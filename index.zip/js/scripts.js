$(document).ready(function() {
    $('#fullpage').fullpage({
		// sectionsColor: ['#0F2980', '#ffd200', '#c1c1c1','#0F2980', '#ffd200', '#c1c1c1','#0F2980', '#ffd200', '#c1c1c1','#0F2980'],
		anchors:['presentacion', 'evan', 'cualidades','queEsVue','mvc','caracteristicas','loader','estructura','gracias'],
		menu: '.main-nav ul',
	});
});