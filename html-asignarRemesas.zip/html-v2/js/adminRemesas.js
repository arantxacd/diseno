// document.getElementById('iconoExcel').style.display = 'none';
document.getElementById('contenedorRemesas').style.display = 'none';
var json_object;
function handleFileSelect(evt) {
  var selectedFile = evt.target.files[0];
  var reader = new FileReader();
  reader.onload = function(event) {
    var data = event.target.result;
    var workbook = XLSX.read(data, {
      type: "binary"
    });

    json_object = XLSX.utils.sheet_to_row_object_array(
      workbook.Sheets[workbook.SheetNames[0]]
    );

    document.getElementById('subirExcel').style.display = 'block';
  };

  reader.onerror = function(event) {
    console.error("File could not be read! Code " + event.target.error.code);
    document.getElementById('subirExcel').style.display = 'none';
  };

  reader.readAsBinaryString(selectedFile);

}

document.getElementById("files").addEventListener("change", handleFileSelect, false);

function cargarTabla() {
    var container = document.getElementById("tablaCuerpo");
    container.innerHTML = '';
    json_object.forEach(element => {
        var tr = document.createElement("tr");
        var tdGuia = document.createElement("td");
        tdGuia.tagName = 'td';
        tdGuia.innerHTML = element.GUIA;

        var tdRemesa = document.createElement("td");
        tdRemesa.innerHTML = element.REMESA;
        
        var tdSucursal = document.createElement("td");
        tdSucursal.innerHTML = element.SUCURSAL;
        
        tr.appendChild(tdGuia);
        tr.appendChild(tdRemesa);
        tr.appendChild(tdSucursal);
        container.appendChild(tr);

    });
    document.getElementById('contenedorRemesas').style.display = 'block';
    $("#tablaCuerpo tr:nth-of-type(2) td:nth-of-type(2)").append("<div>El número de remesa debe contener dieciocho dígitos</div>");
    $("#tablaCuerpo tr:first-of-type td:last-of-type").append("<div>La sucursal debe contener cuatro dígitos</div>");

}

editando = false;

function editarTabla() {
    editando = !editando;
    let cells = document.getElementsByTagName('td');
    if (editando) {
        for (let cell of cells) {
            let input = document.createElement('input');
            input.setAttribute('type', 'text');
            input.setAttribute('value', cell.innerHTML);
            cell.innerHTML = "";
            cell.appendChild(input);
        }
    } else {
        for (let cell of cells) {
            cell.innerHTML = cell.children[0].value;
        }
    }
}

function abrirModal(idModal) {
  this.id=idModal;
    alert(this.id);
    // $("#"+idModal+"").dialog({
    //     draggable: false,
    //     modal: true,
    //     minWidth: 500,
    //     minHeight: 280
    //   });
}

//
$(".modal_view").click(function(){
  var modalId = $(this).attr("modal");
  $("#"+modalId+"").dialog({
      draggable: false,
      modal: true,
      minWidth: 500,
      minHeight: 280
    });
})

$(".menuAdminRemesas #linkInventario").click(function(){
  $(this).addClass("linkActive");
  $(".menuAdminRemesas #linkInventario div").addClass("menuActive");
  $(".menuAdminRemesas #linkCargaRemesas").removeClass("linkActive");
  $(".menuAdminRemesas #linkCargaRemesas div").removeClass("menuActive");
  $(".menuAdminRemesas #linkAsignarRemesas").removeClass("linkActive");
  $(".menuAdminRemesas #linkAsignarRemesas div").addClass("menuActive");
});

$(".menuAdminRemesas #linkCargaRemesas").on('click',function(){
  alert("Hola");
  $(this).addClass("linkActive");
  $(".menuAdminRemesas #linkCargaRemesas div").addClass("menuActive");
  $(".menuAdminRemesas #linkInventario").removeClass("linkActive");
  $(".menuAdminRemesas #linkInventario div").removeClass("menuActive");
});

$(".menuAdminRemesas #linkAsignarRemesas").click(function(){
  $(".menuAdminRemesas #linkInventario").removeClass("linkActive");
  $(".menuAdminRemesas #linkInventario div").removeClass("menuActive");
  $(".menuAdminRemesas #linkCargaRemesas").removeClass("linkActive");
  $(".menuAdminRemesas #linkCargaRemesas div").removeClass("menuActive");
  $(".menuAdminRemesas #linkAsignarRemesas").addClass("linkActive");
  $(".menuAdminRemesas #linkAsignarRemesas div").addClass("menuActive");
});

var validarArchivo = [
  {nombre:"upload_btn", estatus:false}
];
$(document).ready(function(){
  $('.uploadRemesas').change(function () {
    console.log(this.files[0].name);
    if(this.files[0].name == ""){
      validarArchivo[0].estatus=false;
    } else{
      validarArchivo[0].estatus=true;
       $('.btnPrevisualizar').addClass("desac");
    }
    ejecutarValidacion();
  });

});


function ejecutarValidacion(){
    if(validarArchivo[0].estatus=true){
      $(".btnPrevisualizar").removeClass("desac");
    } else {
      $(".btnPrevisualizar").addClass("desac");
    }
}


$(".divAlerta").hide();
$(".btnError").click(function(){
  $(".divAlerta").show();
});


$(".btnRemesa").click(function(){
  alert("Hola");
});

