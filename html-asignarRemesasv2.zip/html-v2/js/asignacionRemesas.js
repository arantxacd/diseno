

$(document).ready(function() {
    var dataSrc = [];
    var table = $('#example').DataTable({
        "searching": false,
        'initComplete': function(){
            var api = this.api();
   
            // Populate a dataset for autocomplete functionality
            // using data from first, second and third columns
            api.cells('tr', [0, 1, 2]).every(function(){
               // Get cell data as plain text
               var data = $('<div>').html(this.data()).text();           
               if(dataSrc.indexOf(data) === -1){ dataSrc.push(data); }
            });
            
            // Sort dataset alphabetically
            dataSrc.sort();
           
            // Initialize Typeahead plug-in
            $('.dataTables_filter input[type="search"]', api.table().container())
               .typeahead({
                  source: dataSrc,
                  afterSelect: function(value){
                     api.search(value).draw();
                  }
               }
            );
         },
        language: {
            paginate: {
              first:      'Primero',
              previous:   'Anterior',
              next:       'Siguiente',
              last:       'Último',
            },
        },
        responsive: true,
        // 'ajax': 'https://api.myjson.com/bins/16lp6',
        'columns': [
            {
                'className':      'details-control',
                'orderable':      false,
                'data':           null,
                'defaultContent': ''
            },
            { 'data': 'Nombre del Implementador' },
            { 'data': 'Remesas solicitadas' },
            { 'data': 'Remesas con las que cuenta' },
            { 'data': 'Fecha de implementación' },
        ],
        'order': [[1, 'asc']]
    });

    // Add event listener for opening and closing details
    $('#example tbody').on('click', 'td.details-control', function(){
        
        var tr = $(this).closest('tr');
        var row = table.row( tr );

        if(row.child.isShown()){
            console.log(row.child);
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
        } else {
            // Open this row
            row.child(format(row.data())).show();
            tr.addClass('shown');
            $(".divOtroMotivo").hide();
            $( "#selectRechazar").dropkick({
                mobile: true
            });
            
        }
    });


    // Handle click on "Expand All" button
    // $('#btn-show-all-children').on('click', function(){

    //     // Enumerate all rows
    //     table.rows().every(function(){
    //         // If row has details collapsed
    //         if(!this.child.isShown()){
    //             // Open this row
    //             this.child(format(this.data())).show();
    //             $(this.node()).addClass('shown');
    //         }
    //     });
    // });

    // Handle click on "Collapse All" button
    $('#btn-hide-all-children').on('click', function(){

        // Enumerate all rows
        table.rows().every(function(){
            // If row has details expanded
            if(this.child.isShown()){
                // Collapse row details
                this.child.hide();
                $(this.node()).removeClass('shown');
            }
        });
    });
});

function format ( d ) {
    
    // `d` is the original data object for the row
    return `
    <div class="divCol4 divCol4M tLeft">
        <div class="col4">
            <div class="bold">Empresa:</div>
            <label>Nissan</label>
        </div>
        <div class="col4">
            <div class="bold">Fecha de implementación:</div>
            <label>15/05/2020</label>
        </div>
        <div class="col4">
            <div class="btnCenter">
                <button class="btn btnWhite ripple" onclick="abrirAsignarRemesa()">Asignar</button>
            </div>
        </div>
        <div class="col4">
            &nbsp;
        </div>
        <div class="col4">
            <div class="bold">Lugar de implementación:</div>
            <label>Prolongación Paseo de la Reforma 1015-23, Lomas de Santa Fe, Contadero.</label>
        </div>
        <div class="col4">
            &nbsp;
        </div>
        <div class="col4 divSelectRechazar">
            <select id="selectRechazar" onchange="functionSelectRechazar()">
                <option value="0">Rechazar por</option>
                <option value="1">Remesas insuficientes</option>
                <option value="2">Implementación sin notificar</option>
                <option value="3">Implementador cuenta con remesas</option>
                <option value="Otro">Otro</option>
            </select>
        </div>
        <div class="col4 divOtroMotivo">
            <textarea placeholder="Escribe el motivo de rechazo" id="motivoRechazo" onkeyup="functionValidarOtro()"></textarea>
            <div class="btnCenter">
                <button class="btn btnRojo btnRechazar desac2" onclick="remesaRechazadaCorrecta()">Rechazar</button> 
            </div>
        </div>
    </div>`;
}
function functionValidarOtro() {

    var textarea_value = $("#motivoRechazo").val();
    
    if(textarea_value != '') {
        $(".btnRechazar").removeClass("desac2");
    } else {
        $(".btnRechazar").addClass("desac2");
    }

}

function remesaRechazadaCorrecta(){
    var table = $('#example').DataTable();
    var tr = $('td.details-control').closest('tr');
    var row = table.row( tr );
    row.child.hide();
    tr.removeClass('shown');
    alertaRechazada();
}
function alertaRechazada(){
    $('#remesaRechazada').addClass('active').delay(7000).queue(function(next) {
        $(this).removeClass('active');
        next();
    });
    $('#remesaRechazada').css("display", "block");
}

function abrirAsignarRemesa() {
    $("#modalAsignarRemesa").modal({
        showClose: false
    });
}
function abrirAsignarRemesa2() {
    $("#modalAsignarRemesa2").modal({
        showClose: false
    });
}
function closeModal() {
    $.modal.close();
    alertaRemesaAsignada();

}
function alertaRemesaAsignada (){
    $('#remesaAsignada').addClass('active').delay(7000).queue(function(next) {
        $(this).removeClass('active');
        next();
    });
    $('#remesaAsignada').css("display", "block");
}

function closeRechazar(){
    $.modal.close();
    remesaRechazadaCorrecta();
    alertaRechazada();
}

function functionSelectRechazar(){
    var rechazo = new Dropkick("#selectRechazar");
    console.log(rechazo.value);
    if(rechazo.value == "Otro"){
        $(".divOtroMotivo").show();
    } else {
        $(".divOtroMotivo").hide();
        $("#modalConfirmacionRechazo").modal({
            showClose: false
        });
    }
}


$(".btnAsignar").click(function(){
    window.location="implementadores.html";
});

$(document).ready( function () {
    $('#tblRemesasAprobadas').DataTable({
        "paging":   true,
        "info":     false,
        "searching": false,
        language: {
            paginate: {
              first:      'Primero',
              previous:   'Anterior',
              next:       'Siguiente',
              last:       'Último',
            },
        },
        responsive: true,
    });
    $('#tblRemesasRechazadas').DataTable({
        "paging":   true,
        "info":     false,
        "searching": false,
        language: {
            paginate: {
              first:      'Primero',
              previous:   'Anterior',
              next:       'Siguiente',
              last:       'Último',
            },
        },
        responsive: true,
    });
});
