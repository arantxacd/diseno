// Menu hambuergesa
$("#effect").toggle(false);
$("#hamburger").click(function (event) {
    event.stopPropagation();
        $( "#effect" ).toggle( "slide"); 
});

$(document).click(function() {
    $("#effect").toggle(false);
});
$("#effect").click (function (event){
    event.stopPropagation();
}); 

function redirect(){
    window.location.href = "inventario.html" ;
}

$(".btnRemesa").click(function(){
    window.location.href = "cargarRemesas.html";
});

function menuLogOut() {
    document.getElementById("myDropdown").classList.toggle("show");
}

function notificaciones() {
    document.getElementById("myDropdownNotificaciones").classList.toggle("show");
}

window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        if (openDropdown.classList.contains('show')) {
            openDropdown.classList.remove('show');
        }
        }
    }

    if (!event.target.matches('.dropbtn2')) {
        var dropdowns = document.getElementsByClassName("dropdown-content-noti");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        if (openDropdown.classList.contains('show')) {
            openDropdown.classList.remove('show');
        }
        }
    }
}

$(document).ready(function(){
    $('#remesaEnviada').addClass('active').delay(7000).queue(function(next) {
        $(this).removeClass('active');
        next();
    });
    
    $(".btnCerrarAlerta").click(function(){
        $('.alertaEnviada').css("display", "none");
    });
});


$(".btnEnviar").click(function quickadd() {
    window.location="inventario.html";
});


//FECHA Y HORA ACTUAL
var date = new Date();
var meses = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
function actualizarFechaHora(){
    date = new Date();
    var fechaHora = [date.getDate(),date.getFullYear(),date.getHours(),date.getMinutes()];
    for ( var i = 0 ; i < fechaHora.length ; i++){
        if(fechaHora[i].toString().length === 1){
            var aux = fechaHora[i];
            fechaHora[i] = '0' + aux;
        }
    }
    document.getElementById('fecha').innerHTML = fechaHora[0] + '/' + meses[date.getMonth()] + '/' + fechaHora[1];
    document.getElementById('hora').innerHTML = fechaHora[2] + ':' + fechaHora[3] + 'Hrs.';
}
actualizarFechaHora();
setInterval(function(){ 
    actualizarFechaHora();
}, 5000);
//FIN FECHA Y HORA ACTUAL
