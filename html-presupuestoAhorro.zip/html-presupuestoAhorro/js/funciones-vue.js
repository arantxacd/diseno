if (Vue) {
	
	Vue.component('header_principal', {
		template: `
			<div class="header">
				<div class="headerMenu">&nbsp</div>
				<div class="headerLogo">
					<a href="index.html"><img src="img/logo.svg" id="imgLogo"></a>
				</div>
				<div class="headerUser">
					<div class="name"><strong>{{usr_nombre}}</strong> {{usr_apellido}}<br>{{usr_puesto}}</div>
				</div>
			</div>
		`,
		props: ['usr_nombre', 'usr_apellido', 'usr_puesto'],
		created: function () {
		},
	});
	Vue.component('menuprin', {
	template: `
		<div id="menu1">
			<ul class="Nivel1">
				<li v-bind:class="{'menuActiv': opcionSel(1)}" v-on:click="selectOption(1)"><a href="consulta-saldo.html"><div><div><img src="img/menu/menu1.svg"></div><div>OPERACIONES TOP</div></div></a></li>
				<li v-bind:class="{'menuActiv': opcionSel(2)}" v-on:click="selectOption(2)"><div><div><img src="img/menu/menu2.svg"></div><div>DEPOSITOS</div></div></li>
				<li v-bind:class="{'menuActiv': opcionSel(3)}" v-on:click="selectOption(3)"><div><div><img src="img/menu/menu3.svg"></div><div>RETIROS</div></div>
					<ul class="Nivel2">
						<li>
							<a href="#">
								<p>Nivel 2</p>
								<div class="flecha"></div>
							</a>
							<ul class="Nivel3">
								<li><a href="#">
										<p>Nivel 3</p>
									</a></li>
								<li><a href="#">
										<p>Nivel 3</p>
									</a></li>
								<li><a href="#">
										<p>Nivel 3</p>
									</a></li>
								<li><a href="#">
										<p>Nivel 3</p>
									</a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li  v-bind:class="{'menuActiv': opcionSel(4)}" v-on:click="selectOption(4)"><div><div><img src="img/menu/menu4.svg"></div><div>CANCELACIÓN</div></div></li>
				<li  v-bind:class="{'menuActiv': opcionSel(5)}" v-on:click="selectOption(5)"><div><div><img src="img/menu/menu5.svg"></div><div>CONSULTAS</div></div></li>
				<li  v-bind:class="{'menuActiv': opcionSel(6)}" v-on:click="selectOption(6)"><div><div><img src="img/menu/menu6.svg"></div><div>REVERSOS</div></div></li>
				<li  v-bind:class="{'menuActiv': opcionSel(7)}" v-on:click="selectOption(7)"><div><div><img src="img/menu/menu7.svg"></div><div>MI AYUDA</div></div></li>
			</ul>
		</div>
	`,
		created: function () {
		},
		methods: {
			selectOption: function (opMenu) {
				this.opMenuSel = opMenu;
			},
			opcionSel: function (opMenu) {
				return this.opMenuSel == opMenu;
			},
		},
		data: function () {
			return { opMenuSel: 0, };
		},
	});

	/*componente menu + header */
	Vue.component('menu_mas_header',{
		template:`
		<div>
			<header_principal v-bind:usr_nombre="usr_nombre" v-bind:usr_apellido="usr_apellido" v-bind:usr_puesto="usr_puesto"></header_principal>
			<menuprin></menuprin>
		</div>
		`,
		props: ['usr_nombre', 'usr_apellido', 'usr_puesto']
	});
	//Loader
	Vue.component('loader', {
		template: `
			<div>
				<div class="modal-mask "></div>
				<div class="loader">Loading...</div>
			</div>
		`,
		created: function () {
		},
		methods: {
		}
	});

	//slider
	Vue.component('slider', {
		template: `
			<div class="contHome">
				<div id="owl-carousel3" class="owl-carousel owl-theme">
					<div class="item"><img src="img/slider/slider01.jpg" class="png"></div>
					<div class="item"><img src="img/slider/slider02.jpg" class="png"></div>
				</div>
			</div>
		`,
		created: function () {
		},
		methods: {		
			
		}
	});

	var app_obj = new Vue({
		el: '#app',
		data: {
			usrNombre: '',
			usrApellido: '',
			usrPuesto: '',
		},
		
		methods: {
			//header Usuario ----------------------------
			cargarInfUsuario: function () {
				this.usrNombre = 'Coyolxauhqui';
				this.usrApellido = 'Ramírez Romero';
				this.usrPuesto = 'Administrador';
			},
			//Slider--------------------------------------
			cargarSlider: function () {
				$('#owl-carousel3').owlCarousel({
					margin: 10,
					nav: true,
					loop: true,
					responsive: {
						0: {
							items: 1
						},
						600: {
							items: 1
						},
						1000: {
							items: 1
						}
					}
				});
			},	
		},
		created: function () {
			this.cargarInfUsuario();
			
		},
		mounted: function () {
			this.cargarSlider();
		},
		updated: function () {

		}
	});
}



