if (Vue)  {
	//Modal Consulta Guia
     Vue.component('modalEstadistico', {
     	template: `
			<transition name="modal">
				<div class="modal-mask">
				  <div class="modal-wrapper">
					<div class="modal-container modal-long cuadroG">
					  <div class="modal-body">
						 <div class="cuadro ">
							<a href="#" class="simplemodal-close btnCerrar" @click="$emit('close')"><img src="img/icoCerrar.svg"></a>
							<div class="titModal">Estadístico de la Guía</div><br>

							<div class="contModal tCenter">
								<div class="titCol">Guía <strong>673523452354326</strong></div>
								<table class="tblGeneral">
								  <tbody>
									<tr>
									  <th>Número de Lote</th>
									  <th>Total Tarjetas</th>
									  <th>Total Tarjetas<br>Pendientes de Entregar</th>
									  <th>Total Tarjetas<br><br>Entregadas/canceladas</th>
									  <th>Fecha Recepción</th>
									</tr>
									<tr>
									   <td>{{v-bind:NoLote}}</td>
										
									</tr>
								  </tbody>
								</table>
							</div>
						</div>
					  </div><br>
					</div>
				  </div>
				</div>
			</transition>
		`,
		props: ['show'],
		methods: {
			close: function () {
				this.$emit('close');
			},
		}
	});
	
	Vue.component('presupuesto-ahorro', {
		template: `
			<div class="contSecc">
				<div class="titSec">Depósito inicial</div>
				<div class="gris">
					<div class="titCol">Ingrese la siguiente información.</div>
					<div class="divCol4">
						<div class="col4">
							Monto de Ahorro:<br>
							<input type="number" placeholder="10,000">
						</div>
						<div class="col4">
							Selecciona:<br>
							<drop_down :config="selPresupuesto"
										@cambiar_option_seleccionada="setSelectedOpPresupuesto($event);">
							</drop_down>
						</div>
						<div class="col4">
							Tipo de Producto:<br>
							<drop_down :config="selProducto" 
									   @cambiar_option_seleccionada="setSelectedOpProducto($event);">
							</drop_down>
						</div>
						<div class="col4">
							&nbsp;<br>
							<a href="#" class="btn1 btnBuscar">Consultar</a>
						</div>
					</div>
				</div>
			</div>
		`,
		props:[],
		data: function() {
			return {
				selPresupuestoID:"0",
				selProductoID:"0",
				//
				selPresupuesto: {
					options: [
						{id:1,value: "CDP"},
						{id:2,value: "Cuenta Socio Empleados"},
						{id:3,value: "Inversión Azteca Creciente"},
						{id:4,value: "Inversión Quetzales"},
						{id:5,value: "Inversión Azteca USD"},
						{id:6,value: "Guardadito"},
						{id:7,value: "Guardakids"},
						{id:8,value: "Guardadito USD"}
					],
					prefix: "",
					placeholder:"Selecciona una opción",
					textColor:"#006341"
				},
				//Tipo de Producto
				selProducto: {
					options: [
					  {id:1,value: "CP. -Tarjeta Mastercard Anónima"},
					  {id:2,value: "Opción 2"},
					  {id:3,value: "Opción 3"}
					],
					prefix: "",
					placeholder: "Seleccione una opción",
					textColor: "#006341"
				},
			};
		},
		methods: {
			//Presupuesto
			setSelectedOpPresupuesto(selectedOption) {
				this.selPresupuestoID=selectedOption.id;
				this.selPresupuesto.placeholder = selectedOption.value;
			},
			//Tipo de producto
			setSelectedOpProducto(selectedOption) {
				this.selProductoID=selectedOption.id;
      			this.selProducto.placeholder = selectedOption.value;
			},
		}
	});
}