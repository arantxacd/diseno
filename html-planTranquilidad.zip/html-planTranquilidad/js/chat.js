$( ".kapat" ).click(function() {
  var durum = $(this).text(),chat=$("#chat"),yaz= $(this);
  if(durum=="-"){
  yaz.html("+");
  chat.animate({
    bottom: "-314px"
  }, 100);
  }else{
   yaz.html("-");
   chat.animate({
    opacity: 1,
    bottom: "0px"
  }, 100);
  }
}); 
 
$('#txt').keydown(function (e){
    if(e.keyCode == 13){
      var yaz="<div class='o'><img align='right' src='img/chat/logo.png'width='35px'><div class='texto'>Buenas tardes <br>¿En qué puedo ayudarte?</div>",
          yazi = $("#txt").val(),
          output = $('.mesaj-gecmisi'),
          img="<img align='left' src='img/chat/usuario.png'width='35px'>",
          sil ="<div class='sil'></div>";
      $("#sonuc").append("<div class='sen'>"+img+"<div class='texto1'>"+yazi+"</div></div>" +sil+yaz +sil+"</div>");
        output.scrollTop(
          output[0].scrollHeight - output.height()
        );
      
        $("#form")[0].reset();
    }
});




