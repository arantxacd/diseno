angular.module('app', [])

.controller('validarForm', ['$scope', function($scope) {
    $scope.tab = 1;

    $scope.setTab = function(newTab){
      $scope.tab = newTab;
    };

    $scope.isSet = function(tabNum){
      return $scope.tab === tabNum;
    };
    $scope.ordenarPor = function(orden){
      $scope.ordenSeleccionado = orden;
    }
    $scope.reportes =
    [
        {idReporte:1,nombreCorto:'Nombre 1', empresa: 'TV Azteca 3', Contrario: '04ST, S.C.', tipoAsunto: 'Asunto 1', Cuantia:'Cuantia 1', Objetivo:'Objetivo 1', areaCliente:'Area 1', Estatus:'Estatus 1', abogadoInt:'Abogado Interno 1', abogadoExt:'Abogado Externo 1', fechaTurno:'17/04/19'},
        {idReporte:2,nombreCorto:'Nombre 2', empresa: 'TV Azteca 3', Contrario: 'AAURG, S.A. DE C.V.', tipoAsunto: 'Asunto 2', Cuantia:'Cuantia 2', Objetivo:'Objetivo 2', areaCliente:'Area 2', Estatus:'Estatus 2', abogadoInt:'Abogado Interno 2', abogadoExt:'Abogado Externo 2', fechaTurno:'17/04/19'},
        {idReporte:3,nombreCorto:'Nombre 3', empresa: 'Azteca Novelas', Contrario: 'ADISTT, S.A. DE C.V.', tipoAsunto: 'Asunto 3', Cuantia:'Cuantia 3', Objetivo:'Objetivo 3', areaCliente:'Area 3', Estatus:'Estatus 3', abogadoInt:'Abogado Interno 3', abogadoExt:'Abogado Externo 3', fechaTurno:'17/04/19'},
        {idReporte:4,nombreCorto:'Nombre 4', empresa: 'TV Azteca ', Contrario: 'Yolanda Torres', tipoAsunto: 'Asunto 4', Cuantia:'Cuantia 4', Objetivo:'Objetivo 4', areaCliente:'Area 4', Estatus:'Estatus 4', abogadoInt:'Abogado Interno 4', abogadoExt:'Abogado Externo 4', fechaTurno:'17/04/19'},
        {idReporte:5,nombreCorto:'Omar', empresa: 'TV Azteca 3', Contrario: 'Ximena González ', tipoAsunto: 'Asunto 5', Cuantia:'Cuantia 5', Objetivo:'Objetivo 5', areaCliente:'Area 5', Estatus:'Estatus 5', abogadoInt:'Abogado Interno 5', abogadoExt:'Abogado Externo 5', fechaTurno:'17/04/19'},
        {idReporte:6,nombreCorto:'Ariel', empresa: 'Azteca Novelas', Contrario: 'WESTHILL, S.C.', tipoAsunto: 'Asunto 6', Cuantia:'Cuantia 6', Objetivo:'Objetivo 6', areaCliente:'Area 6', Estatus:'Estatus 6', abogadoInt:'Abogado Interno 6', abogadoExt:'Abogado Externo 6', fechaTurno:'17/04/19'},
        {idReporte:7,nombreCorto:'Coyolxauhqui', empresa: 'TV Azteca 3', Contrario: 'Contrario 7', tipoAsunto: 'Asunto 7', Cuantia:'Cuantia 7', Objetivo:'Objetivo 7', areaCliente:'Area 7', Estatus:'Estatus 7', abogadoInt:'Abogado Interno 7', abogadoExt:'Abogado Externo 7', fechaTurno:'17/04/19'},
        {idReporte:8,nombreCorto:'Arantxa', empresa: 'TV Azteca 3', Contrario: 'Contrario 8', tipoAsunto: 'Asunto 8', Cuantia:'Cuantia 8', Objetivo:'Objetivo 8', areaCliente:'Area 8', Estatus:'Estatus 8', abogadoInt:'Abogado Interno 8', abogadoExt:'Abogado Externo 8', fechaTurno:'17/04/19'},
        {idReporte:9,nombreCorto:'Haim', empresa: 'TV Azteca 3', Contrario: 'Contrario 9', tipoAsunto: 'Asunto 9', Cuantia:'Cuantia 9', Objetivo:'Objetivo 9', areaCliente:'Area 9', Estatus:'Estatus 9', abogadoInt:'Abogado Interno 9', abogadoExt:'Abogado Externo 9', fechaTurno:'17/04/19'},
    ];

    $scope.noticias =
    [
        {idNoticia:1, fechaAsunto:'01/03/18', asunto:'TV NOTAS Origel anuncia que demandará a TV Azteca y a Daniel Bisogno'},
        {idNoticia:2, fechaAsunto:'08/09/18', asunto:'YOUTUBE Origel habla sobre estancia en Ventaneando'},
    ];

    $scope.juicios =
    [
        {idJuicios:1,nombreCorto:'Haim', actor:'Actor 1', demandado:'Demandado 1', caracter:'Carácter 1', juzgado:'Juzgado 1', nombreFuncionario:'Funcionario 1', expediente:'Expediente 1', cuantia:'Cuantía 1'},
        {idJuicios:2,nombreCorto:'Omar', actor:'Actor 2', demandado:'Demandado 2', caracter:'Carácter 2', juzgado:'Juzgado 2', nombreFuncionario:'Funcionario 2', expediente:'Expediente 2', cuantia:'Cuantía 2'},
        {idJuicios:3,nombreCorto:'Arantxa', actor:'Actor 3', demandado:'Demandado 3', caracter:'Carácter 3', juzgado:'Juzgado 3', nombreFuncionario:'Funcionario 3', expediente:'Expediente 3', cuantia:'Cuantía 3'},
        {idJuicios:4,nombreCorto:'Coyolxauhqui', actor:'Actor 4', demandado:'Demandado 4', caracter:'Carácter 4', juzgado:'Juzgado 4', nombreFuncionario:'Funcionario 4', expediente:'Expediente 4', cuantia:'Cuantía 4'},
        {idJuicios:5,nombreCorto:'Ariel', actor:'Actor 5', demandado:'Demandado 5', caracter:'Carácter 5', juzgado:'Juzgado 5', nombreFuncionario:'Funcionario 5', expediente:'Expediente 5', cuantia:'Cuantía 5'},
    ];

    $scope.recursos =
    [
        {idRecursos:1,nombreCorto:'Haim', recurrente:'Recurrente 1', recurrido:'Recurrido 1', tipoRecurso:'Recurso 1', aQuo:'A Quo 1', expedienteQuo:'Expediente 1', adQuem:'Ad Quem 1', expedienteQuem:'Expediente 1', resolucionRecurrida:'Resolución 1', tema:'Materia 1', status:'Status 1', fechaPresentacion:'Fecha 1'},
        {idRecursos:2,nombreCorto:'Omar', recurrente:'Recurrente 2', recurrido:'Recurrido 2', tipoRecurso:'Recurso 2', aQuo:'A Quo 2', expedienteQuo:'Expediente 2', adQuem:'Ad Quem 2', expedienteQuem:'Expediente 2', resolucionRecurrida:'Resolución 2', tema:'Materia 2', status:'Status 2', fechaPresentacion:'Fecha 2'},
        {idRecursos:3,nombreCorto:'Arantxa', recurrente:'Recurrente 3', recurrido:'Recurrido 3', tipoRecurso:'Recurso 3', aQuo:'A Quo 3', expedienteQuo:'Expediente 3', adQuem:'Ad Quem 3', expedienteQuem:'Expediente 3', resolucionRecurrida:'Resolución 3', tema:'Materia 3', status:'Status 3', fechaPresentacion:'Fecha 3'},
        {idRecursos:4,nombreCorto:'Coyolxauhqui', recurrente:'Recurrente 4', recurrido:'Recurrido 4', tipoRecurso:'Recurso 4', aQuo:'A Quo 4', expedienteQuo:'Expediente 4', adQuem:'Ad Quem 4', expedienteQuem:'Expediente 4', resolucionRecurrida:'Resolución 4', tema:'Materia 4', status:'Status 4', fechaPresentacion:'Fecha 4'},
        {idRecursos:5,nombreCorto:'Ariel', recurrente:'Recurrente 5', recurrido:'Recurrido 5', tipoRecurso:'Recurso 5', aQuo:'A Quo 5', expedienteQuo:'Expediente 5', adQuem:'Ad Quem 5', expedienteQuem:'Expediente 5', resolucionRecurrida:'Resolución 5', tema:'Materia 5', status:'Status 5', fechaPresentacion:'Fecha 5'},
    ];

    $scope.amparos =
    [
        {idAmparos:1,nombre:'Omar', expediente:'Expediente 1', quejoso:'Quejoso 1', tercero:'Tercero 1', autoridad:'Autoridad 1', expedienteJuicio:'Expediente 1', juzgado:'Juzgado 1', juez:'Juez 1', Ponente:'Ponente 1', secretario:'Secretario 1', actoReclamado:'Acto 1', amparoDirecto:'Amparo 1', status:'Status 1', suspension:'Suspensión 1', fechaAudiencia:'24/04/19'},
        {idAmparos:2,nombre:'Haim', expediente:'Expediente 2', quejoso:'Quejoso 2', tercero:'Tercero 2', autoridad:'Autoridad 2', expedienteJuicio:'Expediente 2', juzgado:'Juzgado 2', juez:'Juez 2', Ponente:'Ponente 2', secretario:'Secretario 2', actoReclamado:'Acto 2', amparoDirecto:'Amparo 2', status:'Status 2', suspension:'Suspensión 2', fechaAudiencia:'26/04/19'},
        {idAmparos:3,nombre:'Arantxa', expediente:'Expediente 3', quejoso:'Quejoso 3', tercero:'Tercero 3', autoridad:'Autoridad 3', expedienteJuicio:'Expediente 3', juzgado:'Juzgado 3', juez:'Juez 3', Ponente:'Ponente 3', secretario:'Secretario 3', actoReclamado:'Acto 3', amparoDirecto:'Amparo 3', status:'Status 3', suspension:'Suspensión 3', fechaAudiencia:'28/04/19'},
        {idAmparos:4,nombre:'Coyolxauhqui', expediente:'Expediente 4', quejoso:'Quejoso 4', tercero:'Tercero 4', autoridad:'Autoridad 4', expedienteJuicio:'Expediente 4', juzgado:'Juzgado 4', juez:'Juez 4', Ponente:'Ponente 4', secretario:'Secretario 4', actoReclamado:'Acto 4', amparoDirecto:'Amparo 4', status:'Status 4', suspension:'Suspensión 4', fechaAudiencia:'30/04/19'},
        {idAmparos:5,nombre:'Ariel', expediente:'Expediente 5', quejoso:'Quejoso 5', tercero:'Tercero 5', autoridad:'Autoridad 5', expedienteJuicio:'Expediente 5', juzgado:'Juzgado 5', juez:'Juez 5', Ponente:'Ponente 5', secretario:'Secretario 5', actoReclamado:'Acto 5', amparoDirecto:'Amparo 5', status:'Status 5', suspension:'Suspensión 5', fechaAudiencia:'02/05/19'},
    ];

    $scope.jurisprudencias =
    [
        {idJurisprudencias:1, asunto:'Asunto 1', expediente:'Expediente 1', registroIUS:'Registro 1', rubro:'Rubro 1', contenido:'Contenido 1', observacion:'Observación 1'},
        {idJurisprudencias:2, asunto:'Asunto 2', expediente:'Expediente 2', registroIUS:'Registro 2', rubro:'Rubro 2', contenido:'Contenido 2', observacion:'Observación 2'},
        {idJurisprudencias:3, asunto:'Asunto 3', expediente:'Expediente 3', registroIUS:'Registro 3', rubro:'Rubro 3', contenido:'Contenido 3', observacion:'Observación 3'},
        {idJurisprudencias:4, asunto:'Asunto 4', expediente:'Expediente 4', registroIUS:'Registro 4', rubro:'Rubro 4', contenido:'Contenido 4', observacion:'Observación 4'},
        {idJurisprudencias:5, asunto:'Asunto 5', expediente:'Expediente 5', registroIUS:'Registro 5', rubro:'Rubro 5', contenido:'Contenido 5', observacion:'Observación 5'},
    ];

    $scope.perfilJuicios = 
    [
        {idPerfilJuicios:1, actor:'Televisión Azteca', demandado:'Luis David Avila Montes de Oca', tercero:'Tercero 1', caracter:'Actor', entidad:'Distrito Federal', juzgado:'37 civil', juez:'Juan Perez Perez', expediente:'837/2017', cuantia:'100,000', materia:'Civil', via:'Ordinario', accion:'Acción Confesoria', fechaP:'03/04/2017'},
        {idPerfilJuicios:2, actor:'TV AZTECA', demandado:'Luis David Avila Benitez', tercero:'Tercero 2', caracter:'Actor 2', entidad:'Nuevo León', juzgado:'40 civil', juez:'José Luis Cervantes', expediente:'451/2018', cuantia:'250,000', materia:'Civil', via:'Ordinario Civil', accion:'Acción 2 Confesoria', fechaP:'01/12/2018'},
        {idPerfilJuicios:3, actor:'AZTECA 2', demandado:'Arantxa Castañeda Dorantes', tercero:'Tercero 3', caracter:'Actriz', entidad:'Jalisco', juzgado:'14 civil', juez:'Óscar Adrián Montes de Oca', expediente:'325/2017', cuantia:'150,000', materia:'Civil', via:'Civil', accion:'Acción 3 Confesoria', fechaP:'24/03/2017'},
        {idPerfilJuicios:4, actor:'ADN 40', demandado:'Haim González Sagrero', tercero:'Tercero 4', caracter:'Actor 3', entidad:'Chihuahua', juzgado:'04 civil', juez:'Antonio Castelán Osornio', expediente:'265/2014', cuantia:'400,000', materia:'Civil', via:'Ordinario Civil', accion:'Acción 4 Confesoria', fechaP:'14/09/2014'},
        {idPerfilJuicios:5, actor:'TV AZTECA 3', demandado:'José Luis Conde Plata', tercero:'Tercero 5', caracter:'Actor 4', entidad:'Puebla', juzgado:'25 civil', juez:'Omar Dorantes García', expediente:'124/2016', cuantia:'550,000', materia:'Civil', via:'Civil', accion:'Acción 5 Confesoria', fechaP:'30/08/2016'},
    ];

    $scope.perfilAmparos = 
    [
        {idPerfilAmparos:1, quejoso:'Amalia Manriquez Gonzalez', tercero:'Tercero', autoridad:'Juzgado 2 Mercantil Toluca', expediente:'15/2007', calidad:'3ro Interesado', fechaActo:'30/11/2018', actoReclamado:'Sentencia De Segunda Instancia', fechaNotificacion:'01/12/2017', juzgadoDistrito:'4 De Distrito En Materia Civil', juezDistrito:'Jesus Chavéz Chavéz', expedienteAmparo:'D.C. 253/2018', suspension:'No Se Concedió', estatus:'sentencia segunda', tipoAmparo:'Amparo indirecto', caracter:'tercero interesado'},
        {idPerfilAmparos:2, quejoso:'Luis David Ávila Montes De Oca', tercero:'Tercero 1', autoridad:'Juzgado 20 Civil', expediente:'17/2004', calidad:'3ro Interesado', fechaActo:'30/01/2016', actoReclamado:'Emplazamiento Juicio', fechaNotificacion:'01/11/2017', juzgadoDistrito:'7 De Distrito En Materia Civil', juezDistrito:'Rogelio Vargas Vargas', expedienteAmparo:'532/2018', suspension:'No Se Concedió', estatus:'instancia', tipoAmparo:'Amparo directo', caracter:'tercero interesado'},
        {idPerfilAmparos:3, quejoso:'Arantxa Sara Castañeda Dorantes', tercero:'Tercero 2', autoridad:'Juzgado 4 De Distrito En Materia Civil', expediente:'15/2010', calidad:'3ro Interesado', fechaActo:'20/12/2014', actoReclamado:'Sentencia De Segunda Instancia', fechaNotificacion:'01/12/2017', juzgadoDistrito:'4 De Distrito En Materia Civil', juezDistrito:'Carlos Lopez Lopez', expedienteAmparo:'D.C. 255/2018', suspension:'No Se Concedió', estatus:'sentencia segunda', tipoAmparo:'Amparo indirecto', caracter:'tercero interesado'},
        {idPerfilAmparos:4, quejoso:'José Luis Conde Plata', tercero:'Tercero 3', autoridad:'Juzgado 21 Mercantil Monterrey', expediente:'10/2008', calidad:'3ro Interesado', fechaActo:'28/02/2012', actoReclamado:'Emplazamiento Juicio', fechaNotificacion:'02/09/2017', juzgadoDistrito:'7 De Distrito En Materia Civil', juezDistrito:'Martin Suarez Suarez', expedienteAmparo:'530/2018', suspension:'No Se Concedió', estatus:'instancia', tipoAmparo:'Amparo directo', caracter:'tercero interesado'},
        {idPerfilAmparos:5, quejoso:'Óscar Adrian Mendoza', tercero:'Tercero 4', autoridad:'Juzgado 4 Mercantil Toluca', expediente:'19/2009', calidad:'3ro Interesado', fechaActo:'05/09/2017', actoReclamado:'Sentencia De Segunda Instancia', fechaNotificacion:'05/03/2017', juzgadoDistrito:'4 De Distrito En Materia Civil', juezDistrito:'Jesus Chavéz Chavéz', expedienteAmparo:'512/2018', suspension:'No Se Concedió', estatus:'sentencia segunda', tipoAmparo:'Amparo indirecto', caracter:'tercero interesado'},
    ];

    $scope.documentos =
    [
        {idDocumentos:1, nombreArchivo:'Avila-20190301-SentenciaJuicioAmparo', tipoArchivo:'Documento', ubicacion:'Base Operación', documentoAs:'AVILA-20190201-01-SENTENCIA', asunto:'Ávila', ubicacionInt:'//Avila/Constancias-Judiciales'},
        {idDocumentos:2, nombreArchivo:'Avila-20180805-SentenciaJuicioAmparo', tipoArchivo:'Documento', ubicacion:'Comunicados', documentoAs:'AMALIA-20190201-01-SENTENCIA', asunto:'Amalia', ubicacionInt:'//Amalia/Constancias-Judiciales'},
        {idDocumentos:3, nombreArchivo:'Avila-20170711-SentenciaJuicioAmparo', tipoArchivo:'Documento', ubicacion:'Contrario', documentoAs:'GENESIS-20190201-01-SENTENCIA', asunto:'Genésis', ubicacionInt:'//Genesis/Constancias-Judiciales'},
        {idDocumentos:4, nombreArchivo:'Avila-20161101-SentenciaJuicioAmparo', tipoArchivo:'Documento', ubicacion:'Noticias', documentoAs:'WESTHILL-20190201-01-SENTENCIA', asunto:'WestHill', ubicacionInt:'//WestHill/Constancias-Judiciales'},
        {idDocumentos:5, nombreArchivo:'Avila-20161101-SentenciaJuicioAmparo', tipoArchivo:'Documento', ubicacion:'Constancias Judiciales', documentoAs:'WESTHILL-20190201-01-SENTENCIA', asunto:'WestHill', ubicacionInt:'//WestHill/Constancias-Judiciales'},
        {idDocumentos:6, nombreArchivo:'Avila-20190301-SentenciaJuicioAmparo', tipoArchivo:'Documento', ubicacion:'Base Operación', documentoAs:'AVILA-20190201-01-SENTENCIA', asunto:'Ávila', ubicacionInt:'//Avila/Constancias-Judiciales'},
        {idDocumentos:7, nombreArchivo:'Avila-20180805-SentenciaJuicioAmparo', tipoArchivo:'Documento', ubicacion:'Comunicados', documentoAs:'AMALIA-20190201-01-SENTENCIA', asunto:'Amalia', ubicacionInt:'//Amalia/Constancias-Judiciales'},
        {idDocumentos:8, nombreArchivo:'Avila-20170711-SentenciaJuicioAmparo', tipoArchivo:'Documento', ubicacion:'Contrario', documentoAs:'GENESIS-20190201-01-SENTENCIA', asunto:'Genésis', ubicacionInt:'//Genesis/Constancias-Judiciales'},
        {idDocumentos:9, nombreArchivo:'Avila-20161101-SentenciaJuicioAmparo', tipoArchivo:'Documento', ubicacion:'Noticias', documentoAs:'WESTHILL-20190201-01-SENTENCIA', asunto:'WestHill', ubicacionInt:'//WestHill/Constancias-Judiciales'},
        {idDocumentos:10, nombreArchivo:'Avila-201-SentenciaJuicioAmparo', tipoArchivo:'Documento', ubicacion:'Constancias Judiciales', documentoAs:'WESTHILL-20190201-01-SENTENCIA', asunto:'WestHill', ubicacionInt:'//WestHill/Constancias-Judiciales'},
    ];

    $scope.operaciones =
    [
        {idOperaciones:1, nombreArchivo:'Avila-20190301-SentenciaJuicioAmparo', tipoArchivo:'Documento'},
        {idOperaciones:2, nombreArchivo:'Avila-20180805-SentenciaJuicioAmparo', tipoArchivo:'Documento'},
    ];

    $scope.gastos =
    [
        {idGastos:1, pagado:'$10,000.00', anticipo:'$10,000.00', devolucion:'$0.00', reembolso:'$0.00', fechaGasto:'01/01/2019', fechaComprobacion:'01/01/2019', despachoEx:'precargado', motivoGasto:'Texto libre', comprobacion:'Catálogo', encargadoCliente:'Texto libre', observacion:'Texto libre',  nombreCorto:'Ávila', areaCliente:'Noticias', empresa:'TV AZTECA S.A.B DE C.V', abogadoInt:'Arvin Aguilar Villela', abogadoExt:'Arturo Iturraran Viveros'},
        {idGastos:2, pagado:'$12,000.00', anticipo:'$11,000.00', devolucion:'$100.00', reembolso:'$100.00', fechaGasto:'05/08/2019', fechaComprobacion:'05/08/2019', despachoEx:'precargado', motivoGasto:'Texto libre 2', comprobacion:'Catálogo', encargadoCliente:'Texto libre', observacion:'Texto libre', nombreCorto:'Juan', areaCliente:'Noticias', empresa:'TV AZTECA S.A.B DE C.V', abogadoInt:'Arvin Aguilar Villela', abogadoExt:'Arturo Iturraran Viveros'},
    ];
    //Borra
    $scope.borrar = function(e){
        console.log(e);
        e =e-1;
        $scope.gastos.splice([e],1);
    }

    $scope.publicaciones =
    [
        {idPublicaciones:1, fechaP:'15/01/2019', sintesis:'Lorem ipsum dolor sit amet', nombreArchivo:'Asunto-20190212-01-Resolucion', cuaderno:'Principal', observaciones:'Asunto no coincide',},
        {idPublicaciones:2, fechaP:'02/08/2018', sintesis:'Lorem ipsum dolor sit amet', nombreArchivo:'Asunto-20190212-01-Resolucion', cuaderno:'01', observaciones:'Nomenclatura incorrecta: AAAAA.999999[-99]',},
        {idPublicaciones:3, fechaP:'25/12/2018', sintesis:'Lorem ipsum dolor sit amet', nombreArchivo:'Asunto-20190212-01-Resolucion', cuaderno:'01', observaciones:'Caracteres no válidos',},
    ];
    //Borra
    $scope.borrarPubli = function(e){
        console.log(e);
        e =e-1;
        $scope.publicaciones.splice([e],1);
    }
    
    $scope.inventarioAsuntos =
    [
        {idInventarioAsuntos:1, nombreCorto:'Ávila', empresa:'TV AZTECA S.A.B DE C.V', contraparte:'Luis David Ávila, Montes de Oca, David Ávila Benítez', area:'Noticias', tipo:'Concurso mercantil', cuantia:'$11,000,000.00 MXN', AI:'Jaqueline Díaz Pacheco', AE:'Arturo Iturraran Viveros', objetivo:'Objetivo 1', estatus:'En Trámite', registros:'99'},
        {idInventarioAsuntos:2, nombreCorto:'Amalia', empresa:'TV AZTECA S.A.B DE C.V', contraparte:'Amalia González Manriquez', area:'Noticias', tipo:'Revocación', cuantia:'$400,000.00 MXN', AI:'Brenda Ramírez García', AE:'Arturo Iturraran Viveros', objetivo:'Objetivo 2', estatus:'Concluido', registros:'99'},
    ];
    
    
    $scope.notificaciones =
        [
        {idNoti:1, tipoNoti:'Reunión', relevancia:'Alta relevancia', detalle:'Nueva alerta', asunto:'Avila', FechaNoti:'01/01/2019', fecha:'03/01/2019 10:00 am', descripcion:'Texto de ejemplo, Texto de ejemplo, Texto de ejemplo, Texto de ejemplo, Texto de ejemplo,'},
        {idNoti:2, tipoNoti:'Actividad', relevancia:'Alta relevancia', detalle:'Nueva alerta', asunto:'Avila', FechaNoti:'01/01/2019', fecha:'13/07/2019 10:00 am', descripcion:'Texto de ejemplo, Texto de ejemplo, Texto de ejemplo, Texto de ejemplo, Texto de ejemplo,'},
        {idNoti:3, tipoNoti:'Recordatorio', relevancia:'Maedia relevancia', detalle:'Nueva alerta', asunto:'Actividad de oficina', FechaNoti:'23/06/2019', fecha:'03/01/2019 10:00 am', descripcion:'Texto de ejemplo, Texto de ejemplo, Texto de ejemplo, Texto de ejemplo, Texto de ejemplo,'},
        {idNoti:4, tipoNoti:'Reunión', relevancia:'Título informativo', detalle:'Nueva alerta', asunto:'Avila', FechaNoti:'01/01/2019', fecha:'17/02/2019 10:00 am', descripcion:'Texto de ejemplo, Texto de ejemplo, Texto de ejemplo, Texto de ejemplo, Texto de ejemplo,'},
        {idNoti:5, tipoNoti:'Reunión', relevancia:'Alta relevancia', detalle:'Nueva alerta', asunto:'Nogales', FechaNoti:'01/01/2019', fecha:'25/01/2019 10:00 am', descripcion:'Texto de ejemplo, Texto de ejemplo, Texto de ejemplo, Texto de ejemplo, Texto de ejemplo,'},
    ];

    $scope.despachos =
    [
        {idDespachos:1, despacho:'Mallard', abogado:'Juanito Perez Perez', lugar:'Distrito Federal', poblacion:'Tlalpan', areasExp:'Civil, Penal y Laboral', observaciones:'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', telefono:'55-46-37-35 55-46-37-35', email:'correo@dominio.com.mx'},
        {idDespachos:2, despacho:'1 Mallard', abogado:'José Martínez Martínez', lugar:'Distrito Federal', poblacion:'Tlalpan', areasExp:'Civil y Laboral', observaciones:'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', telefono:'55-46-25-45', email:'correo@dominio.com.mx'},
    ];

    //Agregar
        $scope.inputQue = [];
        $scope.inputTerceroI = [];
        $scope.inputExpJuicio = [];
        $scope.inputAbogadoExt = [];
        $scope.inputContraparte = [];
        $scope.inputAutorizados = [];
        $scope.inputAutoridadR = [];
        $scope.inputActor = [];
        $scope.inputDemandado = [];
        $scope.inputFechaEmp = [];
        $scope.inputFechaNot = [];
        $scope.inputRecurrente = [];
        $scope.inputRecurrido = [];
        $scope.inputMagistrados = [];
        $scope.inputApellido = [];
        $scope.agregaPar = [];//alertas
        $scope.AgregaContraparte = [];//contraparte
        $scope.AgregaAbogadoE = [];//abogado externo
        $scope.AgregaAutorizar = [];//autorizados para editar
        $scope.AgregaPoblacion = [];
        $scope.AgregaLugar =[];
        $scope.AgregaEmail = [];
        $scope.inputAdjuntar = [];
        $scope.ren_inputs = [];
    
       /* $scope.agregar_ren_input = function (quejoso) {
            quejoso.push({
                id: $scope.ren_inputs.length + 1,
                valor: ''
            });
        };*/

      /*  $scope.agregar_ren_input = function (TerceroI) {
            TerceroI.push({
                id: $scope.ren_inputs.length + 1,
                valor: ''
            });
        };

        $scope.agregar_ren_input = function (ExpJuicio) {
            ExpJuicio.push({
                id: $scope.ren_inputs.length + 1,
                valor: ''
            });
        };

        $scope.agregar_ren_input = function (AbogadoExt) {
            AbogadoExt.push({
                id: $scope.ren_inputs.length + 1,
                valor: ''
            });
        };

        $scope.agregar_ren_input = function (Contraparte) {
            Contraparte.push({
                id: $scope.ren_inputs.length + 1,
                valor: ''
            });
        };

        $scope.agregar_ren_input = function (Autorizados) {
            Autorizados.push({
                id: $scope.ren_inputs.length + 1,
                valor: ''
            });
        };

        $scope.agregar_ren_input = function (AutoridadR) {
            AutoridadR.push({
                id: $scope.ren_inputs.length + 1,
                valor: ''
            });
        };

        $scope.agregar_ren_input = function (Actor) {
            Actor.push({
                id: $scope.ren_inputs.length + 1,
                valor: ''
            });
        };

        $scope.agregar_ren_input = function (Demandado) {
            Demandado.push({
                id: $scope.ren_inputs.length + 1,
                valor: ''
            });
        };

        $scope.agregar_ren_input = function (FechaEmp) {
            FechaEmp.push({
                id: $scope.ren_inputs.length + 1,
                valor: ''
            });
        };

        $scope.agregar_ren_input = function (FechaNot) {
            FechaNot.push({
                id: $scope.ren_inputs.length + 1,
                valor: ''
            });
        };

        $scope.agregar_ren_input = function (Recurrente) {
            Recurrente.push({
                id: $scope.ren_inputs.length + 1,
                valor: ''
            });
        };*/

        $scope.agregar_ren_input = function (Recurrido) {
            Recurrido.push({
                id: $scope.ren_inputs.length + 1,
                valor: ''
            });
        };

        $scope.agregar_ren_input = function (Magistrados) {
            Magistrados.push({
                id: $scope.ren_inputs.length + 1,
                valor: ''
            });
        };

        $scope.eliminar_input = function (indice, arreglo) {
            arreglo.splice(indice, 1);
        };

        //alertas
        /*$scope.agregar_ren_input = function (agregaPar) {
            agregaPar.push({
                id: $scope.ren_inputs.length + 1,
                valor: ''
            });
        };*/

        $scope.datos =
            [
                { idDato: 1, quejoso: 'Coyo', apellido: 'Ramirez' },
            ];

      /*  $scope.agregar_dato = function () {
            for(var i=0; i<$scope.inputQue.length; i++){
                console.log($scope.inputQue[i].valor);
                $scope.datos.push({
                    idDato: i,
                    quejoso: $scope.inputQue[i].valor,
                    apellido:""
                });
            }
        $scope.inputQue=[];         
            
        };*/
        //
        $scope.asunto_capturado = '';
        $scope.noticias =
            [
                { idNoticia: 1, fechaAsunto: '01/03/18', asunto: 'TV NOTAS Origel anuncia que demandará a TV Azteca y a Daniel Bisogno' },
                { idNoticia: 2, fechaAsunto: '08/09/18', asunto: 'YOUTUBE Origel habla sobre estancia en Ventaneando' },
            ];
        $scope.agregar_noticia = function () {
            $scope.noticias.push({
                idNoticia: $scope.noticias.length + 1,
                fechaAsunto: '19/04/2019',
                asunto: $scope.asunto_capturado
            });
            $scope.asunto_capturado = '';
        };


  }])
.controller('tabs', ['$scope', function($scope) {
    $scope.tab1 = 1;

    $scope.setTab1 = function(newTab1){
      $scope.tab1 = newTab1;
    };

    $scope.isSet1 = function(tabNum1){
      return $scope.tab1 === tabNum1;
    };

    

    $scope.ordenarPor = function(orden){
      $scope.ordenSeleccionado = orden;
    }
    
  }]);


//Calendario
    $.datepicker.regional['es'] = {
         closeText: 'Cerrar',
         prevText: '',
         nextText: ' ',
         currentText: 'Hoy',
         monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
         monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
         dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
         dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
         dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
         weekHeader: 'Sm',
         dateFormat: 'dd/mm/yy',
         firstDay: 1,
         isRTL: false,
         showMonthAfterYear: false,
         yearSuffix: ''
     };
    $.datepicker.setDefaults($.datepicker.regional['es']);
    $(function() {
        $( "#datepicker" ).datepicker({
            firstDay: 1 
        });
        $( "#datepicker1" ).datepicker({
            firstDay: 1 
        });
        $( "#datepicker2" ).datepicker({
            firstDay: 1 
        });
        $( "#datepicker3" ).datepicker({
            firstDay: 1 
        });
        $( "#datepicker4" ).datepicker({
            firstDay: 1 
        });
        $( "#datepicker5" ).datepicker({
            firstDay: 1 
        });
        $( "#datepicker6" ).datepicker({
            firstDay: 1 
        });
        $( "#datepicker7" ).datepicker({
            firstDay: 1 
        });
        $( "#datepicker8" ).datepicker({
            firstDay: 1 
        });
        $( "#datepicker9" ).datepicker({
            firstDay: 1 
        });
        $( "#datepicker10" ).datepicker({
            firstDay: 1 
        });
        $( "#datepicker11" ).datepicker({
            firstDay: 1 
        });
    });

$(document).ready(function() {
     
    
    //Modal resolución
    $('.modalNoCoincidencias_view').click(function (e) {
        $('#modalNoCoincidencias').modal();
        return false;
    })
    
    $('.modalMotivoC_view').click(function (e) {
        $('#modalMotivoC').modal();
        return false;
    })
    
    $('.modalMotivo_view').click(function (e) {
        $('#modalMotivo').modal();
        return false;
    })

    $('.modalCarpeta_view').click(function(e) {
        setTimeout(function() {
            $('#modalCarpeta').modal({
            });
            return false;
        }, 1);
    })

    $('.modalArchivosUnir_view').click(function(e) {
        setTimeout(function() {
            $('#modalArchivosUnir').modal({
            });
            return false;
        }, 1);
    })

    $('.modalErrorCarga_view').click(function(e) {
        setTimeout(function() {
            $('#modalErrorCarga').modal({
            });
            return false;
        }, 1);
    })

    $('.modalCopiarDoc_view').click(function(e) {
        setTimeout(function() {
            $('#modalCopiarDoc').modal({
            });
            return false;
        }, 1);
    })

    $('.modalPrevisualizador_view').click(function(e) {
        setTimeout(function() {
            $('#modalPrevisualizador').modal({
            });
            return false;
        }, 1);
    })

    $('.modalSubirArchivos_view').click(function(e) {
        setTimeout(function() {
            $('#modalSubirArchivos').modal({
            });
            return false;
        }, 1);
    })

    $('.modalRecursos_view').click(function(e) {
        setTimeout(function() {
            $('#modalRecursos').modal({
            });
            return false;
        }, 1);
    })

    $('.modalNuevoAmparo_view').click(function(e) {
        setTimeout(function() {
            $('#modalNuevoAmparo').modal({
            });
            return false;
        }, 1);
    })
    
    $('.modalHora_view').click(function (e) {
        $('#modalHora').modal();
        return false;
    })
    
    $('.modalCapturar_view').click(function (e) {
        $('#modalCapturar').modal();
        return false;
    })
    
    $('.modalAsunto_view').click(function(e) {
        setTimeout(function() {
            $('#modalAsunto').modal({
            });
            return false;
        }, 1);
    })


    $(".divPension").hide();
    $('.btnBuscarPension').click(function (e) {
        $(".divPension").show();
    })
    /*Menu User*/
    $(".MenuUser, .MenuUser1").hide();
    $('.imgShowMenuUser').click(function() {
        $(".MenuUser, .MenuUser1").toggle("ver");
    });

    $(".divRC").hide();
    $('#radioResCivil').on( "change", function() {
                $(".divRC").show();
            });
    $('#radioEmpre').on( "change", function() {
        $(".divRC").hide();
    });
    
    /********Para selects*******************/
    $( "select").dropkick({
        mobile: true
    }); 
    
    $('.switch').click(function(){
        $(this).toggleClass("switchOn");
    }); 
    
    $( ".cerrarChip" ).click(function() {
       $(this).parent().parent().remove()
    });

    
});

 //Acordeon de menu
 $(".menuResponsive").accordion({
      collapsible: true,
      active: false,
      autoHeight: true,
      navigation: true,
      heightStyle: "content"
  });

/*Multiselect*/
$(".mul0 dt a").on('click', function() {$(".mul0 dd ul").slideToggle('fast');});
$(".mul1 dt a").on('click', function() {$(".mul1 dd ul").slideToggle('fast');});
$(".mul2 dt a").on('click', function() {$(".mul2 dd ul").slideToggle('fast');});
$(".mul3 dt a").on('click', function() {$(".mul3 dd ul").slideToggle('fast');});

$("dd ul li a").on('click', function() {$("dd ul").hide();});

function getSelectedValue(id) {return $("#" + id).find("dt a span.value").html();}

$(document).bind('click', function(e) {
  var $clicked = $(e.target);
  if (!$clicked.parents().hasClass("selectMultiple")) $(".selectMultiple dd ul").hide();
});

$('.mul0 .mutliSelect input[type="checkbox"]').on('click', function() {
  var title = $(this).closest('.mutliSelect').find('input[type="checkbox"]').val(),
    title = $(this).val() + ",";
 
  if ($(this).is(':checked')) {
    var html = '<span title="' + title + '">' + title + '</span>';
    $('.mul0 .multiSel').append(html);
    $(".mul0 .hida").hide();
    
  } else {
    $('.mul0 span[title="' + title + '"]').remove();
    var ret = $(".mul0 .hida");
    $('.mul0 dt a').append(ret);
  }
});

$('.mul1 .mutliSelect input[type="checkbox"]').on('click', function() {
  var title = $(this).closest('.mutliSelect').find('input[type="checkbox"]').val(),
    title = $(this).val() + ",";
 
  if ($(this).is(':checked')) {
    var html = '<span title="' + title + '">' + title + '</span>';
    $('.mul1 .multiSel').append(html);
    $(".mul1 .hida").hide();
    
  } else {
    $('.mul1 span[title="' + title + '"]').remove();
    var ret = $(".mul1 .hida");
    $('.mul1 dt a').append(ret);
  }
});

//Reportes
$('.tblEmpleado1 tr td').click(function (e) {
    location.href ="datos-pension.html";
});

$('.tblEmpleado2 tr td').click(function (e) {
    location.href ="reporteria-informacion.html";
});
//Show/Hide


//Mercantil
$('.divEditarDatos').hide();
$('.btnEditar').click(function () {
    $('.divEditarDatos').show();
    $('.divCapturaDatos').hide();
});

$('.btnGuardar').click(function () {
    $('.divEditarDatos').hide();
    $('.divCapturaDatos').show();
});

//Perfil de Asunto

//$('.divOperaciones').hide();
/*$('.btnOp').click(function () {
    alert("Hola");
    $('.divOperaciones').show();
    $('.divAsuntoDoc').hide();
});*/

$('.btnRegresar').click(function () {
    $('.divOperaciones').hide();
    $('.divAsuntoDoc').show();
});

//Nuevo Juicio
$('#radioGarantiaSi').on( "change", function() {
    $('.divGarantia').removeClass("desac");
    return false;
});
$('#radioGarantiaNo').on( "change", function() {
    $('.divGarantia').addClass("desac");
    return false;
});

$('#radioTramiteSi').on( "change", function() {
    $('.divAlcanceS').removeClass("desac");
    return false;
});
$('#radioTramiteNo').on( "change", function() {
    $('.divAlcanceS').addClass("desac");
    return false;
});

$('#radioTesisSi').on( "change", function() {
    $('.divTesis').removeClass("desac");
    return false;
});
$('#radioTesisNo').on( "change", function() {
    $('.divTesis').addClass("desac");
    return false;
});

 

$('.divBusqueda2Asuntos').hide();
$('input[name=busquedaAs]').change(function(){

        if($('#radio1IA').is(':checked')){
            $('.divBusquedaAsuntos').show();
            $('.divBusqueda2Asuntos').hide();
        }else if($('#radio3IA').is(':checked')){
            $('.divBusquedaAsuntos').hide();
            $('.divBusqueda2Asuntos').show();
        } else if($('#radio2IA').is(':checked')) {
            $('.divBusquedaAsuntos').show();
            $('.divBusqueda2Asuntos').hide();
        }
});

$(".divNotificaciones, .userNotificaciones").hide();
    $('.btnNotificacion').click(function() {
        $(".divNotificaciones, .userNotificaciones").toggle("ver");
    });

//
$('#select-all1AU').change(function() {
  var checkboxes = $('.tblGeneral ').find(':checkbox');
  checkboxes.prop('checked', $(this).is(':checked'));
});

//Tree
// Parametros Asignados
    $("#paramPublicaciones").treeview({
        animated: "fast",
        collapsed: false,
        control: "#treecontrol"
    });

    $(' #paramPublicaciones.treeview ul li span').click(function() {
        if ($(this).hasClass("in"))  {
            $(this).removeClass("seleccionado");
            $(this).removeClass("in");
        }else {
            $(this).addClass("seleccionado");
            $(this).addClass("in"); 
        }
    });

//



