var dom = document.getElementById("graficaDona1");
var graficaInfoTab = echarts.init(dom);
var app = {};

var ver1 = 'rgb(200, 222, 21)';
var ver2 = 'rgb(25, 211, 0)';
var ver3 = 'rgb(19, 178, 71)';
var ver4 = 'rgb(14, 151, 137)';
var ama = 'rgb(255, 237,17)';


option = {
    tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b}: {c} ({d}%)'
    },
    legend: {
        orient: 'vertical',
        left: 10,
        data: ['Rechazados', 'Contratados']
    },
    series: [
        {
            name: 'Registros',
            type: 'pie',
            radius: ['50%', '70%'],
            avoidLabelOverlap: false,
            label: {
                show: false,
                position: 'center'
            },
            emphasis: {
                label: {
                    show: true,
                    fontSize: '20',
                    fontWeight: 'bold'
                }
            },
            labelLine: {
                show: true
            },
            data: [
                {
                    value: 335,
                    name: 'Rechazados',
                    itemStyle: {color: ver2},
                },
                {
                    value: 310, 
                    name: 'Contratados',
                    itemStyle: {color: ver4},
                }
            ]
        }
    ]
};

if (option && typeof option === "object") {
    graficaInfoTab.setOption(option, true);
}

var dom2 = document.getElementById("graficaDona2");
var graficaInfoTab2 = echarts.init(dom2);
var app = {};

var ver1 = 'rgb(200, 222, 21)';
var ver2 = 'rgb(25, 211, 0)';
var ver3 = 'rgb(19, 178, 71)';
var ver4 = 'rgb(14, 151, 137)';
var ama = 'rgb(255, 237,17)';


option = {
    tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b}: {c} ({d}%)'
    },
    legend: {
        orient: 'vertical',
        left: 10,
        data: ['No tengo tiempo', 'Colgó', 'No me interesa', 'Demasiado caro', 'Ya tengo uno']
    },
    series: [
        {
            name: 'Registros',
            type: 'pie',
            radius: ['50%', '70%'],
            avoidLabelOverlap: false,
            label: {
                show: false,
                position: 'center'
            },
            emphasis: {
                label: {
                    show: true,
                    fontSize: '15',
                    fontWeight: 'bold'
                }
            },
            labelLine: {
                show: true
            },
            data: [
                {
                    value: 335,
                    name: 'No tengo tiempo',
                    itemStyle: {color: ver1},
                },
                {
                    value: 310, 
                    name: 'Colgó',
                    itemStyle: {color: ver2},
                },
                {
                    value: 335,
                    name: 'No me interesa',
                    itemStyle: {color: ver3},
                },
                {
                    value: 310, 
                    name: 'Demasiado caro',
                    itemStyle: {color: ver4},
                },
                {
                    value: 335,
                    name: 'Ya tengo uno',
                    itemStyle: {color: ama},
                }
            ]
        }
    ]
};

if (option && typeof option === "object") {
    graficaInfoTab2.setOption(option, true);
}

var dom3 = document.getElementById("graficaDona3");
var graficaInfoTab3 = echarts.init(dom3);
var app = {};

var ver1 = 'rgb(200, 222, 21)';
var ver2 = 'rgb(25, 211, 0)';
var ver3 = 'rgb(19, 178, 71)';
var ver4 = 'rgb(14, 151, 137)';
var ama = 'rgb(255, 237,17)';


option = {
    tooltip: {
        trigger: 'item',
        formatter: '{a} <br/>{b}: {c} ({d}%)'
    },
    legend: {
        orient: 'vertical',
        left: 10,
        data: ['T. de crédito', 'T. de débito', 'Ref. de pago']
    },
    series: [
        {
            name: 'Registros',
            type: 'pie',
            radius: ['50%', '70%'],
            avoidLabelOverlap: false,
            label: {
                show: false,
                position: 'center'
            },
            emphasis: {
                label: {
                    show: true,
                    fontSize: '15',
                    fontWeight: 'bold'
                }
            },
            labelLine: {
                show: true
            },
            data: [
                {
                    value: 335,
                    name: 'T. de crédito',
                    itemStyle: {color: ama},
                },
                {
                    value: 310, 
                    name: 'T. de débito',
                    itemStyle: {color: ver2},
                },
                {
                    value: 335,
                    name: 'Ref. de pago',
                    itemStyle: {color: ver4},
                }
            ]
        }
    ]
};

if (option && typeof option === "object") {
    graficaInfoTab3.setOption(option, true);
}



$(".tab").on( "click", function() {   
    graficaInfoTab.resize();
    graficaInfoTab2.resize();
    graficaInfoTab3.resize();
});

window.onresize = function() {
    graficaInfoTab.resize();
    graficaInfoTab2.resize();
    graficaInfoTab3.resize();
};