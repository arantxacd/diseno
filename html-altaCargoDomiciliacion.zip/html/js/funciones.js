
$(document).ready(function() {
	// Menu hambuergesa
	$("#effect").toggle(false);
	$("#hamburger").click(function (event) {
		event.stopPropagation();
		 $( "#effect" ).toggle( "slide"); 
		 $( ".sobresombra" ).toggle( "quitar"); 
	});

	$(document).click(function() {
		$("#effect").toggle(false);
	});
	$("#effect").click (function (event){
		event.stopPropagation();
	}); 
});



$(document).ready(function() {
	// Menu hambuergesa 
	$(".sobresombra").click(function (event) {  
		 $( ".sobresombra" ).toggle( "quitar"); 
	});

	/*Modales*/

	$("#abrirModalRecuerda, .abrirModalRecuerda").click(function(){
        $("#modalRecuerda").modal({
            showClose: false
        });

    });



    $("#abrirModalImprimirAutorizacion, .abrirModalImprimirAutorizacion").click(function(){
        $("#modalImprimirAutorizacion").modal({
            showClose: false
        });
    });

    $("#abrirModalVisualizacionFirma, .abrirModalVisualizacionFirma").click(function(){
        $("#modalVisualizacionFirma").modal({
            showClose: false
        });
    });

    $("#abrirModalProcesoExitoso, .abrirModalProcesoExitoso").click(function(){
        $("#modalProcesoExitoso").modal({
            showClose: false
        });
    });

    $("#abrirVisualizadorArchivos, .abrirModalVisualizadorArchivos").click(function(){
        $("#modalVisualizadorArchivos").modal({
            showClose: false
        });
    });

    $("#abrirEscaneaHuella, .abrirModalEscaneaHuella").click(function(){
        $("#modalEscaneaHuella").modal({
            showClose: false

        });
        setTimeout(function() {
            $("#modalProcesoExitoso").modal({
  				showClose: false,
  			});
        }, 3000);
    });

	/*DatePicker*/
	jQuery('#fechaDuracion').datetimepicker({
      	ownerDocument: document,
      	contentWindow: window,
      	yearStart: '2010',
      	yearEnd: '2030',
      	timepicker:false,
 	  	format:'d/m/Y'
    });
    $.datetimepicker.setLocale('es');


    
 
});

/*Zoom*/
function zoomIn(){
		console.log(anchoImg);
	var anchoImg = $('.imgArchivo').width();
	$('.imgArchivo').width(anchoImg + 100);
}
function zoomOut(){
	console.log(anchoImg);
	var anchoImg = $('.imgArchivo').width();
	$('.imgArchivo').width(anchoImg - 100);
}
function resetWidth(){
	console.log(anchoImg);
	var anchoImg = $('.imgArchivo').css("width", "100%");
	$('.imgArchivo').width(anchoImg);
}

 
/*Menu User*/
$(document).ready(function() {
	$(".MenuUser, .MenuUser1").hide();
	$('.imgShowMenuUser').click(function() {
		$(".MenuUser, .MenuUser1").toggle("ver");
	});
	/*Selecciona marca - Adelanto de nomina*/
	$('.divmarcas a').click(function() {
		$(".divmarcas a").removeClass("selMarca");
		$(this).addClass("selMarca");
	});
	

});

//Validacion login
$(".txtMesaje").hide();
function validaLogin(f) {
	if(f.txtUsuario.value == "")  
  	{	
	  $(".txtMesaje").show();
	  $(".txtRojo").html('Por favor ingrese su usuario');
	  return false;
  	}else
	if(f.txtLlave.value == "" )
  	{
	  $(".txtMesaje").show();
	  $(".txtRojo").html('Por favor ingrese su contraseña');
	  return false;
  	}else
	{
		location.href="index.html";
		return false;}
}
/*Valida buscador del menu de hamburgesa*/
function valida(f) {
	if (f.busca.value == "")  {
		alert("Es necesario que introduzca un valor");
	}else { 
		return false;
	}
}


/*Detecta resolucion de pantalla*/
if (matchMedia) {
  const mq = window.matchMedia("(min-width: 780px)");
  mq.addListener(WidthChange);
  WidthChange(mq);
}
function WidthChange(mq) {
	if (mq.matches) {
	  	$("#menu ul").addClass("normal");
	  	$("#menu ul li").removeClass("in");
		$('ul.nivel1 >li > ul').slideUp();
		$('ul.nivel2 >li > ul').slideUp();
		$('ul.nivel1>li').off("click");
		$('ul.nivel2>li').off("click");
	} else {
	   $("#menu ul").removeClass("normal");

		$('ul.nivel1>li').on('click', function(event) {
			event.stopPropagation();
			event.preventDefault();
			$target = $(this).children();

			if ($(this).hasClass("in"))  {
			    $('ul.nivel2').slideUp();

				$(this).removeClass("in");
				$('.flecha').removeClass("rotar");
			}else {
			  	$('ul.nivel1 > li').removeClass("in");
				$('ul.nivel2').slideUp();
				$('ul.nivel3').slideUp();
				$('ul.nivel2>li').removeClass("in");
				$(this).addClass("in");
			  	$target.slideDown();
				$('ul.nivel1 > li > a .flecha').addClass("rotar");
				
			}
		});
		$('ul.nivel2>li').on('click', function(event) {
			event.stopPropagation();
			event.preventDefault();
			$target = $(this).children();

			if ($(this).hasClass("in"))  {
			    $('ul.nivel3').slideUp();
				$(this).removeClass("in");
				$('ul.nivel2 > li > a .flecha').removeClass("rotar");
			}else {
			  	$('ul.nivel2 > li').removeClass("in");
				$('ul.nivel3').slideUp();
				$(this).addClass("in");
			  	$target.slideDown();
				$('ul.nivel2 > li > a .flecha').addClass("rotar");
			}
		});
		$('ul.nivel3>li').on('click', function(event) {
			event.stopPropagation();
		});
	}
}



$(document).ready(function() {

	$('#owl-carousel1').on('initialized.owl.carousel changed.owl.carousel', function(e) {
    if (!e.namespace)  {
     	return;
    }
    var carousel = e.relatedTarget;
    $('.slider-counter').html( '<b class="slidPag">' + (carousel.relative(carousel.current()) + 1) + '</b> de ' + carousel.items().length);
	}).owlCarousel({
	    loop:false,
		margin:10,
		nav:true,
		items: 1,
		dots: false,
	});
});

$('.btnH1').click(function(){
	$('.btnCont1').css("display", "block");
	$('.contH').css("display","none");
});
$('.back1').click(function(){
	$('.contH').css("display","block");
	$('.btnCont1').css("display", "none");
});

$('.btnH2').click(function(){
	$('.btnCont2').css("display", "block");
	$('.contH').css("display","none");
});
$('.back2').click(function(){
	$('.contH').css("display","block");
	$('.btnCont2').css("display", "none");
});

$('.btnH3').click(function(){
	$('.btnCont3').css("display", "block");
	$('.contH').css("display","none");
});
$('.back3').click(function(){
	$('.contH').css("display","block");
	$('.btnCont3').css("display", "none");
});

var toggle = document.getElementById('container');
var toggleContainer = document.getElementById('toggle-container');
var toggleNumber;
toggle.addEventListener('click', function() {
  toggleNumber = !toggleNumber;
  if (toggleNumber) {
    toggleContainer.style.clip = 'rect(0px, 78px, 26px, 40px)';
    toggleContainer.style.backgroundColor = '#40af29';
  } else {
    toggleContainer.style.clip = 'rect(0px, 40px, 26px, 0px)';
    toggleContainer.style.backgroundColor = '#40af29';
  }
  console.log(toggleNumber)
});




