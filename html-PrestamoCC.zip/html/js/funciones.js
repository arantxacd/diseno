angular.module('app', [])

.controller('validarForm', ['$scope', function($scope) {
    $scope.tab = 1;

    $scope.setTab = function(newTab){
      $scope.tab = newTab;
    };

    $scope.isSet = function(tabNum){
      return $scope.tab === tabNum;
    };
	
  }])
.controller('tabs', ['$scope', function($scope) {
    $scope.tab1 = 1;

    $scope.setTab1 = function(newTab1){
      $scope.tab1 = newTab1;
    };

    $scope.isSet1 = function(tabNum1){
      return $scope.tab1 === tabNum1;
    };
	
  }]);


//Tooltip
(function() {

  function getOffset(elem) {
    var offsetLeft = 0, offsetTop = 0;
    do {
      if ( !isNaN( elem.offsetLeft ) )
      {
        offsetLeft += elem.offsetLeft;
        offsetTop += elem.offsetTop;
      }
    } while( elem = elem.offsetParent );
    return {left: offsetLeft, top: offsetTop};
  }

  var targets = document.querySelectorAll( '[rel=tooltip]' ),
  target  = false,
  tooltip = false,
  title   = false,
  tip     = false;

  for(var i = 0; i < targets.length; i++) {
    targets[i].addEventListener("mouseenter", function() {
      target  = this;
      tip     = target.getAttribute("title");
      tooltip = document.createElement("div");
      tooltip.id = "tooltip";

      if(!tip || tip == "")
      return false;

      target.removeAttribute("title");
      tooltip.style.opacity = 0;
      tooltip.innerHTML = tip;
      document.body.appendChild(tooltip);

      var init_tooltip = function()
      {
        console.log(getOffset(target));
        // set width of tooltip to half of window width
        if(window.innerWidth < tooltip.offsetWidth * 1.5)
        tooltip.style.maxWidth = window.innerWidth / 2;
        else
        tooltip.style.maxWidth = 340;

        var pos_left = getOffset(target).left + (target.offsetWidth / 2) - (tooltip.offsetWidth / 2),
        pos_top  = getOffset(target).top - tooltip.offsetHeight - 10;
        console.log("top is", pos_top);
        if( pos_left < 0 )
        {
          pos_left = getOffset(target).left + target.offsetWidth / 2 - 20;
          tooltip.classList.add("left");
        }
        else
        tooltip.classList.remove("left");

        if( pos_left + tooltip.offsetWidth > window.innerWidth )
        {
          pos_left = getOffset(target).left - tooltip.offsetWidth + target.offsetWidth / 2 + 20;
          tooltip.classList.add("right");
        }
        else
        tooltip.classList.remove("right");

        if( pos_top < 0 )
        {
          var pos_top  = getOffset(target).top + target.offsetHeight + 15;
          tooltip.classList.add("top");
        }
        else
        tooltip.classList.remove("top");
        // adding "px" is very important
        tooltip.style.left = pos_left + "px";
        tooltip.style.top = pos_top + "px";
        tooltip.style.opacity  = 1;
      };

      init_tooltip();
      window.addEventListener("resize", init_tooltip);

      var remove_tooltip = function() {
        tooltip.style.opacity  = 0;
        document.querySelector("#tooltip") && document.body.removeChild(document.querySelector("#tooltip"));
        target.setAttribute("title", tip );
      };

      target.addEventListener("mouseleave", remove_tooltip );
      tooltip.addEventListener("click", remove_tooltip );
    });
  }

})();

//Calendario
	$.datepicker.regional['es'] = {
		 closeText: 'Cerrar',
		 prevText: '',
		 nextText: ' ',
		 currentText: 'Hoy',
		 monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
		 monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
		 dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
		 dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
		 dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
		 weekHeader: 'Sm',
		 dateFormat: 'dd/mm/yy',
		 firstDay: 1,
		 isRTL: false,
		 showMonthAfterYear: false,
		 yearSuffix: ''
	 };
	$.datepicker.setDefaults($.datepicker.regional['es']);
	$(function() {
		$( "#datepicker" ).datepicker({
			firstDay: 1 
		});
	});

$(document).ready(function() {
	//Modal resolución
	$('.modal01_view').click(function (e) {
		$('#modal01').modal();
		return false;
	})
	
	$('.modal02_view').click(function (e) {
		$('#modal02').modal();
		return false;
	})
	
	$('.modalEjemplo_view').click(function (e) {
		$('#modalEjemplo').modal();
		return false;
	})
	
	$('#modalCarga_view').click(function(e) {
		setTimeout(function() {
			$('#modalCarga').modal({
			});
			return false;
		}, 1);
	})

	$('.modalCerrarFolio_view').click(function(e) {
		setTimeout(function() {
			$('#modalCerrarFolio').modal({
			});
			return false;
		}, 1);
	})

	// Menu hambuergesa
	$("#effect").toggle(false);
	$("#hamburger").click(function (event) {
		event.stopPropagation();
		 $( "#effect" ).toggle( "slide"); 
	});

	$(document).click(function() {
		$("#effect").toggle(false);
	});
	$("#effect").click (function (event){
		event.stopPropagation();
	}); 

	/*Menu User*/
	$(".MenuUser, .MenuUser1").hide();
	$('.imgShowMenuUser').click(function() {
		$(".MenuUser, .MenuUser1").toggle("ver");
	});

	$(".divRC").hide();
	$('#radioResCivil').on( "change", function() {
				$(".divRC").show();
			});
	$('#radioEmpre').on( "change", function() {
		$(".divRC").hide();
	});
	
	// Menu seguimiento
	$("#seguimiento").toggle(true);
	
	$(".hamburgerSeg").click(function (event) {
		event.stopPropagation();
		 $( ".seguimiento" ).toggle( "slide"); 
	});

	$(document).click(function() {
		$(".seguimiento").toggle(false);
	});
	$(".seguimiento").click (function (event){
		event.stopPropagation();
	});
	/********Para selects*******************/
	$( "select").dropkick({
		mobile: true
	});	
	
	$('.switch').click(function(){
		$(this).toggleClass("switchOn");
	}); 
	
	$( ".cerrarChip" ).click(function() {
	   $(this).parent().parent().remove()
	});

});
//Validacion login
$(".txtRojo").hide();
function validaLogin(f) {
	if(f.txtUsuario.value == "")  
  	{	
	  $(".txtRojo").html('Por favor ingrese su usuario');
	  return false;
  	}else
	if(f.txtLlave.value == "" )
  	{
	  $(".txtRojo").html('Por favor ingrese su contraseña');
	  return false;
  	}else
	{
		location.href="index.html";
		return false;}
}
/*Valida buscador del menu de hamburgesa*/
function valida(f) {
	if (f.busca.value == "")  {
		alert("Es necesario que introduzca un valor");
	}else { 
		return false;
	}
}
/*Detecta resolucion de pantalla*/
if (matchMedia) {
  const mq = window.matchMedia("(min-width: 780px)");
  mq.addListener(WidthChange);
  WidthChange(mq);
}
function WidthChange(mq) {
	if (mq.matches) {
	  	$("#menu ul").addClass("normal");
	  	$("#menu ul li").removeClass("in");
		$('ul.nivel1 >li > ul').slideUp();
		$('ul.nivel2 >li > ul').slideUp();
		$('ul.nivel1>li').off("click");
		$('ul.nivel2>li').off("click");
	} else {
	   $("#menu ul").removeClass("normal");

		$('ul.nivel1>li').on('click', function(event) {
			event.stopPropagation();
			
			$target = $(this).children();

			if ($(this).hasClass("in"))  {
			    $('ul.nivel2').slideUp();

				$(this).removeClass("in");
				$('.flecha').removeClass("rotar");
			}else {
			  	$('ul.nivel1 > li').removeClass("in");
				$('ul.nivel2').slideUp();
				$('ul.nivel3').slideUp();
				$('ul.nivel2>li').removeClass("in");
				$(this).addClass("in");
			  	$target.slideDown();
				$('ul.nivel1 > li > a .flecha').addClass("rotar");
				
			}
		});
		$('ul.nivel2>li').on('click', function(event) {
			event.stopPropagation();
		
			$target = $(this).children();

			if ($(this).hasClass("in"))  {
			    $('ul.nivel3').slideUp();
				$(this).removeClass("in");
				$('ul.nivel2 > li > a .flecha').removeClass("rotar");
			}else {
			  	$('ul.nivel2 > li').removeClass("in");
				$('ul.nivel3').slideUp();
				$(this).addClass("in");
			  	$target.slideDown();
				$('ul.nivel2 > li > a .flecha').addClass("rotar");
			}
		});
		$('ul.nivel3>li').on('click', function(event) {
			event.stopPropagation();
		});
	}
}
var allPanels = $('.accordion > dd').hide();

	jQuery('.accordion > dt').on('click', function() {
		$this = $(this);
		//the target panel content
		$target = $this.next();

		jQuery('.accordion > dt').removeClass('accordion-active');
		if ($target.hasClass("in")) {
		  $this.removeClass('accordion-active');
		  $target.slideUp();
		  $target.removeClass("in");

		} else {
		  $this.addClass('accordion-active');
		  jQuery('.accordion > dd').removeClass("in");
		  $target.addClass("in");
			$(".subSeccion").show();

		  jQuery('.accordion > dd').slideUp();
		  $target.slideDown();
		}
	});
	
	var allPanels = $('.accordionM > dd').hide();

	jQuery('.accordionM > dt').on('click', function() {
		$this = $(this);
		//the target panel content
		$target = $this.next();

		jQuery('.accordionM > dt').removeClass('accordion-active');
		if ($target.hasClass("in")) {
		  $this.removeClass('accordion-active');
		  $target.slideUp();
		  $target.removeClass("in");

		} else {
		  $this.addClass('accordion-active');
		  jQuery('.accordionM > dd').removeClass("in");
		  $target.addClass("in");
			$(".subSeccion").show();

		  jQuery('.accordionM > dd').slideUp();
		  $target.slideDown();
		}
	});
	

/* Seleccionar Checkbox*/
$("#checktodos").change(function () {$("input:checkbox.checkM").prop('checked', $(this).prop("checked"));});

// CHIP
$(".chip input[type='checkbox']").change(function(){
  if($(this).is(":checked")){
      $(this).parent().addClass("chipActive"); 
  }else{
      $(this).parent().removeClass("chipActive");  
  }
});


/*Tracking*/
$('#cierre1').hide();
$('#cierre2').hide();
$('#paso1A').hide();
$('#paso1AB').hide();
$('#paso1B').hide();
$('#paso2').hide();
$('#paso2A').hide();
$('#paso2B').hide();
$('#paso2C').hide();
$('#paso2D').hide();
$('#paso3').hide();
$('#paso4').hide();
$('#paso4A').hide();
$('#paso4B').hide();
$('#paso4C').hide();
$('#cierreInesperado').hide();

$('#paso1 .bNegativo').click(function(){
	$('#cierre1').show();
	$('#paso1').hide();
	return false;
});

$('#cierre1 .bPositivo').click(function(){
	$('#cierre1').hide();
	$('#paso1').hide();
	$('#cierre2').show();
	return false;
});

$('#cierre2 .bPositivo').click(function(){
	$('#cierre1').hide();
	$('#paso1').show();
	$('#cierre2').hide();
	return false;
});

$('#paso1 .bPositivo').click(function(){
	$('#paso1').hide();
	$('#paso1A').show();
	return false;
});

$('#paso1A .bNegativo').click(function(){
	$('#paso1').hide();
	$('#paso1A').hide();
	$('#paso1AB').show();
	return false;
});

$('#paso1AB .bNegativo').click(function(){
	$('#paso1').hide();
	$('#paso1AB').hide();
	$('#paso1B').show();
	return false;
});

$('#paso1B .bPositivo').click(function(){
	$('#paso1').hide();
	$('#paso1A').show();
	$('#paso1B').hide();
	return false;
});

$('#paso1A .bPositivo').click(function(){
	$('#paso1').hide();
	$('.paso1').removeClass("activo");
	$('.paso2').addClass("activo");
	$('#paso1A').hide();
	$('#paso2').show();
	return false;
});

$('#paso2 .bNegativo').click(function(){
	$('#paso1').hide();
	$('#paso2').hide();
	$('#paso2A').show();
	return false;
});

$('#paso2A .bPositivo').click(function(){
	$('#paso1').hide();
	$('#paso2').show();
	$('#paso2A').hide();
	return false;
});

$('#paso2 .bPositivo').click(function(){
	$('#paso1').hide();
	$('#paso2B').show();
	$('#paso2').hide();
	return false;
});

$('#paso2B .bPositivo').click(function(){
	$('#paso1').hide();
	$('#paso2B').hide();
	$('#paso2C').show();
	return false;
});

$('#paso2C .bPositivo').click(function(){
	$('#paso1').hide();
	$('#paso2C').hide();
	$('#paso2D').show();
	return false;
});

$('#paso2D .bPositivo').click(function(){
	$('.paso2').removeClass("activo");
	$('.paso3').addClass("activo");
	$('#paso1').hide();
	$('#paso2D').hide();
	$('#paso3').show();
	return false;
});

$('.divContenido1').hide();
$('.divContenido2').hide();

$('.tab1').click(function(){
	$('.divContenido2').hide();
	return false;
});

$('.tab2').click(function(){
	$('.divContenido1').hide();
	return false;
});

$('.input1').click(function(){
	$('.divContenido1').show();
	$('.divTextoM').hide();
	return false;
});

$('.btnMonto').click(function(){
	$('.btnMonto').addClass("activeM");
	$('.divContenido1').show();
	$('.divTextoM').show();
	return false;
});

$('.input2').click(function(){
	$('.divContenido1').hide();
	$('.divContenido2').show();
	$('.divTextoM').hide();
	return false;
});

$('.btnMonto2').click(function(){
	$('.btnMonto2').addClass("activeM");
	$('.divContenido2').show();
	$('.divTextoM').show();
	return false;
});

$('.divContenido2 .bPositivo').click(function(){
	$('.paso3').removeClass("activo");
	$('.paso4').addClass("activo");
	$('#paso3').hide();
	$('#paso4').show();
	return false;
});

$('.divContenido1 .bPositivo').click(function(){
	$('.paso3').removeClass("activo");
	$('.paso4').addClass("activo");
	$('#paso3').hide();
	$('#paso4').show();
	return false;
});

$('#paso4 .bPositivo').click(function(){
	$('#paso4').hide();
	$('#paso4A').show();
	return false;
});

$('#paso4A .bPositivo').click(function(){
	$('#paso4A').hide();
	$('#paso4B').show();
	return false;
});

$('#paso4 .bNegativo').click(function(){
	$('#paso4').hide();
	$('#paso4C').show();
	return false;
});

$('#paso4C .bPositivo').click(function(){
	$('.paso4').removeClass("activo");
	$('.paso3').addClass("activo");
	$('#paso4').hide();
	$('#paso4C').hide();
	$('#paso3').show();
	$('.divContenido2').hide();
	return false;
});

$('.btnCerrar').click(function(){
	$('#paso1').hide();
	$('#paso3').hide();
	$('#paso4B').hide();
	$('#cierreInesperado').show();
	return false;
});
