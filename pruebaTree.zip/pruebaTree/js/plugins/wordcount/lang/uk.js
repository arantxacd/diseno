﻿/*
 Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.html or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang('wordcount', 'uk', {
    WordCount: 'Слів:',
    WordCountRemaining: 'Слів залишилося',
    CharCount: 'Символів:',
    CharCountRemaining: 'Символів залишилося',
    CharCountWithHTML: 'Символів (включаючи HTML-розмітку):',
    CharCountWithHTMLRemaining: 'Символів (включаючи HTML-розмітку) залишилося',
    Paragraphs: 'Параграфів:',
    ParagraphsRemaining: 'Параграфів залишилося',
    pasteWarning: 'Контент не може бути вставлено, оскільки перевищує допустимий ліміт',
    Selected: 'Виділено: ',
    title: 'Статистика'
});
