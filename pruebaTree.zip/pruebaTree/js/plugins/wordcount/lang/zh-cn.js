﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'zh-cn', {
    WordCount: '词数:',
    WordCountRemaining: 'Words remaining',
    CharCount: '字符:',
    CharCountRemaining: '个剩余字符',
    CharCountWithHTML: '字符 (含HTML)',
    CharCountWithHTMLRemaining: 'Characters (with HTML) remaining',
    Paragraphs: '段落:',
    ParagraphsRemaining: 'Paragraphs remaining',
    pasteWarning: '由于上限允许,内容不能粘贴',
    Selected: '已选择: ',
    title: '统计'
});
