﻿// Romanian Translation by Bogdanov Mihail

CKEDITOR.plugins.setLang('wordcount', 'ro', {
    WordCount: 'Numar cuvinte',
    WordCountRemaining: 'Cuvinte ramase',
    CharCount: 'Numar caracter:',
    CharCountRemaining: 'Caractere ramase:',
    CharCountWithHTML: 'Numar caractere (cu HTML):',
    CharCountWithHTMLRemaining: 'Caractere (cu HTML) ramase',
    Paragraphs: 'Paragrafe:',
    ParagraphsRemaining: 'Paragrafe ramase',
    pasteWarning: 'Continutul nu poate fi adaugat deoarece este mai mare decat limita setata',
    Selected: 'Selectat:',
    title: 'Statistici'
});