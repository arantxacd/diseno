var iniciativasEstrategicasBD = [

   {
        idIniciativa: 1, 
        iniciativa: "Conoce el nuevo Visor de Estructuras.",
        secundario: "Siempre en continua mejora para ofrecerte lo mejor.",
        txtboton:   "Ir al Visor de Estructuras.",
        img:"banner.png",
    },

    {
        idIniciativa: 2, 
        iniciativa: "Facilitamos el proceso para ti con un nuevo menú",
        secundario: "--",
        txtboton:   "--",
        img:"banner2.jpg",
    },

    {
        idIniciativa: 3,
        iniciativa: "¿Ya conoces el nuevo proceso de envíos Alnova?",
        secundario: "--",
        txtboton:   "¡Prueba envíos Alnova!",
        img:"banner3.jpg",
    },
        
    {
        idIniciativa: 4, 
        iniciativa: "Estamos mejorando para ti.",
        secundario: "Estaremos fuera de servicio el día 27 de diciembre 2020.",
        txtboton:   "--",
        img:"banner4.jpg",
    },



    


];

var iniciativasEstrategicas = [...iniciativasEstrategicasBD];

$(document).ready(function(){


   

    $(".divIniciativas").on('click', ".contIniciativaAgregar",function(){
        if(iniciativasEstrategicas.length < 100){
            agregarIniciativa();
            cargarIniciativas();
            editarMapa();
        }
    });

    
  $(".wrapper").on('click', ".editar-Mapa",function(){

        editarMapa();
    });


    $('.wrapper').on("click",".cancelar-Mapa",function (e){
        cancelarCambios();
    });



    $(".guardarCambios").click(function(){
        if($(this).attr('cambios') == 1){
            guardarCambios(1); 
        }else{
            cancelarCambios();
        }

        $.modal.close();
    });

 

    $(".divIniciativas").on('click',".btnBorrar",function() {
        borrarElemento($(this).attr('tipoAccion') , $(this).attr('indice'));
    });


   $(".btnBorrarDos").click(function(){
       console.log("click");
    });

    cargarIniciativas();
});


function cargarIniciativas(){
    let divIniciativas = '';

    let index = 0;
    let contador = 0;
    for(let iniciativa of iniciativasEstrategicas){
        divIniciativas +=
        '<div class="contIniciativa" indexIniciativa="'+ index +'">'+
             '<div class="cont_anuncio">'+
                '<div class="newNumero"><b>'+ (index + 1) +'</b></div>'+
                '<button class="btnEliminar"><img src="img/cerrarRed.svg" class="btnBorrar" tipoAccion="-1" indice="'+index+'"></button>'+
                '<button class="confirmaElimacion">Eliminar Modal</button>'+
                '<div class="img_anuncio"><img indice="'+ index +'" src="img/'+  iniciativa.img +'" onerror="this.onerror=null;this.src=\'img/banner.png\';"></div>'+
                '<div class="ct_btn"><div>Nuevo menú</div><div class="editar-Mapa crearModal"><img src="img/editar.svg"></div></div>'+

                '<div class="padding_anuncio">'+
                '<div class="bloqueInformacion"><b>Texto principal</b><div class="conTexto" id="txtPrincipalCarrusel" indice="'+ index +'">'+  iniciativa.iniciativa +'</div></div>'+
                '<div class="bloqueInformacion"><b>Texto secundario</b><div class="conTexto" id="txtSecundarioCarrusel " indice="'+ index +'">'+ iniciativa.secundario +'</div></div>'+
                '<div class="bloqueInformacion"><b>Texto del botón</b><div  class="conTexto" id="txtBotonCarrusel"  indice="'+ index +'">'+  iniciativa.txtboton +'</div></div>'+
                '</div>'+
            '</div>'+


            '<div id="eliminarAnuncio" class="modal contador'+(contador + 1)+'">'+
                '<div class="tituloModal">'+
                    '<div><b>Eliminar anuncio2</b></div>'+
                '</div>'+

                '<div class="pmodal">'+
                    '<button><img src="img/cerrarRed.svg" class="btnBorrarDos" tipoAccion="-1" indice="'+index+'">asdasdasd</button>'+
                    '<div class="textModal"> ¿Deseas eliminar el anuncio <b>Visor de Estructura</b>? <b>Esta acción no puede deshacerse.</b></div>'+
                    '<div class="boxBotones tpModal">'+
                        '<button class="btn gris_oscuro"  onclick="cerrarModal()">No, conservar</button>'+
                        '<button class="btn eliminar_esteAnuncio">Si, eliminar</button>'+
                    '</div>'+ '<br>'+
                '</div>'+
            '</div>'+




        '</div>';



      


  

        index++;
       

      
    }

    divIniciativas += '<div class="contIniciativa contIniciativaAgregar">'+ 
                      '<img src="img/agregarAnuncio.svg"><br><div>Nuevo anuncio</div>'+
                       '</div>';

   

    $(".divIniciativas").html(divIniciativas);
    $('.contIniciativa, .orcCard ,.conten-mv').css('cursor', 'unset');
    $('.contIniciativa, .orcCard ,.conten-mv').css('padding', '10px');
    
    if(iniciativasEstrategicas.length >= 100){
        $(".contIniciativaAgregar").remove();
    }



    $(".confirmaElimacion").click(function() {
        var id = $(".confirmaElimacion").val();
        $('#eliminarAnuncio').modal('show');
    });

   

    $(".eliminar_esteAnuncio").click(function() {
        var button = $(this);
        var id = button.val();
        button.closest(".modal").modal('hide');
        $('#auncioEliminado' + id).modal('show');
    });

   

     

    // $(".crearModal").click(function() {
    //     var id = $(".crearModal").val();
    //     $('#ex1').modal('show');
    // });

    // $(".crearModal").click(function() {
    //     var id = $(".crearModal").val();
    //     $('#ex1').modal('show');
    // });



}

function editarMapa(){
    
    $('.contIniciativa, .orcCard ,.conten-mv').css('cursor', 'grab');
    $(".divIniciativas").sortable({
        placeholder: "ui-state-highlight-iniciativa",
        cancel: '.divIniciativas > .contIniciativaAgregar',
        cancel: '.conTexto',
        cursor: "move",
        stop: function(event, ui){
            let nuevoOrden =  [];
            let datos = $(".divIniciativas").sortable("toArray", {attribute: 'indexIniciativa'});

            datos.forEach(obj => {
                if(obj != ''){
                    nuevoOrden.push(iniciativasEstrategicas[obj]);
                }
            });

            iniciativasEstrategicas = JSON.parse(JSON.stringify(nuevoOrden));
            cargarIniciativas();
            editarMapa();

            $(this).children().each(function(){
                if($(this).hasClass('contIniciativaAgregar')){
                    $(this).remove();
                    $('.divIniciativas').append('<div class="contIniciativa contIniciativaAgregar">'+
                            '<img src="img/agregarAnuncio.svg"><br><div>Nuevo anuncio</div>'+
                    '</div>');
                    


                }
            });
        }
    }).disableSelection();

    $('.connectedSortable').each(function(index, obj){
        $(this).sortable({
            connectWith: ".connectedSortable",
            placeholder: "ui-state-highlight-objetivo",
            cancel: '.connectedSortable > .agObj',
            cursor: "move",
            stop: function(){

                let clonIniciativa = JSON.parse(JSON.stringify(iniciativasEstrategicas));
                
                $('.connectedSortable').each(function(index, obj){
                    var dragDatos = $(this).sortable("toArray", {attribute: 'indexObjetivo'});
                    clonIniciativa[index].objetivos = [];

                    if(dragDatos.length > 1){
                        for(let dato of dragDatos){
                            let indexIniciativa = dato.split('|')[0];
                            let indexObjetivo = dato.split('|')[1]; 

                            if(indexObjetivo){
                                clonIniciativa[index].objetivos.push(iniciativasEstrategicas[indexIniciativa].objetivos[indexObjetivo])
                            }
                        }
                    }
                });

                iniciativasEstrategicas = JSON.parse(JSON.stringify(clonIniciativa));
                cargarIniciativas();
                editarMapa();
            }
        }).disableSelection();
    });

    $(".divQuotes").sortable({
        placeholder: "ui-state-highlight-quote",
        cursor: "move"
    }).disableSelection();
}

function agregarIniciativa(){
    iniciativasEstrategicas.push({
            idIniciativa: iniciativasEstrategicas.length + 1,
            iniciativa: "",
            objetivos: []
    });
}

function borrarElemento(tipoBorrado, indiceElemento){
    if(tipoBorrado == -1){
        iniciativasEstrategicas.splice(+indiceElemento, 1);
        console.log("borado");
    }else{
        //iniciativasEstrategicas[tipoBorrado].objetivos.splice(+indiceElemento, 1);
    }

    cargarIniciativas();
    editarMapa();
}

function guardarCambios(accion){
    if(accion == 1){
        iniciativasEstrategicasBD = [...iniciativasEstrategicas];
    }else{
        iniciativasEstrategicas = [...iniciativasEstrategicasBD];
    }

    cargarIniciativas();
}

function cancelarCambios() {
    $('.contIniciativa, .orcCard ,.conten-mv').css('cursor', 'unset');

    guardarCambios(0);
}



$( "#droppable" ).droppable({
    hoverClass: "ui-state-active",
    drop: function( event, ui ) {
        $( this )
            .addClass( "ui-state-highlight" )
            .find( "p" )
                .html( "Dropped!" );
    }
});






