var iniciativasEstrategicasBD = [

   {
        idIniciativa: 1, 
        iniciativa: "Conoce el nuevo Visor de Estructuras.",
        secundario: "Siempre en continua mejora para ofrecerte lo mejor.",
        txtboton:   "Ir al Visor de Estructuras.",
        img:"banner.png",
        avance: 80,
        objetivos: [
            {
                idObjetivo: 1,
                objetivo: "Construir una fuerza de ventas en geografía, completa, equipada, capacitada, motivada y evaluada, para ofrecer y entregar con calidad productos y servicios a nuestros clientes",
                responsables: 4,
                involucrados: 0,
                avanceObjetivo: 100,
                avanceColor: "verde",
                resultadosClave: []
                   
                
            },
            {
                idObjetivo: 1,
                objetivo: "Habilitar espacios físicos y herramientas para el desempeño de las actividades de ahorro y negocios de comisión",
                responsables: 2,
                involucrados: 0,
                avanceObjetivo:100,
                avanceColor: "verde",
                resultadosClave: []
            }
        ]
    },

    {
        idIniciativa: 2, 
        iniciativa: "Facilitamos el proceso para ti con un nuevo menú",
        secundario: "--",
        txtboton:   "--",
        img:"banner2.jpg",
        objetivos: [
                {
                    idObjetivo: 1,
                    objetivo: "Desarrollar nueva experiencia física y digital de usuario en ATM para mejorar la satisfacción del cliente",
                    responsables: 3,
                    involucrados: 0, 
                    avanceObjetivo: 90,
                    avanceColor: "amarillo",
                    resultadosClave: [
                        {
                            idResultado: 1,
                            avanceResultado:85,
                            color: 'rojo',
                            resultado: "Diseñar y construir físicamente nuevo..."
                        },
                        {
                            idResultado: 2,
                            avanceResultado:85,
                            color: 'rojo',
                            resultado: 'Construir la nueva experiencia funcio..."'
                        },
                        {
                            idResultado: 3,
                            avanceResultado: 100,
                            color: 'verde',
                            resultado: "Construir el RFP del Diseño del NOC/S..."
                        },
                       
                    ]
               },
               {
                    idObjetivo: 1,
                    objetivo: "En Negocios de comisión, ofrecer los productos y servicios financieros más sencillos, confiables y seguros, para impulsar la bancarización en el país",
                    responsables: 2,
                    involucrados: 0, 
                    avanceObjetivo:89,
                    avanceColor: "rojo",
                    resultadosClave:[]
               },
               {
                    idObjetivo: 1,
                    objetivo: "En Captación, ofrecer los productos y servicios financieros más sencillos, confiables y seguros, para impulsar la bancarización en el país",
                    responsables: 4,
                    involucrados: 0, 
                    avanceObjetivo:100,
                    avanceColor: "verde",
                    resultadosClave: []
               }
            ]
        },

    {
        idIniciativa: 3,
        iniciativa: "¿Ya conoces el nuevo proceso de envíos Alnova?",
        secundario: "--",
        txtboton:   "¡Prueba envíos Alnova!",
        img:"banner3.jpg",
        objetivos: [
            {
                idObjetivo: 1,
                objetivo: "Instalar ATM's urgentes para mejorar la experiencia de cliente y migrar transacciones de caja humana",
                responsables: 1,
                involucrados: 0, 
                avanceObjetivo:97,
                avanceColor: "amarillo",
                resultadosClave: [
                    {
                        idResultado: 1,
                        avanceResultado:91.37,
                        color: 'naranja',
                        resultado: "Pasar de 32.66M a 48.64M transacciones"
                    },
                    {
                        idResultado: 2,
                        avanceResultado:100,
                        color: 'verde',
                        resultado: 'Mantener el 98% de uptime de la nueva...'
                    },
                    {
                        idResultado: 3,
                        avanceResultado:111.91,
                        color: 'verde',
                        resultado: "Crecer la red de 856 a 1,335 ATMs"
                    },
                    {
                        idResultado: 4,
                        avanceResultado: 129.41,
                        color: 'verde',
                        resultado: "Incrementar el porcentaje de txn migr..."
                    },
                   
                ]
            },
            {
                idObjetivo: 1,
                objetivo: "Ejecutar plan anticolas de Cajas para ofrecer servicio de calidad",
                responsables: 2,
                involucrados: 0,
                avanceObjetivo:67,
                avanceColor: "rojo",
                resultadosClave: [
                    {
                        idResultado: 1,
                        avanceResultado:0,
                        color: 'rojo',
                        resultado: "CAJAS Y ATMS'S: IPN de 34% a 54%"
                    },
                    {
                        idResultado: 2,
                        avanceResultado: 79.08,
                        color: 'rojo',
                        resultado: 'Pasar de 180 a 1,568 de sucursales co...'
                    },
                    {
                        idResultado: 3,
                        avanceResultado: 96.84,
                        color: 'naranja',
                        resultado: "En el Camino para Atender Mejor pasar..."
                    },
                    {
                        idResultado: 4,
                        avanceResultado:115,
                        color: 'verde',
                        resultado: "Tiempo por transacción promedio en ca..."
                    },
                    {
                        idResultado: 5,
                        avanceResultado:108.84,
                        color: 'verde',
                        resultado: "Pasar de 32% a 52% en el IPN de Cajas..."
                    },
                    {
                        idResultado: 5,
                        avanceResultado:134.48,
                        color: 'verde',
                        resultado: "Implementación de Módulos de Caja Móv..."
                    }
                ]
            },
            {
                idObjetivo: 1,
                objetivo: "Asegurar el servicio y los controles adecuados en los formatos de caja.",
                responsables: 0,
                involucrados: 0,
                avanceObjetivo: 95,
                avanceColor: "amarillo",
                resultadosClave: [
                    {
                        idResultado: 1,
                        avanceResultado:96.84,
                        color: 'naranja',
                        resultado: "Incrementar de 80% a 95% de cumplimie..."
                    },
                    {
                        idResultado: 0,
                        avanceResultado:97,
                        color: 'amarillo',
                        resultado: 'Incrementar de 90% a 100% Cajas abier...'
                    },
                    {
                        idResultado: 3,
                        avanceResultado:95.19,
                        color: 'amarillo',
                        resultado: "Disminuir el faltante promedio de Caj..."
                    },
                   
                ]
            },
            {
                idObjetivo: 1,
                objetivo: "Generar relaciones a largo plazo con nuestros clientes para aumentar la rentabilidad de Negocios de Comisión",
                responsables: 4,
                involucrados: 0,
                avanceObjetivo: 26,
                avanceColor: "rojo",
                resultadosClave: []
            },
            {
                idObjetivo: 1,
                objetivo: "Generar relaciones a largo plazo con nuestros clientes para aumentar la rentabilidad en Captación",
                responsables: 2,
                involucrados: 0,
                avanceObjetivo: 100,
                avanceColor: "verde",
                resultadosClave: []
            },
            {
                idObjetivo: 1,
                objetivo: "Ampliar red de pagos externa con agentes y corresponsales para acercar los servicios financieros a clientes",
                responsables: 2,
                involucrados: 0,
                avanceObjetivo:75,
                avanceColor: "rojo",
                resultadosClave: [
                    {
                        idResultado: 1,
                        avanceResultado: 100,
                        color: 'rojo',
                        resultado: "Incrementar de 1 a 4 corresponsales"
                    },
                    {
                        idResultado: 2,
                        avanceResultado: 93.48,
                        color: 'naranja',
                        resultado: 'Incrementar de 5.6M a 7.9M transaccio...'
                    },
                    {
                        idResultado: 3,
                        avanceResultado: 111.46,
                        color: 'verde',
                        resultado: "Crecer red de agentes de 9.4k a 13k p..."
                    },
                   
                ]
            }
        ]
    },
        
    {
        idIniciativa: 4, 
        iniciativa: "Estamos mejorando para ti.",
         secundario: "Estaremos fuera de servicio el día 27 de diciembre 2020.",
        txtboton:   "--",
        img:"banner4.jpg",
        avance: 80,
        objetivos: [
            {
                idObjetivo: 1,
                objetivo: "Convertir Adquirente en una ventaja competitiva para los negocios del grupo, hacerlo rentable y sustentable",
                responsables: 2,
                involucrados: 0,
                avanceObjetivo: 54,
                avanceColor: "rojo",
                resultadosClave: [
                    {
                        idResultado: 1,
                        avanceResultado:34.31,
                        color: 'rojo',
                        resultado: "Pasar de 0 a 75,000 Acepta Pago coloc..."
                    },
                    {
                        idResultado: 2,
                        avanceResultado:72.5,
                        color: 'rojo',
                        resultado: "Incrementar la contribución de 0 MDP ..."
                    },
                   
                ]
            },
            {
                idObjetivo: 1,
                objetivo: "Incrementar transacciones en los formatos de caja para rentabilizar la Unidad de Negocio de forma sostenida a largo plazo",
                responsables: 2,
                involucrados: 0,
                avanceObjetivo: 100,
                avanceColor: "verde",
                resultadosClave: []
                  
                
            },
            {
                idObjetivo: 1,
                objetivo: "Crecer las operaciones de Divisas, logrando la rentabilidad esperada a largo plazo y de forma sostenida",
                responsables: 5,
                involucrados: 0,
                avanceObjetivo: 100,
                avanceColor: "verde",
                resultadosClave: [
                    {
                        idResultado: 1,
                        avanceResultado:37.06,
                        color: 'rojo',
                        resultado: "Incrementar el monto operado de $1,15..."
                    },
                    {
                        idResultado: 2,
                        avanceResultado:38.83,
                        color: 'rojo',
                        resultado: "Ingreso de $1,236 a $1,478 MDP (+20% ..."
                    },
                    {
                        idResultado: 3,
                        avanceResultado:104.62,
                        color: 'verde',
                        resultado: "Incrementar el spread ponderado de 1...."
                    }
                ]
            },
            {
                idObjetivo: 1,
                objetivo: "Crecer las operaciones de Dinero Express, logrando la rentabilidad esperada a largo plazo y de forma sostenida",
                responsables: 4,
                involucrados: 0,
                avanceObjetivo: 35,
                avanceColor: "rojo",
                resultadosClave: [
                    {
                        idResultado: 1,
                        avanceResultado: 50,
                        color: 'rojo',
                        resultado: "De 7 a 8 campañas de promoción para n..."
                    },
                    {
                        idResultado: 2,
                        avanceResultado:0,
                        color: 'rojo',
                        resultado: "Lanzamiento del Wallet como la evoluc..."
                    },
                    {
                        idResultado: 3,
                        avanceResultado:10.01,
                        color: 'rojo',
                        resultado: "De 72k a 609K transacciones B2P (disp..."
                    },

                    {
                        idResultado: 3,
                        avanceResultado:36.58,
                        color: 'rojo',
                        resultado: "Ingreso de $557 a $585 MDP (5% vs AA)"
                    },
                    {
                        idResultado: 3,
                        avanceResultado:41.11,
                        color: 'rojo',
                        resultado: "De 425K a 518K transacciones de outbo..."
                    }
                ]
            },
            {
                idObjetivo: 1,
                objetivo: "Crecer las operaciones de Transferencias Internacionales, logrando la rentabilidad esperada a largo plazo y de forma sostenida",
                responsables: 5,
                involucrados: 0,
                avanceObjetivo:34,
                avanceColor: "rojo",
                resultadosClave: []
            },
            {
                idObjetivo: 1,
                objetivo: "Crecer el portafolio de Captación, logrando la rentabilidad esperada a largo plazo y de forma sostenida",
                responsables: 3,
                involucrados: 0,
                avanceObjetivo: 30,
                avanceColor: "rojo",
                resultadosClave: []
                   
                
            }
        ]
    },

    


];

var iniciativasEstrategicas = [...iniciativasEstrategicasBD];

var quotes = [
    {
        titulo: 'Visión',
        texto: 'Ser el ejemplo mundial, reconocido como el líder en el mercado mexicano en servicios de tecnologías de información, telecomunicaciones y entretenimiento digital, a través de ser la empresa más innovadora y que exceda las expectativas cambiantes de nuestros clientes y equipo de colaboradores.'
    },
    {
        titulo: 'Misión',
        texto: 'Conectar a la mayoría de los hogares y PYMES a través de servicios innovadores de telecomunicaciones, entretenimiento y tecnología para mejorar permanentemente la experiencia de vida de las personas y la productividad de los negocios.'
    }
];

var objetivosDisponibles = [
    {
        idObjetivo: 1,
        objetivo: "Maximizar la penetración del mercado incrementando el valor y tiempo de vida del cliente.",
        responsables: 1,
        involucrados: 2,
        avanceObjetivo: 90,
        resultadosClave: [
            {
                idResultado: 1,
                avanceResultado: 30,
                color: 'verde',
                resultado: "Eliminar Clientes Perdidos, Aumentand..."
            },
            {
                idResultado: 2,
                avanceResultado: 30,
                color: 'rojo',
                resultado: 'Instalar nuevos clientes "Buenos Pagad..."'
            },
            {
                idResultado: 3,
                avanceResultado: 30,
                color: 'amarillo',
                resultado: "Ser la marca más reconocida y querida..."
            },
            {
                idResultado: 4,
                avanceResultado: 30,
                color: 'amarillo',
                resultado: "Tener Clientes de Alto Valor, mantenien..."
            },
            {
                idResultado: 5,
                avanceResultado: 30,
                color: 'verde',
                resultado: "Generar un Sistema de Información que..."
            }
        ]
    },
    {
        idObjetivo: 2,
        objetivo: "Ser la solución mas innovadora en el merdaco recidencia de Telecomunicaciones.",
        responsables: 2,
        involucrados: 6,
        avanceObjetivo: 90,
        resultadosClave: [
            {
                idResultado: 1,
                avanceResultado: 30,
                color: 'verde',
                resultado: "Mejorar el contenido disponible adicion..."
            },
            {
                idResultado: 2,
                avanceResultado: 30,
                color: 'verde',
                resultado: "Incluir nueva tecnología en los decodific..."
            },
            {
                idResultado: 3,
                avanceResultado: 30,
                color: 'verde',
                resultado: "Desarrollar una nueva unidad de negoci..."
            }
        ]
    }
];

$(document).ready(function(){
    var numero = 5;
    var numeroDos = 4;
    var numeroTres = 1;
    var numeroCuatro = 1;
    var numeroCinco = 1;
    
    $(".editar-Mapa").click(function(){
        $(".btAgregar").addClass("mas-visible");
    });

    $(".divIniciativas").on('click', ".contIniciativaAgregar",function(){
        if(iniciativasEstrategicas.length < 5){
            agregarIniciativa();
            cargarIniciativas();
            editarMapa();
        }
    });

    $(".agObj").click(function(){
        if(numeroTres < 3 ){
            $(".agObj").before();
            numeroTres++;
        }

        if(numeroTres == 3){
            $(".btAgregar").css({"display":"none"});
        }
    });

    $(".agObjDos").click(function(){
        if(numeroCuatro < 3 ){
            $(".agObjDos").before();
            numeroCuatro ++;
        }

        if(numeroCuatro == 3){
            $(".btAgregar").css({"display":"none"});
        }
    });

    $(".agObjTres").click(function(){
        if(numeroCinco < 3){
            $(".agObjTres").before();
            numeroCinco++;
        }

        if(numeroCinco == 3){
            $(".btAgregar").css({"display":"none"});
        }
    });

    $(".editar-Mapa").click(function(){
        editarMapa();
    });

    $('.contGeneral').on("click",".cancelar-Mapa",function (e){
        cancelarCambios();
    });


    $('#avisoGuardar').on("click",".cancelar-MapaDos",function (e){
        cancelarCambios();
    });


    $( "button" ).click(function() {
        $( "p" ).remove();
    });
      
    $('.avisoGuardar_view').click(function(){
        $('#avisoGuardar').modal();
    });

    $(".guardarCambios").click(function(){
        if($(this).attr('cambios') == 1){
            $(".cancelar-Mapa, .guardar-Mapa").css({"display":"none"});
            $('.instrucciones, .btAgregar, .msNew').css({"display":"none"});
            $('.btnBorrar, .btnBorrarTarjeta').css({"display":"none"});
            $(".editar-Mapa").css({"display":"inline-block"});
            $('.bannerAlerta').removeClass("bannerActive");
            $('.texto-area').removeClass("editar-inst");
            $('.texto-area').attr("disabled");
            $('.tb-box').removeClass("extiende");
            $('.v-mide, .v-bottom').css({"vertical-align":"top"});
            $('.v-mide, .v-bottom').css({"vertical-align":"top"});

 
    
            guardarCambios(1); 
        }else{
            cancelarCambios();
        }

        $.modal.close();
    });

    var langArray = [];
    $('.vodiapicker option').each(function(){
        var img = $(this).attr("data-thumbnail");
        var text = this.innerText;
        var value = $(this).val();
        var item = '<li><img src="'+ img +'" alt="" value="'+value+'"/><span>'+ text +'</span></li>';
        langArray.push(item);
    })

    $('#a').html(langArray);

    $('.btn-select').html(langArray[0]);

    $('.btn-select').attr('value', 'en');

    $('#a li').click(function(){
        var img = $(this).find('img').attr("src");
        var value = $(this).find('img').attr('value');
        var text = this.innerText;
        var item = '<li><img src="'+ img +'" alt="" /><span>'+ text +'</span></li>';
        $('.btn-select').html(item);
        $('.btn-select').attr('value', value);
        $(".b").toggle();
    });

    $(".btn-select").click(function(){
        $(".b").toggle();
    });

    var sessionLang = localStorage.getItem('lang');
    if (sessionLang){
        var langIndex = langArray.indexOf(sessionLang);
        $('.btn-select').html(langArray[langIndex]);
        $('.btn-select').attr('value', sessionLang);
    } else {
        var langIndex = langArray.indexOf('ch');
        $('.btn-select').html(langArray[langIndex]);
    }

    $(".divIniciativas").on('click',".btnBorrar",function() {
        borrarElemento($(this).attr('tipoAccion') , $(this).attr('indice'));
    });

    $(".menu").click(function() {
        $(".secmenu").toggleClass("mfijo");
        $(".menu").toggleClass("hams");
    });

    $(".m-oculto").click(function() {
        $(".secmenu").removeClass("mfijo");
    });

    $('.contGeneral').on("click",".editar-Mapa",function (e){ 
        $('.texto-area').prop("disabled", false);
    });
    
    $('.contGeneral').on("click",".cancelar-Mapa",function (e){ 
        $('.texto-area').prop("disabled", true);
    });
    
    $(".guardarCambios").click(function(){
        $('.texto-area').prop("disabled", true);
    });
    
    $(".no-guardar").click(function(){
        $('.texto-area').prop("disabled", false);
    });
    
    //Quotes
    cargarQuotes();
  
    //Iniciativas
    $('.divIniciativas').on('click', '.alinear_view', function (e) {  
        $('.cerrarModalObjetivo').attr('iniciativa', $(this).attr('iniciativa'));
        $('#alinear').modal();
        filtrarObjetivos();
    });

    $('.divIniciativas').on('blur', '.conTexto', function (e){
        iniciativasEstrategicas[+$(this).attr('indice')].iniciativa = $(this).val();
    });

    $('.cerrarModalObjetivo').click(function(){
        let objetivoSeleccionado = objetivosDisponibles.filter(obj => obj.objetivo == $("#tags").val())[0];

        if(objetivoSeleccionado){
            iniciativasEstrategicas[+$(this).attr('iniciativa')].objetivos.push(objetivoSeleccionado);
            cargarIniciativas();
            editarMapa();
        }

        $.modal.close();
    });

    cargarIniciativas();
});

//Iniciativas Estrategicas
function filtrarObjetivos(){
    let listadoObjetivos = [];

    for(let objetivo of objetivosDisponibles){
        listadoObjetivos.push(objetivo.objetivo);
    }

    $("#tags").autocomplete({
        source: listadoObjetivos,
        appendTo: '#alinear'
    });
}

function cargarIniciativas(){
    let divIniciativas = '';

    let index = 0;
    for(let iniciativa of iniciativasEstrategicas){
        divIniciativas +=

 

        // '<div class="cont_anuncio">'+
        //     '<div class="newNumero"><b>'+ (index + 1) +'</b></div>'+
        //     '<button class="btnEliminar"><img src="img/cerrarRed.svg"></button>'+
        //     '<div class="img_anuncio">'+
        //         '<img src="img/banner.png">'+
        //     '</div>'+

        //     '<div class="ct_btn">'+
        //         '<div>Nuevo menú</div>'+
        //         '<div><img src="img/editar.svg"></div>'+
        //     '</div>'+

        //     '<div class="padding_anuncio">'+
        //         '<b>Texto principal</b>'+
        //         '<div>Facilitamos el proceso para ti con un nuevo menú</div>'+
        //         '<div class="conTexto " indice="'+ index +'" disabled>'+ iniciativa.iniciativa +'</div>'+ 
        //     '</div>'+

        //     '<div class="bloqueInformacion">'+
        //         '<b>Texto secundario</b>'+
        //         '<div>Siempre en continua mejora para ofrecerte lo mejor.</div>'+
        //     '</div>'+

        //     '<div class="bloqueInformacion">'+
        //         '<b>Texto del botón</b>'+
        //         '<div>¡Prueba envíos Alnova!</div>'+
        //     '</div>'+
        // '<div>'+
   

        '<div class="contIniciativa" indexIniciativa="'+ index +'">'+
      
            '<div class="cont_anuncio">'+
                '<div class="newNumero"><b>'+ (index + 1) +'</b></div>'+
                '<button class="btnEliminar"><img src="img/cerrarRed.svg" class="btnBorrar" tipoAccion="-1" indice="'+index+'"></button>'+
                '<div class="img_anuncio"><img indice="'+ index +'" src="img/'+  iniciativa.img +'"></div>'+
                '<div class="ct_btn"><div>Nuevo menú</div><div class="editar-Mapa"><img src="img/editar.svg"></div></div>'+

                '<div class="padding_anuncio">'+
                '<div class="bloqueInformacion"><b>Texto principal</b><div  class="conTexto" indice="'+ index +'">'+  iniciativa.iniciativa +'</div></div>'+
                '<div class="bloqueInformacion"><b>Texto secundario</b><div class="conTexto" indice="'+ index +'">'+ iniciativa.secundario +'</div></div>'+
                '<div class="bloqueInformacion"><b>Texto del botón</b><div  class="conTexto" indice="'+ index +'">'+  iniciativa.txtboton +'</div></div>'+
        

                '</div>'+
               
        

      


            '</div>'+


            '<div class="btnIniciativa">' +
                '<div class="icoSortable"></div>'+ 
                '<div class="tb-estrategica">'+
                    '<div class="cell-estrategica"><b>'+ (index + 1) +'</b></div>'+
                '</div>'+
                '<textarea class="conTexto " indice="'+ index +'" disabled>'+ iniciativa.iniciativa +'</textarea>'+ 
        '</div>'+
            '<div class="contCapacidades connectedSortable" id="connectedSortable'+ index+'">';

                if(iniciativa.objetivos.length > 0){
                    let indexObjetivo = 0;
                    for(let objetivo of iniciativa.objetivos){
                        divIniciativas += 
                        '<div class="newObjetivo" indexObjetivo="'+  index +'|'+ indexObjetivo +'">'+
                            '<div class="newcol">'+
                                '<div class="orcCard">'+ 
                                '<div class="icoSortable"></div>'+  
                                    '<img src="img/delete_objetivo.svg" class="btnBorrar" tipoAccion="'+ index +'" indice="'+ indexObjetivo +'">'+
                                    '<a href="ver-objetivo.html" class="orcCardTit">'+ 
                                        '<table class="orcTable">'+
                                            '<tr>'+
                                                '<td valign=top><img src="img/objetivo/objetivo.svg" class='+ objetivo.avanceColor +'></td>'+
                                                '<td valign=top><b>'+ objetivo.objetivo +'</b></td>'+
                                                '<td valign=top><div class='+ objetivo.avanceColor +'><div>'+ objetivo.avanceObjetivo +'%</div></td>'+
                                            '</tr>'+ 
                                        '</table><br>'+ 
                                    '</a>'+ 
                                    '<div class="orcCardUsers">'+
                                        '<div><img src="img/userDefault.svg"><b>'+ objetivo.responsables +'</b></div>'+
                                        '<div><img src="img/multiUser.svg"><b>'+ objetivo.involucrados +'</b></div>'+
                                    '</div>';

                                    if(objetivo.resultadosClave.length > 0){
                                        divIniciativas +=  '<div class="datos">'+
                                            '<div class="orcList tleft">';

                                        for(let resultado of objetivo.resultadosClave){
                                            divIniciativas += '<div class="'+ resultado.color +'"><div>'+ resultado.avanceResultado +'%</div><a href="resultado-grafica.html">'+ resultado.resultado +'</a></div>';
                                        }

                                        divIniciativas += '</div>'+
                                        '</div>';
                                    }

                            divIniciativas += '</div>'+
                            '</div>'+
                        '</div>';

                        indexObjetivo++;
                    }
                }

        divIniciativas += '<div class="newObjetivo agObj msNew alinear_view" iniciativa="'+ index +'">'+
                    ' + Alinear otro objetivo '+
                '</div>'+
            '</div>'+
        '</div>';

        index++;
    }

    divIniciativas += '<div class="contIniciativa contIniciativaAgregar">'+
            ' +  Agregar iniciativa'+
    '</div>';

    $(".divIniciativas").html(divIniciativas);
    $('.contIniciativa, .orcCard ,.conten-mv').css('cursor', 'unset');
    $('.contIniciativa, .orcCard ,.conten-mv').css('padding', '10px');
    
    if(iniciativasEstrategicas.length >= 5){
        $(".contIniciativaAgregar").remove();
    }
}

function editarMapa(){
    $(".editar-Mapa").hide();
    $(".cancelar-Mapa").css({"display":"inline-block"});
    $(".guardar-Mapa").css({"display":"inline-block"});
    $('.bannerAlerta').addClass("bannerActive");
    $('.texto-area').addClass("editar-inst");
    $('.conTexto').addClass("editar-inst");
    $('.conTexto').removeAttr("disabled"); 
    $('.instrucciones').css({"display":"block"});
    $('.tb-box').addClass("extiende");
    $('.msNew, .contIniciativaAgregar').show();
    $('.v-mide').css({"vertical-align":"middle"});
    $('.v-bottom').css({"vertical-align":"bottom"});
    $('.btnBorrar, .btnBorrarTarjeta').show();
    $('.contIniciativa, .orcCard ,.conten-mv').css('cursor', 'grab');
 
    $('.btnIniciativa').addClass("paddingSortable");
    $('.orcCard').addClass("paddingOrcSortable");
    $('.icoSortable').addClass("verIcoSortable");

    $(".divIniciativas").sortable({
        placeholder: "ui-state-highlight-iniciativa",
        cancel: '.divIniciativas > .contIniciativaAgregar',
        cancel: '.conTexto',
        cursor: "move",
        stop: function(event, ui){
            let nuevoOrden =  [];
            let datos = $(".divIniciativas").sortable("toArray", {attribute: 'indexIniciativa'});

            datos.forEach(obj => {
                if(obj != ''){
                    nuevoOrden.push(iniciativasEstrategicas[obj]);
                }
            });
;
            iniciativasEstrategicas = JSON.parse(JSON.stringify(nuevoOrden));
            cargarIniciativas();
            editarMapa();

            $(this).children().each(function(){
                if($(this).hasClass('contIniciativaAgregar')){
                    $(this).remove();
                    $('.divIniciativas').append('<div class="contIniciativa contIniciativaAgregar">'+
                            ' +  Agregar iniciativa'+
                    '</div>');
                    $(".contIniciativaAgregar").show();
                }
            });
        }
    }).disableSelection();

    $('.connectedSortable').each(function(index, obj){
        $(this).sortable({
            connectWith: ".connectedSortable",
            placeholder: "ui-state-highlight-objetivo",
            cancel: '.connectedSortable > .agObj',
            cursor: "move",
            stop: function(){

                let clonIniciativa = JSON.parse(JSON.stringify(iniciativasEstrategicas));
                
                $('.connectedSortable').each(function(index, obj){
                    var dragDatos = $(this).sortable("toArray", {attribute: 'indexObjetivo'});
                    clonIniciativa[index].objetivos = [];

                    if(dragDatos.length > 1){
                        for(let dato of dragDatos){
                            let indexIniciativa = dato.split('|')[0];
                            let indexObjetivo = dato.split('|')[1]; 

                            if(indexObjetivo){
                                clonIniciativa[index].objetivos.push(iniciativasEstrategicas[indexIniciativa].objetivos[indexObjetivo])
                            }
                        }
                    }
                });

                iniciativasEstrategicas = JSON.parse(JSON.stringify(clonIniciativa));
                cargarIniciativas();
                editarMapa();
            }
        }).disableSelection();
    });

    $(".divQuotes").sortable({
        placeholder: "ui-state-highlight-quote",
        cursor: "move"
    }).disableSelection();
}

function agregarIniciativa(){
    iniciativasEstrategicas.push({
            idIniciativa: iniciativasEstrategicas.length + 1,
            iniciativa: "",
            objetivos: []
    });
}

function borrarElemento(tipoBorrado, indiceElemento){
    if(tipoBorrado == -1){
        iniciativasEstrategicas.splice(+indiceElemento, 1);
    }else{
        iniciativasEstrategicas[tipoBorrado].objetivos.splice(+indiceElemento, 1);
    }

    cargarIniciativas();
    editarMapa();
}

function guardarCambios(accion){
    if(accion == 1){
        iniciativasEstrategicasBD = [...iniciativasEstrategicas];
    }else{
        iniciativasEstrategicas = [...iniciativasEstrategicasBD];
    }

    cargarIniciativas();
}

function cancelarCambios() {
    $(".cancelar-Mapa, .guardar-Mapa").css({"display":"none"});
    $(".editar-Mapa").css({"display":"inline-block"});
    $('.bannerAlerta').removeClass("bannerActive");
    $('.texto-area').removeClass("editar-inst");
    $('.texto-area').attr("disabled");
     
    $('.instrucciones').css({"display":"none"});
    $('.btAgregar').css({"display":"none"});
    $('.tb-box').removeClass("extiende");
    $('.msNew').css({"display":"none"});
    $('.v-mide').css({"vertical-align":"top"});
    $('.v-bottom').css({"vertical-align":"top"});
    $('.btnBorrar, .btnBorrarTarjeta').css({"display":"none"});
    $('.contIniciativa, .orcCard ,.conten-mv').css('cursor', 'unset');
 
    $('.btnIniciativa').removeClass("paddingSortable");
    $('.orcCard').removeClass("paddingSortable");

    guardarCambios(0);
}

//Quotes
function cargarQuotes(){
    let index = 0;

    let txtQuotes = '';
    for(let quote of quotes){
        txtQuotes += '<div class="conten-mv">'+
        '<b class="tvision" style="font-weight: 100; font-size: 23px;  display:block; margin-bottom:20px;">' + quote.titulo + ':</b>'+
        '<div class="qVision">'+
            '<div class="instrucciones">Ahora puedes editar el campo <b>¿Cúal es la '+ quote.titulo.toLowerCase() +' de tu unidad?</b></div>'+
            ' <textarea class="texto-area bg-none" disabled>'+ quote.texto +'</textarea>'+
            '</div>'+
        '</div>';

        index++;
    }

    $(".divQuotes").html(txtQuotes);
}

$( "#droppable" ).droppable({
    hoverClass: "ui-state-active",
    drop: function( event, ui ) {
        $( this )
            .addClass( "ui-state-highlight" )
            .find( "p" )
                .html( "Dropped!" );
    }
});






