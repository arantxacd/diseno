//Tabs
$(".contenedorTab, .tab[tab='']").hide();
$(".contenedorTab[contenedorTab='1']").show();
$(".tab").click(function(){
	let tab = $(this);
	tab.siblings().removeClass('active');
	tab.addClass('active');
	$(".contenedorTab").hide();
	$(".contenedorTab[contenedorTab='"+ tab.attr('tab') +"']").show();
});

