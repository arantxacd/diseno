// Titular
$( function() {
    var percentage = 100;
    $(".progressbar-barTitular").progressbar({ value: percentage });
    $(".valorGraficaTitular").text(percentage + "%");
    
    $('input#checkboxPT1[type="checkbox"]').click(function(){
        if($(this).is(":checked")){
          var verdadero = percentage + 10;
          $(".progressbar-barTitular").progressbar({ value: verdadero });
          percentage = verdadero;
          $(".valorGraficaTitular").text(percentage + "%");
          $('.tblPlan tr.Fallecimiento2T').addClass("desac");
          
        }
        else if($(this).is(":not(:checked)")){
          var falso = percentage - 10;
          $(".progressbar-barTitular").progressbar({ value: falso });
          percentage = falso;
          $(".valorGraficaTitular").text(percentage + "%");
          $('.tblPlan tr.Fallecimiento2T').removeClass("desac");
        }
    });

    $('input#checkboxPT2[type="checkbox"]').click(function(){
        if($(this).is(":checked")){
          var verdadero = percentage + 10;
          $(".progressbar-barTitular").progressbar({ value: verdadero });
          percentage = verdadero;
          $(".valorGraficaTitular").text(percentage + "%");
          $('.tblPlan tr.Fallecimiento1T').addClass("desac");
        }
        else if($(this).is(":not(:checked)")){
          var falso = percentage - 10;
          $(".progressbar-barTitular").progressbar({ value: falso });
          percentage = falso;
          $(".valorGraficaTitular").text(percentage + "%");
          $('.tblPlan tr.Fallecimiento1T').removeClass("desac");
        }
    });
    $('input#checkboxPT3[type="checkbox"]').click(function(){
        if($(this).is(":checked")){
          var verdadero = percentage + 10;
          $(".progressbar-barTitular").progressbar({ value: verdadero });
          percentage = verdadero;
          $(".valorGraficaTitular").text(percentage + "%");
        }
        else if($(this).is(":not(:checked)")){
          var falso = percentage - 10;
          $(".progressbar-barTitular").progressbar({ value: falso });
          percentage = falso;
          $(".valorGraficaTitular").text(percentage + "%");
        }
    });
  });

  //Titular + Cónyugue
$( function() {
    var percentage = 100;
    $(".progressbar-barTC").progressbar({ value: percentage });
    $(".valorGraficaTC").text(percentage + "%");
    
    $('input#checkboxTC1[type="checkbox"]').click(function(){
        if($(this).is(":checked")){
          var verdadero = percentage + 10;
          $(".progressbar-barTC").progressbar({ value: verdadero });
          percentage = verdadero;
          $(".valorGraficaLimitado").text(percentage + "%");
          $('.tblPlan tr.Fallecimiento2TC').addClass("desac");

        }
        else if($(this).is(":not(:checked)")){
          var falso = percentage - 10;
          $(".progressbar-barTC").progressbar({ value: falso });
          percentage = falso;
          $(".valorGraficaLimitado").text(percentage + "%");
          $('.tblPlan tr.Fallecimiento2TC').removeClass("desac");

        }
    });

    $('input#checkboxTC2[type="checkbox"]').click(function(){
        if($(this).is(":checked")){
          var verdadero = percentage + 10;
          $(".progressbar-barTC").progressbar({ value: verdadero });
          percentage = verdadero;
          $(".valorGraficaLimitado").text(percentage + "%");
          $('.tblPlan tr.Fallecimiento1TC').addClass("desac");
        }
        else if($(this).is(":not(:checked)")){
          var falso = percentage - 10;
          $(".progressbar-barTC").progressbar({ value: falso });
          percentage = falso;
          $(".valorGraficaLimitado").text(percentage + "%");
          $('.tblPlan tr.Fallecimiento1TC').removeClass("desac");
        }
    });
    $('input#checkboxTC3[type="checkbox"]').click(function(){
        if($(this).is(":checked")){
          var verdadero = percentage + 10;
          $(".progressbar-barTC").progressbar({ value: verdadero });
          percentage = verdadero;
          $(".valorGraficaLimitado").text(percentage + "%");
        }
        else if($(this).is(":not(:checked)")){
          var falso = percentage - 10;
          $(".progressbar-barTC").progressbar({ value: falso });
          percentage = falso;
          $(".valorGraficaLimitado").text(percentage + "%");
        }
    });
  });

   //Titular + Hijos
$( function() {
    var percentage = 100;
    $(".progressbar-barTH").progressbar({ value: percentage });
    $(".valorGraficaTH").text(percentage + "%");
    
    $('input#checkboxTH1[type="checkbox"]').click(function(){
        if($(this).is(":checked")){
          var verdadero = percentage + 10;
          $(".progressbar-barTH").progressbar({ value: verdadero });
          percentage = verdadero;
          $(".valorGraficaTH").text(percentage + "%");
          $('.tblPlan tr.Fallecimiento2TH').addClass("desac");

        }
        else if($(this).is(":not(:checked)")){
          var falso = percentage - 10;
          $(".progressbar-barTH").progressbar({ value: falso });
          percentage = falso;
          $(".valorGraficaTH").text(percentage + "%");
          $('.tblPlan tr.Fallecimiento2TH').removeClass("desac");

        }
    });

    $('input#checkboxTH2[type="checkbox"]').click(function(){
        if($(this).is(":checked")){
          var verdadero = percentage + 10;
          $(".progressbar-barTH").progressbar({ value: verdadero });
          percentage = verdadero;
          $(".valorGraficaTH").text(percentage + "%");
          $('.tblPlan tr.Fallecimiento1TH').addClass("desac");
        }
        else if($(this).is(":not(:checked)")){
          var falso = percentage - 10;
          $(".progressbar-barTH").progressbar({ value: falso });
          percentage = falso;
          $(".valorGraficaTH").text(percentage + "%");
          $('.tblPlan tr.Fallecimiento1TH').removeClass("desac");
        }
    });
    $('input#checkboxTH3[type="checkbox"]').click(function(){
        if($(this).is(":checked")){
          var verdadero = percentage + 10;
          $(".progressbar-barTH").progressbar({ value: verdadero });
          percentage = verdadero;
          $(".valorGraficaTH").text(percentage + "%");
        }
        else if($(this).is(":not(:checked)")){
          var falso = percentage - 10;
          $(".progressbar-barTH").progressbar({ value: falso });
          percentage = falso;
          $(".valorGraficaTH").text(percentage + "%");
        }
    });
  });

//Titular + Cónyugue + Hijos
$( function() {
    var percentage = 100;
    $(".progressbar-barTCH").progressbar({ value: percentage });
    $(".valorGraficaTCH").text(percentage + "%");
    
    $('input#checkboxTCH1[type="checkbox"]').click(function(){
        if($(this).is(":checked")){
          var verdadero = percentage + 10;
          $(".progressbar-barTCH").progressbar({ value: verdadero });
          percentage = verdadero;
          $(".valorGraficaTCH").text(percentage + "%");
          $('.tblPlan tr.Fallecimiento2TCH').addClass("desac");
        }
        else if($(this).is(":not(:checked)")){
          var falso = percentage - 10;
          $(".progressbar-barTCH").progressbar({ value: falso });
          percentage = falso;
          $(".valorGraficaTCH").text(percentage + "%");
          $('.tblPlan tr.Fallecimiento2TCH').removeClass("desac");
        }
    });

    $('input#checkboxTCH2[type="checkbox"]').click(function(){
        if($(this).is(":checked")){
          var verdadero = percentage + 10;
          $(".progressbar-barTCH").progressbar({ value: verdadero });
          percentage = verdadero;
          $(".valorGraficaTCH").text(percentage + "%");
          $('.tblPlan tr.Fallecimiento1TCH').addClass("desac");
        }
        else if($(this).is(":not(:checked)")){
          var falso = percentage - 10;
          $(".progressbar-barTCH").progressbar({ value: falso });
          percentage = falso;
          $(".valorGraficaTCH").text(percentage + "%");
          $('.tblPlan tr.Fallecimiento1TCH').removeClass("desac");
        }
    });
    $('input#checkboxTCH3[type="checkbox"]').click(function(){
        if($(this).is(":checked")){
          var verdadero = percentage + 10;
          $(".progressbar-barTCH").progressbar({ value: verdadero });
          percentage = verdadero;
          $(".valorGraficaTCH").text(percentage + "%");
        }
        else if($(this).is(":not(:checked)")){
          var falso = percentage - 10;
          $(".progressbar-barTCH").progressbar({ value: falso });
          percentage = falso;
          $(".valorGraficaTCH").text(percentage + "%");
        }
    });
  });
