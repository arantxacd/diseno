

//Calendario
$.datepicker.regional['es'] = {
	 closeText: 'Cerrar',
	 prevText: '',
	 nextText: ' ',
	 currentText: 'Hoy',
	 monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
	 monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
	 dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
	 dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
	 dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
	 weekHeader: 'Sm',
	 dateFormat: 'dd/mm/yy',
	 firstDay: 1,
	 isRTL: false,
	 showMonthAfterYear: false,
	 yearSuffix: ''
 };
$.datepicker.setDefaults($.datepicker.regional['es']);
$(function() {
	$( ".datapicker1" ).datepicker({
		firstDay: 1,
		minDate: 0,
		maxDate: 31
	});
});

$(document).ready(function() {
	//Modal resolución

	$("#terminarLlamada, .terminarLlamada").click(function(){
        $("#modalTerminarLlamada").modal({
            showClose: false
        });
    });

    $("#terminarContratacion, .terminarContratacion").click(function(){
        $("#modalFelicidades").modal({
            showClose: false
        });
    });

    $("#terminarVerDatos, .terminarVerDatos").click(function(){
        $("#modalDatosCliente").modal({
            showClose: false
        });
	});
	
	$("#terminarDatosPTranquilidad, .terminarDatosPTranquilidad").click(function(){
        $("#modalDatosPTranquilidad").modal({
            showClose: false
        });
    });
    $("#terminarConfirmarVenta, .terminarConfirmarVenta").click(function(){
        $("#modalConfirmarVenta").modal({
            showClose: false
        });
    });

    $("#terminarErrorContratar, .terminarErrorContratar").click(function(){
        $("#modalErrorContratar").modal({
            showClose: false
        });
    });
	
	

	// Menu hambuergesa
	$("#effect").toggle(false);
	$("#hamburger").click(function (event) {
		event.stopPropagation();
		 $( "#effect" ).toggle( "slide"); 
	});

	$(document).click(function() {
		$("#effect").toggle(false);
	});
	$("#effect").click (function (event){
		event.stopPropagation();
	}); 

	/*Menu User*/
	$(".MenuUser, .MenuUser1").hide();
	$('.imgShowMenuUser').click(function() {
		$(".MenuUser, .MenuUser1").toggle("ver");
	});

	$(".divRC").hide();
	$('#radioResCivil').on( "change", function() {
				$(".divRC").show();
			});
	$('#radioEmpre').on( "change", function() {
		$(".divRC").hide();
	});
	
	// Menu seguimiento
	$("#seguimiento").toggle(true);
	
	$(".hamburgerSeg").click(function (event) {
		event.stopPropagation();
		 $( ".seguimiento" ).toggle( "slide"); 
	});

	$(document).click(function() {
		$(".seguimiento").toggle(false);
	});
	$(".seguimiento").click (function (event){
		event.stopPropagation();
	});
	/********Para selects*******************/
	$( "select").dropkick({
		mobile: true
	});	
	
	$('.switch').click(function(){
		$(this).toggleClass("switchOn");
	}); 
	
	$( ".cerrarChip" ).click(function() {
	   $(this).parent().parent().remove()
	});


});

/*Valida buscador del menu de hamburgesa*/
function valida(f) {
	if (f.busca.value == "")  {
		alert("Es necesario que introduzca un valor");
	}else { 
		return false;
	}
}
/*Detecta resolucion de pantalla*/
if (matchMedia) {
  const mq = window.matchMedia("(min-width: 780px)");
  mq.addListener(WidthChange);
  WidthChange(mq);
}
function WidthChange(mq) {
	if (mq.matches) {
	  	$("#menu ul").addClass("normal");
	  	$("#menu ul li").removeClass("in");
		$('ul.nivel1 >li > ul').slideUp();
		$('ul.nivel2 >li > ul').slideUp();
		$('ul.nivel1>li').off("click");
		$('ul.nivel2>li').off("click");
	} else {
	   $("#menu ul").removeClass("normal");

		$('ul.nivel1>li').on('click', function(event) {
			event.stopPropagation();
			
			$target = $(this).children();

			if ($(this).hasClass("in"))  {
			    $('ul.nivel2').slideUp();

				$(this).removeClass("in");
				$('.flecha').removeClass("rotar");
			}else {
			  	$('ul.nivel1 > li').removeClass("in");
				$('ul.nivel2').slideUp();
				$('ul.nivel3').slideUp();
				$('ul.nivel2>li').removeClass("in");
				$(this).addClass("in");
			  	$target.slideDown();
				$('ul.nivel1 > li > a .flecha').addClass("rotar");
				
			}
		});
		$('ul.nivel2>li').on('click', function(event) {
			event.stopPropagation();
		
			$target = $(this).children();

			if ($(this).hasClass("in"))  {
			    $('ul.nivel3').slideUp();
				$(this).removeClass("in");
				$('ul.nivel2 > li > a .flecha').removeClass("rotar");
			}else {
			  	$('ul.nivel2 > li').removeClass("in");
				$('ul.nivel3').slideUp();
				$(this).addClass("in");
			  	$target.slideDown();
				$('ul.nivel2 > li > a .flecha').addClass("rotar");
			}
		});
		$('ul.nivel3>li').on('click', function(event) {
			event.stopPropagation();
		});
	}
}
var allPanels = $('.accordion > dd').hide().first().show();

	jQuery('.accordion > dt').on('click', function() {
		$this = $(this);
		//the target panel content
		$target = $this.next();

		jQuery('.accordion > dt').removeClass('accordion-active');
		if ($target.hasClass("in")) {
		  $this.removeClass('accordion-active');
		  $target.slideUp();
		  $target.removeClass("in");

		} else {
		  $this.addClass('accordion-active');
		  jQuery('.accordion > dd').removeClass("in");
		  $target.addClass("in");
			$(".subSeccion").show();

		  jQuery('.accordion > dd').slideUp();
		  $target.slideDown();
		}
	});

	
	jQuery('.accordionM > dt').on('click', function() {
		$this = $(this);
		//the target panel content
		$target = $this.next();

		jQuery('.accordionM > dt').removeClass('accordion-active');
		if ($target.hasClass("in")) {
		  $this.removeClass('accordion-active');
		  $target.slideUp();
		  $target.removeClass("in");

		} else {
		  $this.addClass('accordion-active');
		  jQuery('.accordionM > dd').removeClass("in");
		  $target.addClass("in");
			$(".subSeccion").show();

		  jQuery('.accordionM > dd').slideUp();
		  $target.slideDown();
		}
	});
$(document).ready(function() {
	//Acordeon 
 	$(".menu2").accordion({
      collapsible: true,
      active: false,
      autoHeight: true,
      navigation: true,
      heightStyle: "content"
    });
	
});

		
$('.divBeneficiarios').hide();
$("#checkBeneficiario").on('change',function(){
	if($(this).is(':checked')) {
		$('.divBeneficiarios').show();
		$('.divDatosT').hide();
		$('.divTerminos').hide();
	} else {
		$('.divBeneficiarios').hide();
		$('.divDatosT').show();
		$('.divTerminos').show();
	}
});

$("#checkAviso").on('change',function(){
	if($(this).is(':checked')) {
		$('.btnActivar').removeClass("desac");
	} else {
		$('.btnActivar').addClass("desac");
	}
});

$('#radio4P').on( "change", function() {
	$('.btnMoradoS').removeClass("btnLila");
	return false;
});

$('.divGastosI').hide();
$('.divAdicional').hide();
$('#radio1PI').on( "change", function() {
	$('.divGastosI').show();
	$('.divPorcentaje').css("width", "50%");
	$('.divAdicional').show();
	return false;
});

$('.avisoTxt').hide();
$('.divInformacionI').hide();

$('#inputNumSerie').on("keyup", function(){
	if($(this).val() != ''){
		$('.btnConsultar').removeClass("desacAzul");
		
	} else {
		$('.btnConsultar').addClass("desacAzul");

	}
});

$('#inputfactuar').on("keyup", function(){
	if($(this).val() != ''){
		$('.btnBus').removeClass("desac");
		
	} else {
		$('.btnBus').addClass("desac");

	}
});

$('.btnConsultar').click(function(){
	$('.avisoTxt').show();
	$('.divInformacionI').show();
});

$('.btnAgregC').click(function(){
	$('.ocultarC').hide();
	$('.mostrarC').show();
});

$('#checkFolio').on( "change", function() {
	if($(this).is(':checked')){
		$(".btnFolioA").removeClass("desac");
	} else {
		$(".btnFolioA").addClass("desac");
	}
	
});

$('.divDireccion').hide();
$('.divBeneficiario').hide();
$('.btnFolioA').click(function(){
	$('.divDireccion').show();
	$('.divBeneficiario').hide();
	$('.divDatosPersonales').hide();
});

$('.btnSiguiente').click(function(){
	$('.divDireccion').hide();
	$('.divBeneficiario').show();
	$('.divDatosPersonales').hide();
});

function selectFunction() {
  var x = document.getElementById("selectEstado").value;
  if (x == "1"){
  	$('.btnSiguiente').removeClass("desac");
  } else {
	$('.btnSiguiente').addClass("desac");
  }
}

function selectCFDI() {
  var activarBtn = document.getElementById("selectCFDI").value;
  if (activarBtn == "2"){
  	$('.btnFacturar').removeClass("desac");
  } else {
	$('.btnFacturar').addClass("desac");
  }
}

$(".btnDelet").click(function (e) {
	$(this).parent().parent().remove();
}); 

$(".btnBus").click(function (e) {
	$(".contBuscar").css("display", "block");
}); 



$('#radioParMi').on( "change", function() {
	$('.btnRadioSeguros').click( function(){
		window.location.href ="activarFolio.html";
	});
});

$('#radioTercero').on( "change", function() {
	$('.btnRadioSeguros').click( function(){
		window.location.href ="activar-folio.html";
	});
});

$(document).ready(function(){
    $(".sfs1link").click(function(){   
		$(".sfs1").trigger("click");
    });
});



/*Selecciona cliente*/
$(".cardSeguro").click(function(){
	$('.cardSeguro').removeClass("activeCard");
	$(this).addClass("activeCard");
});


$(document).ready(function(){
	

	//Editar Datos personales
	$(".btnEditarDatos").click(function (){
		$(this).hide();
		$('.divEditarDatosP label').hide();
		$('.divEditarDatosP input[type="text"]').show();
		$('.btnGuardarDatosP').show();
		$(".divSelectSexo .dk-select").css("display", "block");
		
	});
	
	$('.divEditarDatosP input[type="text"]').blur(function() {
		 if ($.trim(this.value) == ''){
			 this.value = (this.defaultValue ? this.defaultValue : '');
		 }
		 else{
			 $(this).prev().html(this.value);
		 }
		 
	
	});

	
	$('.divEditarDatosP input[type="text"]').keypress(function(event) {
		  if (event.keyCode == '13') {
			  if ($.trim(this.value) == ''){
				 this.value = (this.defaultValue ? this.defaultValue : '');
			 }
			 else
			 {
				$(this).prev().html(this.value);
			 }
	
		  }
	});
	$('.btnGuardarDatosP').click(function(){
		$(this).hide();
		$('.divEditarDatosP input[type="text"]').hide();
		$('.btnEditarDatos').show();
		$('.divEditarDatosP label').show();
		$(".divSelectSexo .dk-select").css("display", "none");

	});


	//Editar dirección
	$(".btnEditarDireccion").click(function (){
		$(this).hide();
		$('.divEditarDireccion label').hide();
		$('.divEditarDireccion input[type="text"]').show();
		$('.btnGuardarDireccion').show();
		$(".divEstado .dk-select").css("display", "block");
	});
	
	$('.divEditarDireccion input[type="text"]').blur(function() {
		 if ($.trim(this.value) == ''){
			 this.value = (this.defaultValue ? this.defaultValue : '');
		 }
		 else{
			 $(this).prev().html(this.value);
		 }
	
	});
	
	$('.divEditarDireccion input[type="text"]').keypress(function(event) {
		  if (event.keyCode == '13') {
			  if ($.trim(this.value) == ''){
				 this.value = (this.defaultValue ? this.defaultValue : '');
			 }
			 else
			 {
				$(this).prev().html(this.value);
			 }
	
		  }
	});
	$('.btnGuardarDireccion').click(function(){
		$(this).hide();
		$('.divEditarDireccion input[type="text"]').hide();
		$('.btnEditarDireccion').show();
		$('.divEditarDireccion label').show();
		$(".divEstado .dk-select").css("display", "none");
	});


	//Editar Datos de contacto
	$(".btnEditarDatosContacto").click(function (){
		$(this).hide();
		$('.divEditarDatosContacto label').hide();
		$('.divEditarDatosContacto input[type="text"]').show();
		$('.btnGuardarDatos').show();
	});
	
	$('.divEditarDatosContacto input[type="text"]').blur(function() {
		 if ($.trim(this.value) == ''){
			 this.value = (this.defaultValue ? this.defaultValue : '');
		 }
		 else{
			 $(this).prev().html(this.value);
		 }
	
	});
	
	$('.divEditarDatosContacto input[type="text"]').keypress(function(event) {
		  if (event.keyCode == '13') {
			  if ($.trim(this.value) == ''){
				 this.value = (this.defaultValue ? this.defaultValue : '');
			 }
			 else
			 {
				$(this).prev().html(this.value);
			 }
	
		  }
	});
	$('.btnGuardarDatos').click(function(){
		$(this).hide();
		$('.divEditarDatosContacto input[type="text"]').hide();
		$('.btnEditarDatosContacto').show();
		$('.divEditarDatosContacto label').show();
	});


	// editar datos tabla
	$("#btnEditarPlaca1").click(function (){
		$(this).hide();
		$('.tblDatosMoto td.tdPlaca1 .labelPlaca').hide();
		$('.tblDatosMoto td.tdPlaca1 input[type="text"]').show();
		$('#btnGuardarPlaca1').show();
	});
	$('.tblDatosMoto td input[type="text"]').blur(function() {
		 if ($.trim(this.value) == ''){
			 this.value = (this.defaultValue ? this.defaultValue : '');
		 }
		 else{
			 $(this).prev().html(this.value);
		 }
	
	});
	$('.tblDatosMoto td input[type="text"]').keypress(function(event) {
		  if (event.keyCode == '13') {
			  if ($.trim(this.value) == ''){
				 this.value = (this.defaultValue ? this.defaultValue : '');
			 }
			 else
			 {
				$(this).prev().html(this.value);
			 }
	
		  }
	});
	$('#btnGuardarPlaca1').click(function(){
		$(this).hide();
		$('.tblDatosMoto td.tdPlaca1 input[type="text"]').hide();
		$('#btnEditarPlaca1').show();
		$('.tblDatosMoto td.tdPlaca1 .labelPlaca').show();
	});



	$("#btnEditarPlaca2").click(function (){
		$(this).hide();
		$('.tblDatosMoto td.tdPlaca2 .labelPlaca').hide();
		$('.tblDatosMoto td.tdPlaca2 input[type="text"]').show();
		$('#btnGuardarPlaca2').show();
	});
	$('.tblDatosMoto td input[type="text"]').blur(function() {
		 if ($.trim(this.value) == ''){
			 this.value = (this.defaultValue ? this.defaultValue : '');
		 }
		 else{
			 $(this).prev().html(this.value);
		 }
	
	});
	$('.tblDatosMoto td input[type="text"]').keypress(function(event) {
		  if (event.keyCode == '13') {
			  if ($.trim(this.value) == ''){
				 this.value = (this.defaultValue ? this.defaultValue : '');
			 }
			 else
			 {
				$(this).prev().html(this.value);
			 }
	
		  }
	});
	$('#btnGuardarPlaca2').click(function(){
		$(this).hide();
		$('.tblDatosMoto td.tdPlaca2 input[type="text"]').hide();
		$('#btnEditarPlaca2').show();
		$('.tblDatosMoto td.tdPlaca2 .labelPlaca').show();
	});

});

$(".tooltipInfo").click(function(event) {
  $(".tooltiptext").css("display", "none");
  $(this).find(".tooltiptext").css("display", "block");
});

$(document).on("click",function(e) {               
  var container = $(".tooltipInfo");         
     if (!container.is(e.target) && container.has(e.target).length === 0) { 
      $(".tooltiptext").css("display", "none");               
     }
});


//Copiar
function copyToClipboard(target) {
	console.log("este es el target " + target);
	var element = document.getElementById(target);
	var text = element.innerHTML;
	CopyToClipboard(text);
	alert("Texto copiado");
}

var apellidoPadre = $(".txt1").text();
var apellidoMadre = $(".txt2").text();
var apellidos = apellidoPadre + " " + apellidoMadre;
console.log(apellidos);

function copyApellidos(apellidos) {
	CopyToClipboard(apellidos);
	alert("Texto copiado");
}

function CopyToClipboard (text) {
	  if (window.clipboardData && window.clipboardData.setData) {

		  return clipboardData.setData("Text", text); 
  
	} else if (document.queryCommandSupported && document.queryCommandSupported("copy")) {
	  var textarea = document.createElement("textarea");
	  textarea.textContent = text;
	  textarea.style.position = "fixed";  
	  document.body.appendChild(textarea);
	  textarea.select();
  
	  try {
		return document.execCommand("copy"); 
	  } catch (ex) {
		console.warn("Copy to clipboard failed.", ex);
		return false;
	  } finally {
		document.body.removeChild(textarea);
	  }
	  }
 }

 function limpiarParametros() {
	 document.getElementById("formManejoCampanas").reset();
 }

$(".btnEditarD").click(function(event) {
	$(this).siblings(".btnGuardarD").css("display", "block");
	$(this).css("display", "none");
	console.log($(this));
});
$(".btnGuardarD").click(function(event) {
	$(this).css("display", "none");
	$(this).siblings(".btnEditarD").css("display", "block");
});


  $(document).ready(function() {
	
	$('#owl-carousel1').owlCarousel({
		margin: 38,
		nav: true,
		stagePadding: 38,
		loop: false,
		responsive: {
		  	0: {
				items: 1
		  	},
		  	600: {
				items: 2
		  	},
		  	1000: {
				items: 3
		  	}
		}
	});
});

$(document).ready(function() {
    $('.tblSeleccionarPlan input:radio[name=grupoModal1]').change(function() {
        if (this.value == 'titular') {
			$('.divPlanTitular').css("display","block");
			$('.divPlanTC').css("display","none");
			$('.divPlanTH').css("display","none");
			$('.divPlanTCH').css("display","none");
			$(".beneficiarioConyuge").css("display", "none");
			$(".beneficiarioHijo").css("display", "none");
			$(".divConyugeHijo").css("display", "none");
        }
        else if (this.value == 'titularConyugue') {
            $('.divPlanTC').css("display","block");
			$('.divPlanTitular').css("display","none");
			$('.divPlanTH').css("display","none");
			$('.divPlanTCH').css("display","none");
			$(".beneficiarioConyuge").css("display", "block");
			$(".beneficiarioHijo").css("display", "none");
			$(".divConyugeHijo").css("display", "none");
		}
		else if (this.value == 'titularHijos') {
            $('.divPlanTH').css("display","block");
			$('.divPlanTitular').css("display","none");
			$('.divPlanTC').css("display","none");
			$('.divPlanTCH').css("display","none");
			$(".beneficiarioConyuge").css("display", "none");
			$(".beneficiarioHijo").css("display", "block");
			$(".divConyugeHijo").css("display", "none");
        }
        else if (this.value == 'titularCHijos') {
			$('.divPlanTCH').css("display","block");
			$('.divPlanTitular').css("display","none");
			$('.divPlanTC').css("display","none");
			$('.divPlanTH').css("display","none");
			$(".beneficiarioConyuge").css("display", "none");
			$(".beneficiarioHijo").css("display", "none");
			$(".divConyugeHijo").css("display", "block");
        }
    });
});

 /*Nuevo*/
$(".btnContratarSeguro").click(function(){
	$(".divLlamar").css("display", "none");
	$(".divContratarSeguro").css("display", "block");
	$(".tracker2 .paso2").addClass("active demi");
});

$(".btnAplicar").click(function(){
	$(".tracker2 .paso3").addClass("active demi");
});

let hijoBeneficiario = 1;
$(document).ready(function (){
	$(".btnAgregarHijo").click(function (){
		let contadorDP = $(".tblHijosBeneficiarios").find(".date").size();
		let total_rows = $(".tblHijosBeneficiarios tbody tr").length;
		let calendarioT = (contadorDP + 1);
		if(total_rows > 1){
			alert("Sólo puedes agregar 3 hijos");
			$(".btnAgregarHijo").css("display", "none");
		} else {
			markup = "<tr><td><div>Nombre (s)</div><input type='text' id='inputNombre"+hijoBeneficiario+"'></td><td><div>Apellido paterno</div><input type='text' id='inputApellidoPaterno"+hijoBeneficiario+"'></td><td><div>Apellido materno</div><input type='text' id='inputApellidoMaterno"+hijoBeneficiario+"'></td><td><div>Fecha de nacimiento</div><input type='text' placeholder='DD/MM/AAAA' class='datapicker1 date mayusculas' id='datepickerH"+calendarioT+"' autocomplete='off'></td></tr>";
		}
		tableBody= $(".tblHijosBeneficiarios tbody");
		tableBody.append(markup);
		hijoBeneficiario++;
		$(".datapicker1").datepicker({
			firstDay: 1,
			minDate: 0,
			maxDate: 31
		});

	});

});

let hijoBeneficiario2 = 1;
$(document).ready(function (){
	$(".btnAgregarHijo2").click(function (){
		let contadorDP2 = $(".tblHijosBeneficiarios2").find(".date").size();
		let total_rows2 = $(".tblHijosBeneficiarios2 tbody tr").length;
		let calendarioT2 = (contadorDP2 + 1);
		if(total_rows2 > 1){
			alert("Sólo puedes agregar 3 hijos");
			$(".btnAgregarHijo2").css("display", "none");
		} else {
			markup = "<tr><td><div>Nombre (s)</div><input type='text' id='inputNombre"+hijoBeneficiario2+"'></td><td><div>Apellido paterno</div><input type='text' id='inputApellidoPaterno"+hijoBeneficiario2+"'></td><td><div>Apellido materno</div><input type='text' id='inputApellidoMaterno"+hijoBeneficiario2+"'></td><td><div>Fecha de nacimiento</div><input type='text' placeholder='DD/MM/AAAA' class='datapicker1 date mayusculas' id='datepickerH"+calendarioT2+"' autocomplete='off'></td></tr>";
		}
		tableBody= $(".tblHijosBeneficiarios2 tbody");
		tableBody.append(markup);
		hijoBeneficiario2++;
		$(".datapicker1").datepicker({
			firstDay: 1,
			minDate: 0,
			maxDate: 31
		});
	});

});




