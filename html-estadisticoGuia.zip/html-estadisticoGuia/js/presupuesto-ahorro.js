if (Vue) {
	//Modal Consulta de saldos - Foto de usuario
    Vue.component('modalfotousr', {
        template: `
			<transition name="modal">
				<div class="modal-mask">
				  <div class="modal-wrapper">
					<div class="modal-container modal-long">

							<a href="#" class="simplemodal-close btnCerrar" @click="$emit('close')"><img src="img/icoCerrar.svg"></a>
							<img v-bind:src="foto" class="viewFoto">


					</div>
				  </div>
				</div>
			</transition>
		`,
		props: ['show','foto'],
		methods: {
			close: function () {
				this.$emit('close');
			},
		},
		created: function () {
			//this.funcDetalle();
		}
	});

	//Modal Consulta de saldos - Imprime comprobante
     Vue.component('modalimpconsulta', {
     	template: `
			<transition name="modal">
				<div class="modal-mask">
				  <div class="modal-wrapper">
					<div class="modal-container modal-long">
					  <div class="modal-body">
						 <div class="cuadro cuadroM">
							<a href="#" class="simplemodal-close btnCerrar" @click="$emit('close')"><img src="img/icoCerrar.svg"></a>
							<div class="titModal">Impresión de Consulta de Saldo</div><br>
							<div class="contModal tCenter">
								¿Se imprimió correctamente el ticket?
							</div>
							<div class="btnCenter">
								<a href="#" class="btn1 btnG" @click="$emit('close')">No, Imprimir nuevamente</a>
								<a href="#" class="btn1" @click="$emit('close')">Sí, salir</a>
							</div>
						  </div>
					  </div><br>
					</div>
				  </div>
				</div>
			</transition>
		`,
		props: ['show'],
		methods: {
			close: function () {
				this.$emit('close');
			},
		}
	});
	
	Vue.component('presupuesto-ahorro', {
        template: `
      
                <div class="contSecc">
                    <div v-show="divConsultaSaldo == 0">
                        <div class="titCol">Seleccione un criterio de búsqueda.</div><br>
                        <div class="divCriterior">
                            <div v-bind:class="{'desac1': opcionBusqueda(1)}" v-on:click="selOptBusqueda(1)">
                                <div><img src="img/criterio1.svg"></div>Por nombre
                            </div>
                            <div v-bind:class="{'desac1': opcionBusqueda(2)}" v-on:click="selOptBusqueda(2)">
                                <div><img src="img/criterio2.svg"></div>Por número de tarjeta
                            </div>
                            <div v-bind:class="{'desac1': opcionBusqueda(3)}" v-on:click="selOptBusqueda(3)">
                                <div><img src="img/criterio3.svg"></div>Por número de cuenta
                            </div>
                            <div v-bind:class="{'desac1': opcionBusqueda(4)}" v-on:click="selOptBusqueda(4)">
                                <div><img src="img/criterio4.svg"></div>Por Cliente Único
                            </div>
                        </div>
        
                        <div class="divBuscarCriterio" v-show="opMenuBusqueda > 0">
                            <div class="titSec">Búsqueda del cliente</div>
                            <div class="gris">
                                <div class="titCol">Ingrese la siguiente información.</div>
                                <div class="divCol4">
                                    <div class="col4" v-show="opMenuBusqueda == 1">
                                        Primer apellido:<br>
                                        <input type="text" v-model="txtApellidoP"
                                            v-bind:class="[{'desac': bloqueadoUno}, {'act': bloqueadoDos}]"><br>
                                        <input type="checkbox" name="grupo1" id="checkApellidoP" v-model="bloqueadoUno" />
                                        <label for="checkApellidoP" v-bind:class="[{'desac': bloqueadoDos}]">Sin primer apellido</label>
                                    </div>
                                    <div class="col4" v-show="opMenuBusqueda == 1">
                                        Segundo apellido:<br>
                                        <input type="text" v-model="txtApellidoM"
                                            v-bind:class="[{'desac': bloqueadoDos}, {'act': bloqueadoUno}]"><br>
                                        <input type="checkbox" name="grupo2" id="checkApellidoM" v-model=" bloqueadoDos" /><label
                                            for="checkApellidoM" v-bind:class="[{'desac': bloqueadoUno}]">Sin segundo apellido</label>
                                    </div>
                                    <div class="col4" v-show="opMenuBusqueda == 1">Nombre(s):<br><input type="text"
                                            v-model="txtNombre"><br>&nbsp;</div>
                                    <div class="col4" v-show="opMenuBusqueda == 2">Teclee el número de tarjeta:<br><input type="number"
                                            v-model="txtNoTarjeta"></div>
                                    <div class="col4" v-show="opMenuBusqueda == 3">Teclee el número de cuenta:<br><input type="number"
                                            v-model="txtNoCuenta"></div>
                                    <div class="col4" v-show="opMenuBusqueda == 4">Cliente Único:<br>
                                        <div class="divCol4 divCol4int">
                                            <div class="col4"><input type="number" v-model="cliUPais"></div>
                                            <div class="col4"><input type="number" v-model="cliUCabal"></div>
                                            <div class="col4"><input type="number" v-model="cliUSucursal"></div>
                                            <div class="col4"><input type="number" v-model="cliUFolio"></div>
                                        </div>
                                    </div>
                                    <div class="col4">&nbsp;<br><a href="#" class="btn1 btnBuscar "
                                            v-on:click.prevent="funcResultados()">Buscar</a></div>
                                </div>
                                <div class="titCol">Recuerda puedes seguir <strong>pasando la Tarjeta para recabar los datos del
                                        Cliente.</strong></div>
                                <div class="clear"></div>&nbsp;
                                <div class="divError">&nbsp;</div>
                            </div>
                        </div>
                        <div class="clear">&nbsp;</div>
                        <div class="divBuscar" v-if="resultadosBusqueda" v-show="resultadosBusqueda.length > 0">
                            <div class="titSec">Resultado de la búsqueda</div>
                            <div class="gris">
                                <div class="scroll scrolly">
                                    <table class="tblGeneral tblClientes">
                                        <tbody>
                                            <tr>
                                                <th>Cliente Único</th>
                                                <th>Cuenta</th>
                                                <th>Tipo de Cuenta</th>
                                                <th>Apellido Paterno</th>
                                                <th>Apellido Materno</th>
                                                <th>Nombre</th>
                                                <th>Fecha Nacimiento</th>
                                                <th>T*</th>
                                            </tr>
                                            <tr v-for="resultado in resultadosBusqueda" v-on:click="funcDetalle(resultado)">
                                                <td>{{resultado.clienteU}}</td>
                                                <td>{{resultado.cuenta}}</td>
                                                <td><img v-bind:src="resultado.tipoCuenta" class="icoLogo"></td>
                                                <td>{{resultado.apellidoP}}</td>
                                                <td>{{resultado.apellidoM}}</td>
                                                <td>{{resultado.nombre}}</td>
                                                <td>{{resultado.fechaN}}</td>
                                                <td>{{resultado.T}}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="titCol divSimple">
                                    <div><strong>T </strong>= Titular</div>
                                    <div><strong>A </strong>= Autorizado</div>
                                    <div><strong>B </strong>= Baja</div>
                                    <div><strong>N </strong>= No es cliente de ahorro</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!----------------------------------------------------------------->
                    <div class="divBuscar" v-show="opDetalle == 1">
                        <div class="titSec">Datos de titular</div>
                        <div class="gris">
                            <div class="infoUsuario" v-if="clienteDetalle">
                                <div class="divFoto">
                                    <img v-bind:src="clienteDetalle.foto" @click="modalFotoUsr_view = true">
                                    <img src="img/lupa1.svg" @click="modalFotoUsr_view = true" class="imgLupa">
                                </div>
        
                                <div>
                                    <table class="tblGeneral tblClientes">
                                        <tbody>
                                            <tr>
                                                <th>Cliente Único</th>
                                                <th>Cuenta</th>
                                                <th>Tipo de Cuenta</th>
                                                <th>Número de tarjeta</th>
                                            </tr>
                                            <tr>
                                                <td>{{clienteDetalle.clienteU}}</td>
                                                <td>{{clienteDetalle.cuenta}}</td>
                                                <td><img v-bind:src="clienteDetalle.tipoCuenta" class="icoLogo"></td>
                                                <td>*************703</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <div class="clear">&nbsp;</div>
                                    <table class="tblGeneral tblClientes">
                                        <tbody>
                                            <tr>
        
                                                <th>Primer Apellido</th>
                                                <th>Segundo Aellido</th>
                                                <th>Nombre(s)</th>
                                                <th>Fecha Nacimiento</th>
                                            </tr>
                                            <tr>
                                                <td>{{clienteDetalle.apellidoP}}</td>
                                                <td>{{clienteDetalle.apellidoM}}</td>
                                                <td>{{clienteDetalle.nombre}}</td>
                                                <td>{{clienteDetalle.fechaN}}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <div class="clear">&nbsp;</div>
                                    <div class="btnCenter">
                                        <a class="btn1 btnG" @click.prevent="regresar()">Regresar</a>
                                        <a href="#" class="btn1" @click="modalimpconsulta_view = true">Coincide la Fotografía de Titular</a>
                                    </div>
                                </div>
                            </div>
        
                        </div>
                    </div>
                    <modalfotousr v-if="modalFotoUsr_view " @close="modalFotoUsr_view  = false" v-bind:foto="clienteDetalle.foto"></modalfotousr>
                    <modalimpconsulta v-if="modalimpconsulta_view" @close="modalimpconsulta_view  = false"></modalimpconsulta>
                </div> 
     
        `,
		props: [],
		data: function () {
			return {
				
				
				divConsultaSaldo: 0,
				//DEsactiva check
				bloqueadoUno: false,
				bloqueadoDos: false,
				opMenuSel: 0,
				opMenuBusqueda: 0,
				resultadosBusqueda: [],
				//Cosulta Saldos por nombre
				checkApellidoP: "",
				checkApellidoM: "",
				txtApellidoP: "",
				txtApellidoM: "",
				txtNombre: "",
				//Cosulta Saldos por número de tarjeta
				txtNoTarjeta: "",
				//Cosulta Saldos por número de cuenta
				txtNoCuenta: "",
				//Cosulta Saldos por cliente ínico
				cliUPais: "",
				cliUCabal: "",
				cliUSucursal: "",
				cliUFolio: "",
				open: false,
				//Modal Consulta de saldos - Foto de usuario
				modalFotoUsr_view: false,
				modalimpconsulta_view: false,
				opDetalle: "",
				clienteDetalle: null,
				
				//Presupuesto Ahorro
				noAhorro:"",
				selCuenta:""
			};
		},
		methods: {
			selOptBusqueda: function (opBusqueda) {
				this.opMenuBusqueda = opBusqueda;
				//$(".divError").html('');
			},
			opcionBusqueda: function (opBusqueda) {
				return this.opMenuBusqueda != opBusqueda;
			},

			funcConsultaAhorro:function(){
				if (this.selCuenta == "CDP"){
					alert("llega");
				}
			},
			funcResultados: function () {
				if ((this.txtApellidoP == "") && (this.opMenuBusqueda == 1)) { $(".divError").html('Es necesario que ingreses su apellido paterno'); return false; }
				else if ((this.txtApellidoM == "") && (this.opMenuBusqueda == 1)) { $(".divError").html('Es necesario que ingrese su apellido materno'); return false; }
				else if ((this.txtNombre == "") && (this.opMenuBusqueda == 1)) { $(".divError").html('Es necesario que ingrese su nombre'); return false; }
				else if ((this.txtNoTarjeta.length <= 16) && (this.opMenuBusqueda == 2)) { $(".divError").html('Es necesario que ingrese el número de su tarjeta'); return false; }
				else if ((this.txtNoCuenta.length <= 5) && (this.opMenuBusqueda == 3)) { $(".divError").html('Es necesario que ingrese el número de su cuenta'); return false; }
				else if ((this.txtNoCuenta.length <= 5) && (this.opMenuBusqueda == 4)) { $(".divError").html('Es necesario que ingrese su número de cliente único'); return false; }
				else {
					this.resultadosBusqueda = [
						{ clienteU: '0201035741105', cuenta: '03570100198767', tipoCuenta: 'img/guardadito.gif', apellidoP: 'Ramírez', apellidoM: 'Romero', nombre: 'Coyolxauhqui', fechaN: '00/00/0000', T: 'T', foto: 'img/usuarios/207207.jpg' },
						{ clienteU: '0201035741106', cuenta: '03570100198704', tipoCuenta: 'img/guardadito.gif', apellidoP: 'Castro', apellidoM: 'Olguin', nombre: 'Ariel', fechaN: '00/00/0000', T: 'T', foto: 'img/usuarios/181798.jpg' },
						{ clienteU: '0201035741107', cuenta: '03570100198718', tipoCuenta: 'img/guardadito.gif', apellidoP: 'Castañeda', apellidoM: 'Dorantes', nombre: 'Arantxa', fechaN: '00/00/0000', T: 'T', foto: 'img/usuarios/40883.jpg' },
						{ clienteU: '0201035741108', cuenta: '03570100198733', tipoCuenta: 'img/guardadito.gif', apellidoP: 'Camarillo', apellidoM: 'Encina', nombre: 'Antonio', fechaN: '00/00/0000', T: 'T', foto: 'img/usuarios/208988.jpg' },
						{ clienteU: '0201035741109', cuenta: '03570100198767', tipoCuenta: 'img/guardadito.gif', apellidoP: 'Ramírez', apellidoM: 'Romero', nombre: 'Coyolxauhqui', fechaN: '00/00/0000', T: 'T', foto: 'img/usuarios/207207.jpg' },
					];
					console.log(this.txtApellidoP);
				}
			},
			funcDetalle: function (opDetalle) {
				this.divConsultaSaldo = 1;
				this.opDetalle = 1;
				this.opMenuBusqueda = 0;
				this.clienteDetalle = opDetalle;
				this.resultadosBusqueda = [];
			},
			regresar: function () {
				console.log('regresar');
				this.clienteDetalle = null;
				this.opDetalle = 0;
				this.divConsultaSaldo = 0;
				this.funcResultados();
			},
			//Fin COnsulta de saldos

			//Modal ---------------------------------------------
			hideModal: function () {
				this.open = false;
			}
		}
	});
            
}



