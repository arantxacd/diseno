var config_select= {
	options: [
	  {
		id:1,
		value: "option 1"
	  },
	  {
		  id:2,
		value: "option 2"
	  },
	  {
		  id:3,
		value: "option 3"
	  }
		],
		prefix: "",
		placeholder: "Seleccionar",
		backgroundColor: "#cde4f5",
		textColor: "black",
		borderRadius: "4px",
		border: "1px solid gray",
		width: 150
		};
