if (Vue) {
	//Modal Consulta Guia
     Vue.component('modalEstadistico', {
     	template: `
			<transition name="modal">
				<div class="modal-mask">
				  <div class="modal-wrapper">
					<div class="modal-container modal-long cuadroG">
					  <div class="modal-body">
						 <div class="cuadro ">
							<a href="#" class="simplemodal-close btnCerrar" @click="$emit('close')"><img src="img/icoCerrar.svg"></a>
							<div class="titModal">Estadístico de la Guía</div><br>

							<div class="contModal tCenter">
								<div class="titCol">Guía <strong>673523452354326</strong></div>
								<table class="tblGeneral">
								  <tbody>
									<tr>
									  <th>Número de Lote</th>
									  <th>Total Tarjetas</th>
									  <th>Total Tarjetas<br>Pendientes de Entregar</th>
									  <th>Total Tarjetas<br><br>Entregadas/canceladas</th>
									  <th>Fecha Recepción</th>
									</tr>
									<tr>
									   <td>{{v-bind:NoLote}}</td>
										
									</tr>
								  </tbody>
								</table>
							</div>
						</div>
					  </div><br>
					</div>
				  </div>
				</div>
			</transition>
		`,
		props: ['show'],
		methods: {
			close: function () {
				this.$emit('close');
			},
		}
	});
	
	Vue.component('estadistico-guia', {
        template: `
			<div class="contSecc">
				<div class="titSec">Busqueda de Guías</div>
				<div class="gris">
					<div class="titCol">Ingrese la siguiente información.</div>
					<div class="divCol4">
						<div class="col4">
							Tipo de Tarjetas:<br>
							<drop_down :config="selTarjeta" 
									   @cambiar_option_seleccionada="setSelectedOpTarjeta($event);">
							</drop_down>
						</div>
						<div class="col4">
							Tipo de Producto:<br>
							<drop_down :config="selProducto" 
									   @cambiar_option_seleccionada="setSelectedOpProducto($event);">
							</drop_down>
						</div>

						<div class="col4">&nbsp;<br><a href="#" class="btn1 btnBuscar "
								v-on:click.prevent="funcConsultaGuia()">Consultar</a></div>
					</div>

					<div class="clear"></div>&nbsp;
					<div class="divError">&nbsp;</div>
				</div>
				<div class="clear">&nbsp;</div>
                        <div class="divBuscar" v-if="resultadosGuia" v-show="resultadosGuia.length > 0">
                            <div class="titSec">Resultado de la consulta</div>
                            <div class="gris">
                                <div class="scroll scrolly">
                                    <table class="tblGeneral tblClientes">
                                        <tbody>
                                            <tr>
                                                <th>Número de Guía</th>
                                                <th>Total de Tarjetas</th>
                                                <th>Total de Tarjetas<br>pendientes de Entregar</th>
                                                <th>Total de Tarjetas<br>Entregadas/Canceladas</th>
                                                <th>Ver Detalles</th>
                                            </tr>
                                            <tr v-for="resultadoGuia in resultadosGuia" >
                                                <td> {{resultadoGuia.NoGuia}}</td>
                                                <td>{{resultadoGuia.totalTarjeta}}</td>
                                                <td>{{resultadoGuia.totalTarjetaP}}</td>
                                                <td>{{resultadoGuia.TotalTarjetaC}}</td>
                                                <td> <a href="#" @click="modalEstadistico_view = true,funcDetalleGuia(resultadoGuia)"><img src="img/icoVer.svg"></a></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

 				<modalEstadistico v-if="modalEstadistico_view" @close="modalEstadistico_view  = false" v-bind:NoLote="guiaDetalle.NoLote"></modalEstadistico>
			</div>
        `,
		props: [],
		data: function () {
			return {
				resultadosGuia: [],
				selTarjetaID:"0",
				selProductoID:"0",
				//Modal Estadístico Guía
				open: false,
				modalEstadistico_view: false,
				
				opDetalle: "",
				guiaDetalle: null,

				//Tipo de tarjeta
				selTarjeta: {
					options: [
					  {id:1,value: "Crédito"},
					  {id:2,value: "Nómina"},
					  {id:3,value: "Personalizada"}
					],
					prefix: "",
					placeholder: "Seleccione una opción",
					textColor: "#006341"
				},
				//Tipo de Producto
				selProducto: {
					options: [
					  {id:1,value: "CP. -Tarjeta Mastercard Anónima"},
					  {id:2,value: "Opción 2"},
					  {id:3,value: "Opción 3"}
					],
					prefix: "",
					placeholder: "Seleccione una opción",
					textColor: "#006341"
				},
			};
		},
		methods: {
			//Tipo de tarjeta
			setSelectedOpTarjeta(selectedOption) {
				this.selTarjetaID=selectedOption.id;
      			this.selTarjeta.placeholder = selectedOption.value;
			},
			//Tipo de producto
			setSelectedOpProducto(selectedOption) {
				this.selProductoID=selectedOption.id;
      			this.selProducto.placeholder = selectedOption.value;
			},
			
			funcConsultaGuia: function () {
				if (this.selTarjetaID == "0")  { $(".divError").html('Es necesario que seleccione un tipo de tarjeta');return false;}
				else if (this.selProductoID == "0") { $(".divError").html('Es necesario seleccione un tipo de producto'); return false; }
				
				else {
					this.resultadosGuia = [
						{ NoGuia: '67100735645553647367', NoLote:'51007356455536473647', totalTarjeta: '2', totalTarjetaP: '2', TotalTarjetaC: '2', fecha :'12/04/2019' },
						{ NoGuia: '67007356455536473648', NoLote:'51007356455536473648', totalTarjeta: '2', totalTarjetaP: '2', TotalTarjetaC: '2', fecha :'12/04/2019' },
						{ NoGuia: '67007356455536473649', NoLote:'51007356455536473649', totalTarjeta: '2', totalTarjetaP: '2', TotalTarjetaC: '2', fecha :'12/04/2019' },
						{ NoGuia: '67007356455536473610', NoLote:'51007356455536473610',totalTarjeta: '2', totalTarjetaP: '2', TotalTarjetaC: '2', fecha :'12/04/2019' },
						{ NoGuia: '67007356455536473611', NoLote:'51007356455536473611',totalTarjeta: '2', totalTarjetaP: '2', TotalTarjetaC: '2', fecha :'12/04/2019' },
						{ NoGuia: '67007356455536473612', NoLote:'51007356455536473612',totalTarjeta: '2', totalTarjetaP: '2', TotalTarjetaC: '2', fecha :'12/04/2019' },
					];
					$(".divError").html(''); 
				}
			},
			

			funcDetalleGuia: function (opDetalle) {
				this.guiaDetalle = opDetalle;
			},
			/*regresar: function () {
				console.log('regresar');
				this.clienteDetalle = null;
				this.opDetalle = 0;
				this.divConsultaSaldo = 0;
				this.funcResultados();
			},*/

			//Modal ---------------------------------------------
			hideModal: function () {
				this.open = false;
			}
		}
	});
            
}



