if (Vue) {
	Vue.component('drop_down',{
		template:`
		<div class="dropdown" @click="toggleRiskLevels" :class="{ expanded: isExpanded }" :style="computedStyles">
			<div class="dropdown-label-container">
				<div class="dropdown-label">
        			<span class="text">
          			{{(config.prefix ? config.prefix : "") + " "}}{{config.placeholder ? config.placeholder : ""}}
        			</span>
					<i class="angle-down" :class="{ toggled: isExpanded }"></i>
				</div>
			</div>
			<div v-expand="isExpanded" class="options expand">
				<div v-for="option in configOptions" class="option" @click="setCurrentSelectedOption(option);">
					{{ option.value }}
				</div>
			</div>
		</div>`,
		data: function(){
			return {
				isBottomSectionToggled: false,
				optionsHeight: 0,
				optionHeight: 35,
				width: 100,
				configOptions: [],
				backgroundColor: "#cde4f5",
				backgroundExpandedColor: "#fff",
				hoverBackgroundColor: "#0084d4",
				border: "1px solid  #232b35",
				borderRadius: 0,
				textColor: "#fff",
				isExpanded: false
			};
		},
		props: ["config"],
		computed: {
			computedStyles: function() {
				return [
					{ '--options-height': this.optionsHeight + 'px' },
					{ '--options-height-neg': '-' + this.optionsHeight + 'px' },
					{ '--option-height': this.optionHeight + 'px' },
					{ '--main-el-border-radius': this.borderRadius },
					{ '--dropdown-width': this.width + 'px' },
					{ '--dropdown-background-color': this.backgroundColor },
					{ '--dropdown-expanded-color': this.backgroundExpandedColor },
					{ '--dropdown-border': this.border },
					{ '--dropdown-hover-background-color': this.hoverBackgroundColor },
					{ '--dropdown-default-text-color': this.textColor }
				];
			}
		},
		directives: {
			expand: {
				inserted: function(el, binding) {
					if (binding.value !== null) {
						function calcHeight() {
							const currentState = el.getAttribute("aria-expanded");
							el.classList.add("u-no-transition");
							el.removeAttribute("aria-expanded");
							el.style.height = null;
							el.style.height = el.clientHeight + "px";
							el.setAttribute("aria-expanded", currentState);

							setTimeout(function() {
								el.classList.remove("u-no-transition");
							});
						}
						el.classList.add("expand");
						el.setAttribute("aria-expanded", binding.value ? "true" : "false");
						calcHeight();
						window.addEventListener("resize", calcHeight);
					}
				},
				update: function(el, binding) {
					if (el.style.height && binding.value !== null) {
						el.setAttribute("aria-expanded", binding.value ? "true" : "false");
					}
				}
			}
		},
		methods: {
			toggleRiskLevels() {
				this.isExpanded = !this.isExpanded;
			},
			setCurrentSelectedOption(option) {
				this.$emit("cambiar_option_seleccionada", option);
			},
			setConfigData() {
				this.configOptions = this.config.options;
				this.width = this.config.width;
				this.placeholder = this.config.placeholder;
				if (this.config.backgroundColor) {
					this.backgroundColor = this.config.backgroundColor;
				}
				if (this.config.backgroundExpandedColor) {
					this.backgroundExpandedColor = this.config.backgroundExpandedColor;
				}
				if (this.config.border) {
					this.border = this.config.border;
				}
				if (this.config.hoverBackgroundColor) {
					this.hoverBackgroundColor = this.config.hoverBackgroundColor;
				}
				if (this.config.textColor) {
					this.textColor = this.config.textColor;
				}
				if (this.config.borderRadius) {
					this.borderRadius = this.config.borderRadius;
				}
			},
			setOptionsHeight() {
				this.optionsHeight = this.optionHeight * this.configOptions.length;
			}
		},
		created() {
			this.setConfigData();
			this.setOptionsHeight();
		},
		beforeUdate() {
			// this.setOptionsHeight();
		},
		mounted() {}
	});
	Vue.component('header_principal', {
		template: `
			<div class="header">
				<div class="headerMenu">&nbsp</div>
				<div class="headerLogo">
					<a href="index.html"><img src="img/logo.svg" id="imgLogo"></a>
				</div>
				<div class="headerUser">
					<div class="name"><strong>{{usr_nombre}}</strong> {{usr_apellido}}<br>{{usr_puesto}}</div>
				</div>
			</div>
		`,
		props: ['usr_nombre', 'usr_apellido', 'usr_puesto'],
		created: function () {
		},
	});
	Vue.component('menuprin', {
	template: `
		<div id="menu1">
			<ul class="Nivel1">
				<li v-bind:class="{'menuActiv': opcionSel(1)}" v-on:click="selectOption(1)"><a href="consulta-saldo.html"><div><div><img src="img/menu/menu1.svg"></div><div>OPERACIONES TOP</div></div></a></li>
				<li v-bind:class="{'menuActiv': opcionSel(2)}" v-on:click="selectOption(2)"><div><div><img src="img/menu/menu2.svg"></div><div>DEPOSITOS</div></div></li>
				<li v-bind:class="{'menuActiv': opcionSel(3)}" v-on:click="selectOption(3)"><div><div><img src="img/menu/menu3.svg"></div><div>RETIROS</div></div>
					<ul class="Nivel2">
						<li>
							<a href="#">
								<p>Nivel 2</p>
								<div class="flecha"></div>
							</a>
							<ul class="Nivel3">
								<li><a href="#">
										<p>Nivel 3</p>
									</a></li>
								<li><a href="#">
										<p>Nivel 3</p>
									</a></li>
								<li><a href="#">
										<p>Nivel 3</p>
									</a></li>
								<li><a href="#">
										<p>Nivel 3</p>
									</a></li>
							</ul>
						</li>
					</ul>
				</li>
				<li  v-bind:class="{'menuActiv': opcionSel(4)}" v-on:click="selectOption(4)"><div><div><img src="img/menu/menu4.svg"></div><div>CANCELACIÓN</div></div></li>
				<li  v-bind:class="{'menuActiv': opcionSel(5)}" v-on:click="selectOption(5)"><div><div><img src="img/menu/menu5.svg"></div><div>CONSULTAS</div></div></li>
				<li  v-bind:class="{'menuActiv': opcionSel(6)}" v-on:click="selectOption(6)"><div><div><img src="img/menu/menu6.svg"></div><div>REVERSOS</div></div></li>
				<li  v-bind:class="{'menuActiv': opcionSel(7)}" v-on:click="selectOption(7)"><div><div><img src="img/menu/menu7.svg"></div><div>MI AYUDA</div></div></li>
			</ul>
		</div>
	`,
		created: function () {
		},
		methods: {
			selectOption: function (opMenu) {
				this.opMenuSel = opMenu;
			},
			opcionSel: function (opMenu) {
				return this.opMenuSel == opMenu;
			},
		},
		data: function () {
			return { opMenuSel: 0, };
		},
	});

	/*componente menu + header */
	Vue.component('menu_mas_header',{
		template:`
		<div>
			<header_principal v-bind:usr_nombre="usr_nombre" v-bind:usr_apellido="usr_apellido" v-bind:usr_puesto="usr_puesto"></header_principal>
			<menuprin></menuprin>
		</div>
		`,
		props: ['usr_nombre', 'usr_apellido', 'usr_puesto']
	});
	//Loader
	Vue.component('loader', {
		template: `
			<div>
				<div class="modal-mask "></div>
				<div class="loader">Loading...</div>
			</div>
		`,
		created: function () {
		},
		methods: {
		}
	});

	//slider
	Vue.component('slider', {
		template: `
			<div class="contHome">
				<div id="owl-carousel3" class="owl-carousel owl-theme">
					<div class="item"><img src="img/slider/slider01.jpg" class="png"></div>
					<div class="item"><img src="img/slider/slider02.jpg" class="png"></div>
				</div>
			</div>
		`,
		created: function () {
		},
		methods: {		
			
		}
	});

	var app_obj = new Vue({
		el: '#app',
		data: {
			usrNombre: '',
			usrApellido: '',
			usrPuesto: '',
			noAhorro: '',
			selCuenta: '',
			config_select: {
        options: [
          {
			id:1,
            value: "option 1"
          },
          {
			  id:2,
            value: "option 2"
          },
          {
			  id:3,
            value: "option 3"
          }
        	],
        	prefix: "",
        	placeholder: "Seleccionar",
        	backgroundColor: "#cde4f5",
        	textColor: "black",
        	borderRadius: "4px",
        	border: "1px solid gray",
        	width: 150
			}
		},
		
		methods: {
			//header Usuario ----------------------------
			cargarInfUsuario: function () {
				this.usrNombre = 'Coyolxauhqui';
				this.usrApellido = 'Ramírez Romero';
				this.usrPuesto = 'Administrador';
			},
			//Slider--------------------------------------
			cargarSlider: function () {
				$('#owl-carousel3').owlCarousel({
					margin: 10,
					nav: true,
					loop: true,
					responsive: {
						0: {
							items: 1
						},
						600: {
							items: 1
						},
						1000: {
							items: 1
						}
					}
				});
			},	
			cargaSelect:function(){
				console.log('entra a cargaSelect');
				console.log($("select"));
				$("select").dropkick({
					mobile: true
				});	
			},
			setSelectedOption(selectedOption) {
				this.selCuenta=selectedOption.id;
      			this.config_select.placeholder = selectedOption.value;
				console.log(this.selCuenta);
			}
		},
		created: function () {
			this.cargarInfUsuario();
			//this.cargaSelect();
			
		},
		mounted: function () {
			this.cargarSlider();
			
		},
		updated: function () {
			
		}
	});
}



