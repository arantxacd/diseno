if (Vue) {
	Vue.component('tabla', {
		template: `
			<div class="contSecc">
				<v-simple-table class="tblVue">
					<template v-slot:default>
						<thead class="tblHead">
							<tr>
								<th class="text-left">Nombre</th>
								<th class="text-left">Calorías</th>
								<th class="text-left">Pagos</th>
							</tr>
						</thead>
						<tbody class="tblBody">
							<tr v-for="item in postres" :key="item.name">
								<td>{{ item.name }}</td>
								<td>{{ item.calories }}</td>
								<td class="cantidad">{{ item.pagos }}</td>
							</tr>
							<tr class="total">
								<td colspan="2">&nbsp;</td>
								<td class="cantidad">$365,688.00</td>
							</tr>
						</tbody>
					</template>
				</v-simple-table>
			</div>
        `,
	  	data () {
			return {
			  postres: [
				{name: 'Frozen Yogurt',calories: 159,pagos:'$100.00'},
				{name: 'Ice cream sandwich',calories: 237,pagos:'$10,000.00'},
				{name: 'Eclair',calories: 262,pagos:'$500.00'},
				{name: 'Cupcake',calories: 305,pagos:'$80.00'},
				{name: 'Gingerbread',calories: 356,pagos:'$20,000.00'},
				{name: 'Jelly bean',calories: 375,pagos:'$90.00'},
				{name: 'Lollipop',calories: 392,pagos:'$234,000.00'},
				{name: 'Honeycomb',calories: 408,pagos:'$100,000.00'},
				{name: 'Donut',calories: 452,pagos:'$18.00'},
				{name: 'KitKat',calories: 518,pagos:'$900.00'},
			  ],
			}
		  },
	});  
}

new Vue({
	el: '#tabla',
	vuetify: new Vuetify(),
})