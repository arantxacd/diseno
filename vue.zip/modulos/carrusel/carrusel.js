if (Vue) {
	Vue.component('carrusel', {
		template: `
			<div class="contSecc" >
				<v-carousel
					cycle
					height="400"
					hide-delimiter-background
					show-arrows-on-hover
				>
					<v-carousel-item
					v-for="(imagen, i) in imagenes"
					:src="imagen.src"
					:key="i"
					reverse-transition="fade-transition"
      				transition="fade-transition"
					>
					</v-carousel-item>
				</v-carousel>
			</div>
        `,
	  	data () {
			return {
				imagenes:[
					{src:'slider/slider01.jpg'},
					{src:'slider/slider02.jpg'},
					{src:'slider/slider03.jpg'},
					{src:'slider/slider04.jpg'},
				],
			}
		},
	});  
}

new Vue({
	el: '#app',
	vuetify: new Vuetify(),
})