if (Vue) {
	Vue.component('tabs', {
		template: `
		<div class="contSecc" >
			<v-tabs grow hide-slider="false" class="tabEstiloPrimario" >
				<v-tab>Tab texto 1</v-tab>
				<v-tab>Tab texto 2</v-tab>
				<v-tab>Tab texto 3</v-tab>

				<v-tab-item>
					<tabs2></tabs2>
				</v-tab-item>
				<v-tab-item>
					<p>Contenido 2</p>
				</v-tab-item>
				<v-tab-item>
					<div class="gris">
						<p>Contenido 3</p>
					</div>
				</v-tab-item>
			</v-tabs>
		</div>
		`,
	}); 
	Vue.component('tabs2', {
		template: `
		<v-tabs grow class="tabEstiloSecundario" >
			<v-tabs-slider color="#006341"></v-tabs-slider>
			<v-tab>Tab texto 1</v-tab>
			<v-tab>Tab texto 2</v-tab>
			<v-tab>Tab texto 3</v-tab>
			<v-tab>Tab texto 4</v-tab>
			<v-tab>Tab texto 5</v-tab>
	
			<v-tab-item>
				<div class="gris">
					<p>Contenido</p>
				</div>
			</v-tab-item>

			<v-tab-item>
				<div class="gris">
					<p>Contenido</p>
				</div>
			</v-tab-item>

			<v-tab-item>
				<div class="gris">
					<p>Contenido 3</p>
				</div>
			</v-tab-item>

			<v-tab-item>
				<div class="gris">
					<p>Contenido 4</p>
				</div>
			</v-tab-item>
			
			<v-tab-item>
				<div class="gris">
					<p>Contenido 5</p>
				</div>
			</v-tab-item>
		</v-tabs>
		`,
	}); 
}

new Vue({
	el: '#app',
	vuetify: new Vuetify(),
})