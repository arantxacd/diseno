Vue.component('modal-componente', {


  data() {
    return {
      dialog: false,
      dialog2: false,
      dialog3: false,
    };
  },

  template: `
        <div class="contSecc">
          <v-app id="inspire" class="modalWrapper">
            <div class="gris">
              <div class="btnCenter">
                  <v-btn class="btn botonPrimario" v-on:click="dialog = true">Modal Chico</v-btn>
                  <v-btn class="btn botonPrimario" v-on:click="dialog2 = true">Modal Mediano</v-btn>
                  <v-btn class="btn botonPrimario" v-on:click="dialog3 = true">Modal Grande</v-btn>
              </div>
              <v-dialog v-model="dialog" persistent max-width="320">
                <template v-slot:activator="{ on }">
                </template>
                <v-card>
                  <a href="#" class="simplemodal-close btnCerrar" @click="dialog = false"><img src="../../assets/img/icoCerrar.svg"></a>
                  <div class="titModal">
                    <slot name="titulo">Modal Chico</slot>
                  </div>

                  <div class="contModal">
                    <slot name="contenido">
                        Texto ejemplo texto ejemplo
                        texto ejemplo texto ejemplo texto ejemplo. <br>
                        <strong>Texto ejemplo texto ejemplo texto</strong>
                    </slot>
                  </div>


                    <div class="btnCenter">
                      <v-btn class="btn botonSecundario" @click="dialog = false">Cancelar</v-btn>
                      <v-btn class="btn botonPrimario" @click="dialog = false">Aceptar</v-btn>
                    </div>


                </v-card>

              </v-dialog>
              <v-dialog v-model="dialog2" persistent max-width="768" width="70%">
                <template v-slot:activator="{ on }">
                </template>
                <v-card>
                  <a href="#" class="simplemodal-close btnCerrar" @click="dialog2 = false"><img src="../../assets/img/icoCerrar.svg"></a>
                  <div class="titModal">
                    <slot name="titulo">Modal Mediano</slot>
                  </div>

                  <div class="contModal">
                    <slot name="contenido">
                        Texto ejemplo texto ejemplo
                        texto ejemplo texto ejemplo texto ejemplo. <br>
                        <strong>Texto ejemplo texto ejemplo texto</strong>
                    </slot>
                  </div>


                    <div class="btnCenter">
                      <v-btn class="btn botonSecundario" @click="dialog2 = false">Cancelar</v-btn>
                      <v-btn class="btn botonPrimario" @click="dialog3 = !dialog3">Siguiente</v-btn>
                    </div>


                </v-card>

              </v-dialog>
              <v-dialog v-model="dialog3" persistent max-width="900" width="90%">
                <template v-slot:activator="{ on }">
                </template>
                <v-card>
                  <a href="#" class="simplemodal-close btnCerrar" @click="dialog3 = false"><img src="../../assets/img/icoCerrar.svg"></a>
                  <div class="titModal">
                    <slot name="titulo">Modal Grande</slot>
                  </div>

                  <div class="contModal">
                    <slot name="contenido">
                        Texto ejemplo texto ejemplo
                        texto ejemplo texto ejemplo texto ejemplo. <br>
                        <strong>Texto ejemplo texto ejemplo texto</strong>
                    </slot>
                  </div>


                    <div class="btnCenter">
                      <v-btn class="btn botonTerciario" @click="dialog3 = false">Otro</v-btn>
                      <v-btn class="btn botonSecundario" @click="dialog3 = false">Cancelar</v-btn>
                      <v-btn class="btn botonPrimario" @click="dialog3 = false">Aceptar</v-btn>
                    </div>


                </v-card>

              </v-dialog>
            </div>
          </v-app>
        </div>

        `,

});


new Vue({
  el: "#app",
  vuetify: new Vuetify(),
});


