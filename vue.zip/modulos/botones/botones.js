if (Vue) {
	Vue.component('combobox', {
		template: `
			<div class="contSecc" >
				<div class="gris">
					<v-form data-app>
						<v-container>
							<div class="btnCenter">
								<v-btn class="btn botonTerciario">Otro</v-btn>
								<v-btn class="btn botonSecundario">Cancelar</v-btn>
								<v-btn class="btn botonPrimario">Aceptar</v-btn>
							</div>
						</v-container>
					</v-form>
				</div>
				<div class="gris">
					<v-form data-app>
						<v-container>
							<div class="btnCenter">
								<v-btn class="botonPrimario">
									<img class="botonIcono" src="../../assets/img/icoBotones/icoGuardar.svg" alt="">Guardar
								</v-btn>
								<v-btn class="botonPrimario">
									<img class="botonIcono" src="../../assets/img/icoBotones/icoEditar.svg" alt="">Editar
								</v-btn>
								<v-btn class="botonPrimario">
									<img class="botonIcono" src="../../assets/img/icoBotones/icoLimpiar.svg" alt="">Limpiar
								</v-btn>
								<v-btn class="botonPrimario">
									<img class="botonIcono" src="../../assets/img/icoBotones/icoDescargar.svg" alt="">Descargar
								</v-btn>
								<v-btn class="botonPrimario">
									<img class="botonIcono" src="../../assets/img/icoBotones/icoPrint.svg" alt="">Imprimir
								</v-btn>
								<v-btn class="botonPrimario">
									<img class="botonIcono" src="../../assets/img/icoBotones/icoWord.svg" alt="">Word
								</v-btn>
								<v-btn class="botonPrimario">
									<img class="botonIcono" src="../../assets/img/icoBotones/icoExcel.svg" alt="">Excel
								</v-btn>
								<v-btn class="botonPrimario">
									<img class="botonIcono" src="../../assets/img/icoBotones/icoPpt.svg" alt="">Powerpoint
								</v-btn>
								<v-btn class="botonPrimario">
									<img class="botonIcono" src="../../assets/img/icoBotones/icoTxt.svg" alt="">Texto
								</v-btn>
								<v-btn class="botonPrimario">
									<img class="botonIcono" src="../../assets/img/icoBotones/icoPdf.svg" alt="">PDF
								</v-btn>
								<v-btn class="botonPrimario">
									<img class="botonIcono" src="../../assets/img/icoBotones/icoAgregar.svg" alt="">Agregar
								</v-btn>
							</div>
						</v-container>
					</v-form>
				</div>
			</div>
        `,
	});  
}

new Vue({
	el: '#app',
	vuetify: new Vuetify(),
})