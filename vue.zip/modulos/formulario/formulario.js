if (Vue) {
	Vue.component('formulario', {
		template: `
			<div class="contSecc" >
				<div class="gris">
					<v-form>
						<v-container>
							<div class="divCol">
								<div class="col3">
									<div>Nombre:</div>
									<v-text-field
										v-model="nombre"
										label="Nombre:"
										single-line
            							solo
										placeholder="Nombre"
									></v-text-field>
								</div>
								<div class="col3">
									<div>Apellido:</div>
									<v-text-field
										v-model="apellido"
										label="Apellido:"
										single-line
            							solo
										placeholder="Apellido"
									></v-text-field>
								</div>
						
								<div class="col3">
									<div>Correo:</div>
									<v-text-field
										v-model="correo"
										label="Correo:"
										single-line
            							solo
										placeholder="Correo"
									></v-text-field>
								</div>
								<div class="col3">
									<div>Teléfono:</div>
									<v-text-field
										v-model="numeroTelefonico"
										label="Teléfono:"
										single-line
            							solo
										placeholder="Teléfono"
										type="number"
									></v-text-field>
								</div>
								<div class="col3">
									<div>Textarea:</div>
									<v-textarea
										single-line
										solo
										name="textarea1"
										label="Textarea:"
										placeholder="Esto es un textarea"
									></v-textarea>
								</div>
								<div class="col3">
									<div>Adjuntar documento:</div>
									<v-file-input label="Adjuntar documento:" single-line solo dense></v-file-input>
								</div>
								<div class="col3 divSelect" >
									<div>Select:</div>
									<v-select :items="items" label="Select:" single-line solo></v-select>
								</div>
								<div class="col3 inputDatePicker">
									<div>Fecha:</div>
									<v-menu
										ref="menu1"
										v-model="menu1"
										:close-on-content-click="false"
										transition="scale-transition"
										offset-y
										max-width="290px"
										min-width="290px"
									>
										<template v-slot:activator="{ on }">
											<v-text-field
												v-model="dateFormatted"
												label="Fecha"
												prepend-icon="event"
												@blur="date = parseDate(dateFormatted)"
												v-on="on"
												single-line 
												solo
												placeholder="MM/DD/YYYY"
											></v-text-field>
										</template>
										<v-date-picker v-model="date" no-title @input="menu1 = false"></v-date-picker>
									</v-menu>
								</div>
								<div class="col3">
									<div>Switch:</div>
									<v-switch v-model="switch1" inset label="Switch"></v-switch>
								</div>
								<div class="col3 divCheckbox">
									<div>Checkboxes</div>
									<div class="divCol2Input">
										<div><v-checkbox v-model="checkbox" label="Check 1"></v-checkbox></div>
										<div><v-checkbox v-model="checkbox2" label="Check 2"></v-checkbox></div>
									</div>
								</div>
								<div class="col3 divRadio">
									<div>Radio</div>
									<v-radio-group v-model="row" row>
										<v-radio label="Opción 1" value="radio-1"></v-radio>
										<v-radio label="Opción 2" value="radio-2"></v-radio>
									</v-radio-group>
								</div>
							</div>
							<div class="btnCenter">
								<v-btn class="botonPrimario">
									<img class="botonIcono" src="../../assets/img/icoBotones/icoEditar.svg" alt="">Editar
								</v-btn>
								<v-btn class="botonPrimario">
									<img class="botonIcono" src="../../assets/img/icoBotones/icoGuardar.svg" alt="">Guardar
								</v-btn>
							</div>
						</v-container>
					</v-form>
				</div>
			</div>
        `,
	  	data () {
			return {
				nombre: '',
				apellido: '',
				correo: '',
				numeroTelefonico: '',
				textarea1:'',
				items: '',
				items: ['Banco Azteca', 'Elektra', 'Italika', 'Total Play'],
				menu1:'',
				date:'',
				dateFormatted:'',
				data: vm => ({
					date: new Date().toISOString().substr(0, 10),
					dateFormatted: vm.formatDate(new Date().toISOString().substr(0, 10)),
					menu1: false,
					menu2: false,
				}),
				checkbox: false,
				checkbox2: false,
				radioGroup: 1,
				row: null,
				switch1: false,
			}
		},
		computed: {
			computedDateFormatted () {
			  return this.formatDate(this.date)
			},
		},
		watch: {
			date (val) {
				this.dateFormatted = this.formatDate(this.date)
			},
		},
		methods: {
			formatDate (date) {
			  if (!date) return null
	  
			  const [year, month, day] = date.split('-')
			  return `${day}/${month}/${year}`
			},
			parseDate (date) {
			  if (!date) return null
	  
			  const [month, day, year] = date.split('/')
			  return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`
			},
		},
	});  
}

new Vue({
	el: '#app',
	vuetify: new Vuetify(),
})