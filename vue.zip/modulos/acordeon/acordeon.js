if (Vue) {
	Vue.component('acordeon', {
		template: `
		<div class="contSecc">
			<v-expansion-panels accordion focusable>
				<v-expansion-panel>
					<v-expansion-panel-header>
						<h4>Primer título</h4>
					</v-expansion-panel-header>
						
					<v-expansion-panel-content>
						<h4>Subtitulo</h4>
						<p>Texto prueba para ver como se ve. Texto prueba para ver como se ve.Texto prueba para ver como se ve. Texto prueba para ver como se ve.</p>
						<botones></botones>
					</v-expansion-panel-content>
				</v-expansion-panel>

				<v-expansion-panel>
					<v-expansion-panel-header>
						<h4>Segundo título</h4>
					</v-expansion-panel-header>
					<v-expansion-panel-content>
						<h4>Subtitulo</h4>
						<p>Texto prueba para ver como se ve. Texto prueba para ver como se ve.Texto prueba para ver como se ve. Texto prueba para ver como se ve.</p>
						<botones></botones>
					</v-expansion-panel-content>
				</v-expansion-panel>

				<v-expansion-panel>
					<v-expansion-panel-header>
						<h4>Tercer título</h4>
					</v-expansion-panel-header>
					<v-expansion-panel-content>
						<h4>Subtitulo</h4>
						<p>Texto prueba para ver como se ve. Texto prueba para ver como se ve.Texto prueba para ver como se ve. Texto prueba para ver como se ve.</p>
						<botones></botones>
					</v-expansion-panel-content>
				</v-expansion-panel>
			</v-expansion-panels>
		</div>
		`,
	});
	Vue.component('botones', {
		template: `
		<div class="btnCenter">
			<v-btn class="btnA btnB">Otro</v-btn>
			<v-btn class="btnA btnG">Cancelar</v-btn>
			<v-btn class="btnA">Aceptar</v-btn>
		</div>
		`,
	}); 
}

new Vue({
	el: '#app',
	vuetify: new Vuetify(),
})