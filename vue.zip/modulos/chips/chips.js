if (Vue) {
	Vue.component('chips', {
		template: `
			<div class="contSecc">
				<div class="titSec">Chips</div>
				<div class="gris">
					<div class="chipSecc">
						<v-chip
							class="ma-2"
							color="#e0e0e0"
							text-color="grey darken-4"
							pill
						>
						<div><v-checkbox v-model="checkbox" label="Banco Azteca"></v-checkbox></div>
						</v-chip>
						<v-chip
							v-if="chip1"
							class="ma-2"
							color="rgba(0, 99, 64, 0.24)"
							text-color="grey darken-4"
							pill
							close
							@click:close="chip1 = false"
						>
							<v-avatar left>
								<v-img src="https://portal.socio.gs/foto/elektra/empleados/40883.jpg"></v-img>
							</v-avatar>
							Arantxa Sara Castañeda Dorantes
						</v-chip>
						<v-chip
							class="ma-2"
							color="#FAE074"
							text-color="grey darken-4"
							>
							<v-avatar left>
								<v-img src="https://portal.socio.gs/foto/elektra/empleados/41352.jpg"></v-img>
							</v-avatar>
							Omar
						</v-chip>
					</div>
				</div>
				<div class="gris">
					<v-chip
						class="ma-2 chipLabel"
						label
					>
						Arantxa Sara Castañeda Dorantes
					</v-chip>
				</div>
			</div>
        `,
	  	data () {
			return {
				checkbox:false,
				chip1:true,
			}
		  },
	});  
}

new Vue({
	el: '#app',
	vuetify: new Vuetify(),
})