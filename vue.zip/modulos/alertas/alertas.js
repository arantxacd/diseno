if (Vue) {
	Vue.component('alertas', {
		template: `
			<div class="contSecc" >
				<div class="titSec" style="margin-bottom:15px;">Alertas</div>
				<v-alert dense text type="success">
					Éxito
				</v-alert>
				<v-alert dense text type="warning">
					Aviso
				</v-alert>
				<v-alert dense text type="error">
					Error
				</v-alert>
				<v-alert dense text type="info">
					Información
				</v-alert>
				<v-alert
					v-model="alert"
					border="left"
					colored-border
					close-text="Close Alert"
					color="green darken-2"
					elevation="2"
					dismissible
				>
					Aenean imperdiet. Quisque id odio. Cras dapibus. Pellentesque ut neque. Cras dapibus.

					Vivamus consectetuer hendrerit lacus. Sed mollis, eros et ultrices tempus, mauris ipsum aliquam libero, non adipiscing dolor urna a orci. Sed mollis, eros et ultrices tempus, mauris ipsum aliquam libero, non adipiscing dolor urna a orci. Curabitur blandit mollis lacus. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo.
				</v-alert>
				<div class="text-center">
					<v-btn
						v-if="!alert"
						color="deep-purple accent-4"
						dark
						@click="alert = true"
					>
						Reset
					</v-btn>
				</div>
			</div>
        `,
	  	data () {
			return {
				alert:true,
			}
		},
	});  
}

new Vue({
	el: '#app',
	vuetify: new Vuetify(),
})